<?php

class Customer extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('user_logged') === null) redirect(site_url('login'));
    }

    /** Pembayaran */
    public function Pembayaran()
    {
        $this->load->model('Model_sj');
        $data['h'] = $this->Model_sj->get_pembayaran()->result(); 
        $data['content'] = "customer/pembayaran";
        $this->load->view('layout', $data);
    }

    public function addPembayaran()
    {
        $this->load->model('Model_master');
        $data['customer'] = $this->Model_master->customer()->result();
        $data['content'] = "customer/add_pembayaran";
        $this->load->view('layout', $data);
    }

    public function save_pembayaran()
    {
        $user_id   = $this->session->userdata('user_id');
        $tanggal   = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $this->db->trans_start();

        $this->load->model('Model_master');
        $code = $this->Model_master->getNumbering('PMB', $tgl_input);
      
        $data = array(
            'no_pmb'=> $code,
            'tanggal'=> $this->input->post('tanggal'),
            'id_customer'=>$this->input->post('customer'),
            'keterangan'=>$this->input->post('keterangan'),
            'status'=>0,
            'created_at'=> $tanggal,
            'created_by'=> $user_id
        );
        $this->db->insert('f_pmb', $data);
        $id = $this->db->insert_id();

        if($this->db->trans_complete()){
            redirect('Customer/view/'.$id);
        }else{
            $this->session->set_flashdata('gagal', 'Data Pembayaran Invoice gagal disimpan, silahkan dicoba kembali!');
            redirect('Customer/Pembayaran');  
        }
    }

    public function delete()
    {
        $id = $this->uri->segment(3);
        $user_id  = $this->session->userdata('user_id');
        $tanggal   = date('Y-m-d H:i:s');
        $this->db->trans_start();
        if(!empty($id)){

            $this->load->model('Model_finance');
            $details = $this->Model_finance->load_inv_dtl($id)->result();
            foreach ($details as $value) {
                $nilai_bayar = $value->nilai_bayar - $value->inv_bayar;
                $this->db->where('id',$value->id_inv);
                $this->db->update('f_invoice', [
                    'nilai_bayar'=>$nilai_bayar,
                    'flag'=>0,
                    'tanggal_lunas'=>'0000-00-00',
                    'modified_at'=> $tanggal,
                    'modified_by'=> $user_id
                ]);
            }

            $this->db->where('id', $id);
            $this->db->delete('f_pmb');         

            $this->db->where('id_pmb', $id);
            $this->db->delete('f_pmb_detail');   
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Pembayaran berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data Pembayaran gagal dihapus');
        }
        redirect('Customer/Pembayaran');
    }

    public function view()
    {
        $id = $this->uri->segment(3);

        $this->load->model("Model_sj");
        $this->load->model("Model_master");
        $data['h'] = $this->Model_sj->get_data_pmb($id)->row_array();
        if($data['h']['status']==0){
            $data['content']= "customer/view_pembayaran";
        }else{
            $this->load->model('Model_finance');
            $data['details'] = $this->Model_finance->load_inv_dtl($id)->result();
            $data['content']= "customer/view_pembayaran2";
        }
        
        $this->load->view('layout', $data);
    }

    public function approve_pmb()
    {
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $id = $this->input->post('id');

        $this->db->trans_start();

        #Update status f_pmb
        $this->db->where('id', $id);
        $this->db->update('f_pmb', array(
            'status'=> 1,
            'nilai'=> $this->input->post('nilai_pmb'),
            'modified_at'=> $tanggal,
            'modified_by'=>$user_id
        ));

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Pembayaran berhasil diapprove');
        }else{
            $this->session->set_flashdata('gagal', 'Data Pembayaran gagal diapprove');
        }
        redirect('Customer/Pembayaran');
    }

    function open_inv(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $id = $this->input->post('id');

        $this->db->trans_start();

        #Update status SPB
        $this->db->where('id', $id);
        $this->db->update('f_pmb', array(
            'status'=> 0,
            'nilai'=> 0,
            'modified_at'=> $tanggal,
            'modified_by'=>$user_id
        ));

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Invoice berhasil di open');
        }else{
            $this->session->set_flashdata('gagal', 'Data Invoice gagal di open');
        }
        redirect('Customer/view/'.$id);
    }

    public function add_inv_pmb()
    {
        $this->db->trans_start();
        if($this->input->post('sisa_inv')==0){
            $flag = 1;//sudah lunas
            $tanggal_lunas = $this->input->post('tanggal');
        }else{
            $flag = 0;
            $tanggal_lunas = '0000-00-00';
        }

        $this->load->model("Model_finance");

        $get_inv = $this->Model_finance->get_data_inv($this->input->post('id_inv'))->row_array();
        $nilai_bayar = $get_inv['nilai_bayar'] + str_replace(',', '', $this->input->post('nominal_bayar'));

        $this->db->where('id',$this->input->post('id_inv'));
        $this->db->update('f_invoice', array(
            'nilai_bayar'=>$nilai_bayar,
            'tanggal_lunas'=>$tanggal_lunas,
            'flag'=>$flag
        ));

        $data = array(
            'id_pmb'=>$this->input->post('id_modal'),
            'id_inv'=>$this->input->post('id_inv'),
            'inv_bayar'=>str_replace(',', '', $this->input->post('nominal_bayar'))
        );
        $this->db->insert('f_pmb_detail', $data);

        if($this->db->trans_complete()){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan Pembayaran! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function add_biaya_pmb()
    {
        $this->db->trans_start();

        $data = array(
            'id_pmb'=>$this->input->post('id_pmb'),
            'jenis'=>1,//jenis biaya
            'id_inv'=>0,
            'inv_bayar'=>str_replace(',', '', $this->input->post('nominal')),
            'keterangan'=>$this->input->post('keterangan')
        );
        $this->db->insert('f_pmb_detail', $data);

        if($this->db->trans_complete()){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan Pembayaran! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function load_list_inv()
    {
        $id = $this->input->post('id');
        $id_pmb = $this->input->post('id_pmb');

        $tabel = "";
        $total_invoice = 0;
        $no    = 1;
        $this->load->model('Model_finance');
        $myDetail = $this->Model_finance->load_inv_full($id,$id_pmb)->result();
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center;width:5%;">'.$no.'</td>';
            $tabel .= '<td>'.$row->no_invoice.'</td>';
            $tabel .= '<td style="text-align:right;">'.number_format($row->nilai_invoice-$row->nilai_bayar,2,',','.').'</td>';
            $tabel .= '<td style="text-align:center">';
            if($row->count==0){
                $tabel .= '<a href="javascript:;" class="btn btn-warning btn-xs" onclick="input_inv('.$row->id.');" style="margin-top:2px; margin-bottom:2px;" id="addInv"><i class="fa fa-plus"></i> Tambah </a>';
            }else{
                $tabel .= 'Added!';
            }
            $tabel .= '</td>';
            $no++;
            $total_invoice += $row->nilai_invoice-$row->nilai_bayar;
        }
        $tabel .= '<tr>';
        $tabel .= '<td style="text-align:right;" colspan="2"><strong>Total Invoice </strong></td>';
        $tabel .= '<td style="text-align:right;">';
        $tabel .= '<strong>'.number_format($total_invoice,2,',','.').'</strong>';
        $tabel .= '<input type="hidden" id="list_inv" name="list_inv" value="'.$total_invoice.'">';
        $tabel .= '</td>';
        $tabel .= '<td></td>';
        $tabel .= '</tr>';

        header('Content-Type: application/json');
        echo json_encode($tabel); 
    }

    public function load_data_inv()
    {
        $id = $this->input->post('id');

        $tabel = "";
        $total_nominal = 0;
        $no    = 1;
        $this->load->model('Model_finance');
        $myDetail = $this->Model_finance->load_inv_dtl($id)->result();
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center">'.$no.'</td>';
            $tabel .= '<td>'.$row->no_invoice.'</td>';
            $tabel .= '<td style="text-align:right;">'.number_format($row->inv_bayar,2,',', '.').'</td>';
            $tabel .= '<td style="text-align:center">';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-danger" onclick="delINV('.$row->id.','.$row->id_inv.');" style="margin-top:2px; margin-bottom:2px;margin-left:2px;" id="delSJ"><i class="fa fa-trash"></i> Delete </a></td>';
            $tabel .= '</tr>';            
            $no++;
            $total_nominal += $row->inv_bayar;
        }
        $tabel .= '<tr>';
        $tabel .= '<td style="text-align:right;" colspan="2"><strong>Total Invoice </strong></td>';
        $tabel .= '<td style="text-align:right;">';
        $tabel .= '<strong>'.number_format($total_nominal,2,',','.').'</strong>';
        $tabel .= '<input type="hidden" id="total_inv" name="total_inv" value="'.$total_nominal.'">';
        $tabel .= '</td>';
        $tabel .= '<td id="view_total_inv"></td>';
        $tabel .= '</tr>';

        header('Content-Type: application/json');
        echo json_encode($tabel); 
    }

    public function del_inv()
    {
        $return_data = array();
        $id = $this->input->post('id');
        $id_inv = $this->input->post('id_inv');
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');

        $this->db->trans_start();

        if($id_inv>0){
            $this->load->model('Model_finance');
            $get = $this->Model_finance->view_inv_data($id)->row_array();
            $nilai_bayar = $get['nilai_bayar'] - $get['inv_bayar'];

            $this->db->where('id',$get['id_inv']);
            $this->db->update('f_invoice', array(
                'nilai_bayar'=>$nilai_bayar,
                'tanggal_lunas'=>'0000-00-00',
                'flag'=>0,
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ));
        }

        $this->db->where('id', $this->input->post('id'));
        $this->db->delete('f_pmb_detail');

        if($this->db->trans_complete()){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal Menghapus! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data);  
    }
    
    public function get_data_inv()
    {
        $id = $this->input->post('id');

        $this->load->model('Model_finance');
        $result= $this->Model_finance->get_data_inv($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function view_data_inv()
    {
        $id = $this->input->post('id');

        $this->load->model('Model_finance');
        $result= $this->Model_finance->view_inv_data($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }


}    