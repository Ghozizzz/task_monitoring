<?php

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("Model_master");
        if($this->session->userdata('user_logged') === null) redirect(site_url('login'));
    }

    public function index()
    {
        $data['content']= "layout/example";
        $this->load->view('layout', $data);
    }

/** BANK **/
    public function bank()
    {
        $data['content']= "master/bank";
        $data['data'] = $this->Model_master->bank()->result();
        $this->load->view('layout', $data);
    }

    function bank_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $data = [
                    'nama_bank'=> $this->input->post('nama_bank'),
                    'nomor_rekening'=> $this->input->post('nomor_rekening'),
                    'atas_nama'=> $this->input->post('atas_nama'),
                    'currency'=> $this->input->post('currency'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id,
                ];
       
        $this->db->insert('m_bank', $data); 
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data bank berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data bank gagal disimpan');
        }
        redirect('Admin/bank');       
    }
    
    function bank_delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('m_bank');            
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data bank berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data bank gagal dihapus');
        }
        redirect('Admin/bank');
    }
    
    function bank_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_bank($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function bank_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        
        $data = [
                'nama_bank'=> $this->input->post('nama_bank'),
                'nomor_rekening'=> $this->input->post('nomor_rekening'),
                'atas_nama'=> $this->input->post('atas_nama'),
                'currency'=> $this->input->post('currency'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ];
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('m_bank', $data);
        
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data bank berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data bank gagal disimpan');
        }
        redirect('Admin/bank');
    }

/** Barang **/
    public function barang()
    {
        $data['content']= "master/barang";
        $data['data'] = $this->Model_master->barang()->result();
        $this->load->view('layout', $data);
    }

    function barang_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $data = [
                    'nama_barang'=> $this->input->post('nama_barang'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id,
                ];
       
        $this->db->insert('m_barang', $data); 
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data barang berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data barang gagal disimpan');
        }
        redirect('Admin/barang');       
    }
    
    function barang_delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('m_barang');            
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data barang berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data barang gagal dihapus');
        }
        redirect('Admin/barang');
    }
    
    function barang_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_barang($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function barang_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        
        $data = [
                'nama_barang'=> $this->input->post('nama_barang'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ];
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('m_barang', $data);
        
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data barang berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data barang gagal disimpan');
        }
        redirect('Admin/barang');
    }

/** Barang Relasi **/
    public function barang_relasi()
    {
        $data['content']= "master/barang_relasi";
        $data['data'] = $this->Model_master->barang_relasi()->result();
        $data['barang'] = $this->Model_master->barang()->result();
        $data['customer'] = $this->Model_master->customer()->result();
        $this->load->view('layout', $data);
    }

    function barang_relasi_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $id_barang = $this->input->post('barang');
        $id_customer = $this->input->post('customer');

        $cek = $this->Model_master->cek_barang_relasi($id_barang,$id_customer)->row_array();
        if(empty($cek)){
            $data = [
                        'id_barang'=> $id_barang,
                        'id_customer'=> $id_customer
                    ];
            $this->db->insert('m_barang_relasi', $data);
            if($this->db->trans_complete()){
                $this->session->set_flashdata('sukses', 'Data barang berhasil disimpan');
            }else{
                $this->session->set_flashdata('gagal', 'Data barang gagal disimpan');
            }
        }else{
            $this->session->set_flashdata('gagal', 'Data barang relasi sudah ada yang sama');
        }
        redirect('Admin/barang_relasi');       
    }
    
    function barang_relasi_delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('m_barang_relasi');            
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data barang berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data barang gagal dihapus');
        }
        redirect('Admin/barang_relasi');
    }
    
    function barang_relasi_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_barang_relasi($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function barang_relasi_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $id_barang = $this->input->post('barang');
        $id_customer = $this->input->post('customer');
        
        $cek = $this->Model_master->cek_barang_relasi($id_barang,$id_customer)->row_array();
        if(empty($cek)){
            $data = [
                    'id_barang'=> $id_barang,
                    'id_customer'=> $id_customer
                ];
            $this->db->where('id', $this->input->post('id'));
            $this->db->update('m_barang_relasi', $data);
            
            if($this->db->trans_complete()){
                $this->session->set_flashdata('sukses', 'Data barang berhasil disimpan');
            }else{
                $this->session->set_flashdata('gagal', 'Data barang gagal disimpan');
            }
        }else{
            $this->session->set_flashdata('gagal', 'Data barang relasi sudah ada yang sama');
        }
        redirect('Admin/barang_relasi');
    }

/** Harga Barang **/
    public function harga_barang()
    {
        $data['content']= "master/harga_barang";
        $data['customer'] = $this->Model_master->customer()->result();
        // $data['barang'] = $this->Model_master->barang()->result();
        $data['data'] = $this->Model_master->harga_barang()->result();
        $this->load->view('layout', $data);
    }

    function harga_barang_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();

        //Insert Harga Beli
        $this->db->insert('m_harga', [
            'id_barang'=> $this->input->post('barang'),
            'id_customer'=> $this->input->post('customer'),
            'harga'=> $this->input->post('harga'),
            'tanggal'=> $this->input->post('tanggal'),
            'created_at'=> $tanggal,
            'created_by'=> $user_id,
        ]);

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data harga barang berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data harga barang gagal disimpan');
        }
        redirect('Admin/harga_barang');       
    }
    
    public function view_harga()
    {
        $id = $this->uri->segment(3);

        $data['content'] = "master/view_harga";
        $data['data'] = $this->Model_master->get_harga_barang_list2($id)->result();

        $this->load->view('layout', $data);
    }

    function delete_harga(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $check['count'] = 0;
            $check = $this->Model_master->check_harga($id)->row_array();
            if($check['count']==0){
                $this->db->where('id', $id);
                $this->db->delete('m_harga');
            }        
        }
        if($check['count']==0 && $this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data harga barang berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data harga barang gagal dihapus');
        }
        redirect('Admin/harga_barang');
    }
    
    function harga_barang_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_harga_barang_customer($id)->row_array();
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }

    function harga_barang_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $id = $this->input->post('id');
        $this->db->trans_start();
        if(!empty($id)){
            $check['count'] = 0;
            $check = $this->Model_master->check_harga($id)->row_array();
            $data = $this->Model_master->get_harga_barang($id)->row_array(); 
            if($check['count']==0){
                //Insert Harga Beli
                $this->db->where('id',$id);
                $this->db->update('m_harga', [
                    'harga'=> $this->input->post('harga'),
                    'tanggal'=> $this->input->post('tanggal'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id,
                ]);

                $this->db->insert('logs', [
                    'jenis'=>'update',
                    'tabel'=>'m_harga',
                    'reff'=>$id,
                    'json'=>json_encode($data),
                    'created_at'=>$tanggal,
                    'created_by'=>$user_id
                ]);
                if($this->db->trans_complete()){
                    $this->session->set_flashdata('sukses', 'Data harga barang berhasil disimpan');
                }else{
                    $this->session->set_flashdata('gagal', 'Data harga barang gagal disimpan');
                }
            }else{
                $this->session->set_flashdata('gagal', 'Data harga barang sudah dipakai di surat jalan, gagal disimpan !');
            }
            redirect('Admin/view_harga/'.$data['id_barang']);    
        }else{
            $this->session->set_flashdata('gagal', 'Data harga barang gagal disimpan');
            redirect('Admin/harga_barang');
        }
    }

    function get_harga_barang_list(){ 
        $id = $this->input->post('id');
        $idc = $this->input->post('idc');
        $cur_date = $this->input->post('cur_date');

        $table = '';
        $data = $this->Model_master->get_harga_barang_list($id,$idc,$cur_date)->result();
        $table .= '<option value="">Silahkan pilih....</option>';
        foreach ($data as $row) {
            $table .= '<option value="'.$row->id.','.$row->harga.'">'.number_format($row->harga,2,',','.').' ('.$row->tanggal.')</option>';
        } 

        print $table;
        // print form_dropdown('harga_barang', $arr_so, [], );
    }

    function get_harga_barang_sj(){ 
        $id = $this->input->post('id');
        $idc = $this->input->post('idc');
        $id_harga = $this->input->post('id_harga');
        $cur_date = $this->input->post('cur_date');

        $tabel = '';
        $data = $this->Model_master->get_harga_barang_list($id,$idc,$cur_date)->result();
        foreach ($data as $row) {
            if($row->id==$id_harga){
                $status ='selected';
            }else{
                $status = '';
            }
            $tabel .= '<option value="'.$row->id.','.$row->harga.'" '.$status.'>'.number_format($row->harga,2,',','.').' ('.$row->tanggal.')</option>';
        } 

        header('Content-Type: application/json');
        echo json_encode($tabel);
        // print form_dropdown('harga_barang', $arr_so, [], );
    }

    function get_harga_current(){ 
        $id = $this->input->post('id');
        $idc = $this->input->post('idc');
        $id_harga = $this->input->post('id_harga');
        $cur_date = $this->input->post('cur_date');

        $tabel = '';
        $data = $this->Model_master->get_harga_barang_list($id,$idc,$cur_date)->result();
        foreach ($data as $row) {
            if($row->id==$id_harga){
                $status ='selected';
            }else{
                $status = '';
            }
            $tabel .= '<option value="'.$row->id.','.$row->harga.'" '.$status.'>'.number_format($row->harga,2,',','.').' ('.$row->tanggal.')</option>';
        } 

        print $tabel;
        // print form_dropdown('harga_barang', $arr_so, [], );
    }

    function get_barang_customer(){ 
        $id = $this->input->post('id');

        $table = '';
        $data = $this->Model_master->get_barang_customer($id)->result();
        $table .= '<option value="">Silahkan pilih....</option>';
        foreach ($data as $row) {
            $table .= '<option value="'.$row->id.'">'.$row->nama_barang.'</option>';
        } 

        print $table;
        // print form_dropdown('harga_barang', $arr_so, [], );
    }

/** Harga Jual **/
    public function harga_jual()
    {
        $data['content']= "master/harga_jual";
        $data['barang'] = $this->Model_master->barang()->result();
        $data['data'] = $this->Model_master->harga_jual()->result();
        $this->load->view('layout', $data);
    }

    function harga_jual_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $data = [
            'id_barang'=> $this->input->post('barang'),
            'harga'=> $this->input->post('harga'),
            'tanggal'=> $this->input->post('tanggal'),
            'created_at'=> $tanggal,
            'created_by'=> $user_id,
        ];
       
        $this->db->insert('m_harga_jual', $data); 
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data harga jual berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data harga jual gagal disimpan');
        }
        redirect('Admin/harga_jual');       
    }
    
    // function harga_jual_delete(){
    //     $id = $this->uri->segment(3);
    //     $this->db->trans_start();
    //     if(!empty($id)){
    //         $this->db->where('id', $id);
    //         $this->db->delete('m_harga_jual');            
    //     }
    //     if($this->db->trans_complete()){
    //         $this->session->set_flashdata('sukses', 'Data harga jual berhasil dihapus');
    //     }else{
    //         $this->session->set_flashdata('gagal', 'Data harga jual gagal dihapus');
    //     }
    //     redirect('Admin/harga_jual');
    // }
    
    function harga_jual_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_harga_jual($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function harga_jual_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        
        $data = [
                'id_barang'=> $this->input->post('barang'),
                'harga'=> $this->input->post('harga'),
                'tanggal'=> $this->input->post('tanggal'),
                'created_at'=> $tanggal,
                'created_by'=> $user_id
            ];
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->insert('m_harga_jual', $data);
        
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data harga jual berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data harga jual gagal disimpan');
        }
        redirect('Admin/harga_jual');
    }

/** Customer **/
    public function customer()
    {
        $data['content']= "master/customer";
        $data['data'] = $this->Model_master->customer()->result();
        $this->load->view('layout', $data);
    }

    function customer_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $data = [
                    'nama_customer'=> $this->input->post('nama_customer'),
                    'kode_customer'=> $this->input->post('kode_customer'),
                    'alamat'=> $this->input->post('alamat'),
                    'nama_bank'=> $this->input->post('nama_bank'),
                    'no_rekening'=> $this->input->post('no_rekening'),
                    'atas_nama'=> $this->input->post('atas_nama'),
                    'kcp'=> $this->input->post('kcp'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id,
                ];
       
        $this->db->insert('m_customer', $data); 
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data customer berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data customer gagal disimpan');
        }
        redirect('Admin/customer');       
    }
    
    function customer_delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('m_customer');            
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data customer berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data customer gagal dihapus');
        }
        redirect('Admin/customer');
    }
    
    function customer_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_customer($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function customer_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        
        $data = [
                'nama_customer'=> $this->input->post('nama_customer'),
                'kode_customer'=> $this->input->post('kode_customer'),
                'alamat'=> $this->input->post('alamat'),
                'nama_bank'=> $this->input->post('nama_bank'),
                'no_rekening'=> $this->input->post('no_rekening'),
                'atas_nama'=> $this->input->post('atas_nama'),
                'kcp'=> $this->input->post('kcp'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ];
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('m_customer', $data);
        
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data customer berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data customer gagal disimpan');
        }
        redirect('Admin/customer');
    }

/** Supplier **/
    public function supplier()
    {
        $data['content']= "master/supplier";
        $data['supplier'] = $this->Model_master->group_supplier()->result();
        $data['data'] = $this->Model_master->get_supplier()->result();
        $this->load->view('layout', $data);
    }

    function supplier_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $data = [
                    'nama_supplier'=> $this->input->post('nama_supplier'),
                    'alamat'=> $this->input->post('alamat'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id,
                ];
       
        $this->db->insert('m_supplier', $data); 
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data supplier berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data supplier gagal disimpan');
        }
        redirect('Admin/supplier');       
    }
    
    function supplier_delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('m_supplier');            
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data supplier berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data supplier gagal dihapus');
        }
        redirect('Admin/supplier');
    }
    
    function supplier_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_supplier($id)->row_array(); 

        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function supplier_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        
        $data = [
                'nama_supplier'=> $this->input->post('nama_supplier'),
                'alamat' => $this->input->post('alamat'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ];
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('m_supplier', $data);
        
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data supplier berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data supplier gagal disimpan');
        }
        redirect('Admin/supplier');
    }

/** Group Supplier **/
    public function group_supplier()
    {
        $data['content']= "master/group_supplier";
        $data['data'] = $this->Model_master->group_supplier()->result();
        $this->load->view('layout', $data);
    }

    function group_supplier_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $data = [
                    'nama_group_supplier'=> $this->input->post('nama_group_supplier'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id,
                ];
       
        $this->db->insert('m_group_supplier', $data); 
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data group_supplier berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data group_supplier gagal disimpan');
        }
        redirect('Admin/group_supplier');       
    }
    
    function group_supplier_delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('m_group_supplier');            
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data group_supplier berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data group_supplier gagal dihapus');
        }
        redirect('Admin/group_supplier');
    }
    
    function group_supplier_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_group_supplier($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function group_supplier_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        
        $data = [
                'nama_group_supplier'=> $this->input->post('nama_group_supplier'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ];
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('m_group_supplier', $data);
        
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data group_supplier berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data group_supplier gagal disimpan');
        }
        redirect('Admin/group_supplier');
    }

/** Bongkar Muat **/
    public function bongkar_muat()
    {
        $data['content']= "master/bongkar_muat";
        $data['data'] = $this->Model_master->bongkar_muat()->result();
        $this->load->view('layout', $data);
    }

    function bongkar_muat_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $data = [
                    'nama_bongkar_muat'=> $this->input->post('nama_bongkar_muat'),
                    'harga' => $this->input->post('harga'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id,
                ];
       
        $this->db->insert('m_bongkar_muat', $data); 
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data bongkar_muat berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data bongkar_muat gagal disimpan');
        }
        redirect('Admin/bongkar_muat');       
    }
    
    function bongkar_muat_delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('m_bongkar_muat');            
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data bongkar_muat berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data bongkar_muat gagal dihapus');
        }
        redirect('Admin/bongkar_muat');
    }
    
    function bongkar_muat_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_bongkar_muat($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function bongkar_muat_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        
        $data = [
                'nama_bongkar_muat'=> $this->input->post('nama_bongkar_muat'),
                'harga' => $this->input->post('harga'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ];
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('m_bongkar_muat', $data);
        
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data bongkar_muat berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data bongkar_muat gagal disimpan');
        }
        redirect('Admin/bongkar_muat');
    }

/** Users **/
    public function users()
    {
        $data['content']= "master/users";
        $data['data'] = $this->Model_master->users()->result();
        $data['roles'] = $this->Model_master->roles()->result();
        $this->load->view('layout', $data);
    }

    function users_save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $data = [
                    'username'=> $this->input->post('username'),
                    'name'=> $this->input->post('name'),
                    'id_roles'=> $this->input->post('roles'),
                    'password'=> password_hash('admin', PASSWORD_BCRYPT),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id,
                ];
       
        $this->db->insert('users', $data); 
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data user berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data user gagal disimpan');
        }
        redirect('Admin/users');       
    }
    
    function users_delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('users');            
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data user berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data user gagal dihapus');
        }
        redirect('Admin/users');
    }
    
    function users_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->get_users($id)->row_array(); 
        
        header('Content-Type: application/json');
        echo json_encode($data);       
    }
    
    function users_update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();
        
        $data = [
                'username'=> $this->input->post('username'),
                'name'=> $this->input->post('name'),
                'id_roles'=> $this->input->post('roles'),
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ];
        
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('users', $data);
        
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data user berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data user gagal disimpan');
        }
        redirect('Admin/users');
    }

    function change_password()
    {
        $data['content']= "master/change_password";
        $this->load->view('layout', $data);
    }

    function update_password(){
        $user_id    = $this->session->userdata('user_id');
        $user_name  = $this->session->userdata('username');
        $post_data  = $this->input->post('data');
        $isi_data   = explode("^", $post_data);
        
        $old_password = $isi_data[0];
        $new_password = $isi_data[1];
        $tanggal = date('Y-m-d H:i:s');
        
        $this->load->model('Model_user');
        $cek = $this->Model_user->doLogin($user_name, $old_password);
        if($cek){
            $data = array(
                'password'=> password_hash($new_password, PASSWORD_BCRYPT),
                'modified_at'=> $tanggal,
            );
            
            $this->db->where('id', $user_id);
            $this->db->update('users', $data);
            
            $url = "SUKSES";
        }else{
            $url = "SALAH";
        }
        header('Content-Type: application/json');
        echo json_encode($url);
    }

/** Numberings **/
    function numbering(){
        $data['content']= "master/numberings";
        $data['data'] = $this->Model_master->list_numbering()->result();
        $this->load->view('layout', $data);
    }
    
    function cek_number(){
        $code = $this->input->post('data');
        $cek_data = $this->Model_master->cek_numbering($code)->row_array();
        $return_data = ($cek_data)? "ADA": "TIDAK ADA";

        header('Content-Type: application/json');
        echo json_encode($return_data);
    }
    
    function number_save(){        
        $data = array(
            'prefix'=> $this->input->post('prefix'),
            'date_info'=> ($this->input->post('date_info')=="on")? 1: 0,
            'padding'=> $this->input->post('padding'),
            'prefix_separator'=> $this->input->post('prefix_separator'),
            'date_separator'=> $this->input->post('date_separator')
        );
        
        $this->db->insert('m_numberings', $data); 
        $this->session->set_flashdata('sukses', 'Data berhasil disimpan');
        redirect('Admin/numbering');
    }
    
    function number_delete(){
        $id = $this->uri->segment(3);
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('m_numberings');            
        }
        $this->session->set_flashdata('sukses', 'Data berhasil dihapus');
        redirect('Admin/numbering');
    }
    
    function number_edit(){
        $id = $this->input->post('id');
        $data = $this->Model_master->show_numbering($id)->row_array();
        if($data['date_info']==1){
            $data['date_info'] = true;
        }else{
            $data['date_info'] = false;
        }
        
        header('Content-Type: application/json');
        echo json_encode($data);        
    }
    
    function number_update(){        
        $data = array(
                'prefix'=> $this->input->post('prefix'),
                'date_info'=> ($this->input->post('date_info')=="on")? 1: 0,
                'padding'=> $this->input->post('padding'),
                'prefix_separator'=> $this->input->post('prefix_separator'),
                'date_separator'=> $this->input->post('date_separator')
            );
        #echo "<pre>"; die(var_dump($this->input->post()));
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('m_numberings', $data);
        
        $this->session->set_flashdata('sukses', 'Data berhasil disimpan');
        redirect('Admin/numbering');
    }
}