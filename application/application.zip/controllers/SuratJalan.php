<?php

class SuratJalan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('user_logged') === null) redirect(site_url('login'));
        // if($this->session->userdata('id_roles') == 3) redirect(site_url('NoAccess'));
        $this->load->model('Model_master');
        $this->load->model('Model_sj');
    }

    public function index()
    {
        $data['content']= "surat_jalan/index";
        $data['data'] = $this->Model_sj->sj_list()->result();
        $data['supplier'] = $this->Model_master->get_supplier()->result();
        $data['group_supplier'] = $this->Model_master->group_supplier()->result();
        $data['customer'] = $this->Model_master->customer()->result();
        $this->load->view('layout', $data);
    }

    function list_sj() {
        $this->load->model('Model_finance');
        $ids = $this->input->post('id_supplier');
        $idc = $this->input->post('id_customer');
        $gs = $this->input->post('id_gs');
        $s = $this->input->post('startDate');
        $e = $this->input->post('endDate');
        $arr = [
            'supplier' => $ids,
            'cust' => $idc,
            'gs' => $gs,
            'start' => $s,
            'end' => $e
        ];

        $list = $this->Model_finance->get_datatables($arr,'list_sj');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $action = '';
            $row = array();
            $row[] = $no.".";
            $row[] = $item->no_surat_jalan;
            $row[] = date('d-m-Y', strtotime($item->tanggal));
            $row[] = $item->nama_supplier;
            $row[] = $item->nama_group_supplier;
            $row[] = $item->kode_customer;
                if($item->status==0){
                  $status = '<div class="bg-secondary"><span>Draft</span></div>'; 
                }elseif($item->status==1){
                  if($item->flag>0){
                    $status = '<div class="bg-navy"><span>Sudah Dibayar</span></div>';
                  }else{
                    $status = '<div class="bg-success"><span>Approved</span></div>';
                  }
                }elseif($item->status==2){
                  $status = '<div class="bg-navy"><b>Finished</b></div>';
                }elseif($item->status==9){
                  $status = '<div class="bg-danger color-palette"><span>Rejected</span></div>';
                }
            $row[] = $status;
                if($item->id_invoice==0){
                  $status_inv = '<div class="bg-secondary">Belum ada Invoice</div>';
                }else{
                  $status_inv = '<div class="bg-navy">Sudah ada Invoice</div>';
                }
            $row[] = $status_inv;
                if($item->status==0){
                  $action .= '<a class="btn btn-info btn-sm" href="'.site_url().'SuratJalan/edit/'.$item->id.'" ><i class="fa fa-edit"></i> Edit</a>';
                  $action .= '<a class="btn btn-danger btn-sm" href="'.site_url().'SuratJalan/delete/'.$item->id.'" onclick="return confirm(\'Anda yakin menghapus data ini?\');"><i class="fa fa-trash"></i> Delete</a> |';
                }
                  $action .= '<a class="btn btn-primary btn-sm" href="'.site_url().'SuratJalan/view/'.$item->id.'" ><i class="fa fa-file-alt"></i> View</a>';
                if($item->status!=0){
                  $action .= '<a class="btn btn-dark btn-sm" href="'.site_url().'SuratJalan/print_sj/'.$item->id.'" target="_blank"><i class="fa fa-print"></i> Print</a>';
                }  
            $row[] = $action;

            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    public function add()
    {
        $data['content']= "surat_jalan/add";
        $data['supplier'] = $this->Model_master->get_supplier()->result();
        if($this->session->userdata('id_roles') == 3){
            $data['customer'] = $this->Model_master->get_customer(5)->row_array();
            $data['group_supplier'] = $this->Model_master->get_group_supplier(12)->row_array();
        }else{
            $data['customer'] = $this->Model_master->customer()->result();
            $data['group_supplier'] = $this->Model_master->group_supplier()->result();
        }
        // $data['bongkar_muat'] = $this->Model_master->bongkar_muat()->result();
        $this->load->view('layout', $data);
    }

    public function edit()
    {
        $id = $this->uri->segment(3);

        $data['content']= "surat_jalan/edit";
        $data['h'] = $this->Model_sj->get_sj($id)->row_array();

        // $data['supplier'] = $this->Model_master->get_supplier_by_group()->result();
        $data['group_supplier'] = $this->Model_master->group_supplier()->result();
        $data['supplier'] = $this->Model_master->get_supplier()->result();
        // $data['customer'] = $this->Model_master->customer()->result();
        $data['bongkar_muat'] = $this->Model_master->bongkar_muat()->result();
        $data['barang'] = $this->Model_master->get_barang_customer($data['h']['id_customer'])->result();
        $data['details'] = $this->Model_sj->detail_sj($id)->row_array();
        $this->load->view('layout', $data);
    }

    public function getSupplier()
    {
        $id = $this->input->post('id');
        $data = $this->Model_master->get_supplier_by_group($id)->result();
        echo json_encode($data);
    }

    function save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $this->db->trans_start();
        if($this->input->post('supplier')==0){
            if(!empty($this->input->post('supplier_baru'))){
                $this->db->insert('m_supplier', [
                    'nama_supplier'=>strtoupper($this->input->post('supplier_baru')),
                    'created_at'=>$tanggal,
                    'created_by'=>$user_id
                ]);
                $supplier_id = $this->db->insert_id();
            }else{
                $this->session->set_flashdata('gagal', 'Data surat jalan gagal disimpan, Nama Supplier Baru belum diisi!');
                redirect('SuratJalan\add');
            }
        }else{
            $supplier_id = $this->input->post('supplier');
        }

        $code = $this->Model_master->getNumbering('FT-YAP', $tgl_input);
        $data = array(
            'no_surat_jalan'=> $code,
            'tanggal'=> $tgl_input,
            'id_supplier'=>$supplier_id,
            'no_tbt'=>$this->input->post('no_tbt'),
            'id_customer'=>$this->input->post('customer'),
            'id_group_supplier'=>$this->input->post('group_supplier'),
            'jenis_kendaraan'=>strtoupper($this->input->post('jenis_kendaraan')),
            'no_kendaraan'=>strtoupper($this->input->post('no_kendaraan')),
            'ppn'=>$this->input->post('ppn'),
            'no_tbt'=>$this->input->post('no_tbt'),
            'keterangan'=>strtoupper($this->input->post('keterangan')),
            'status'=>0,
            'created_at'=> $tanggal,
            'created_by'=> $user_id
        );
        $this->db->insert('t_sj', $data);
        $sj_id = $this->db->insert_id();
        if($this->db->trans_complete()){
            redirect('SuratJalan/edit/'.$sj_id);
        }else{
            $this->session->set_flashdata('gagal', 'Data surat jalan gagal disimpan, silahkan dicoba kembali!');
            redirect('SuratJalan');  
        }
    }

    function save_detail(){
        $user_id = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $bonus = $this->input->post('bonus');

        $return_data = array();
        if(empty($bonus)){
            $bonus = 0;
        }

        $this->db->insert('t_sj_details', $var = array(
            'id_sj'=>$this->input->post('id'),
            'id_jb'=>$this->input->post('id_jb'),
            'bruto'=>$this->input->post('bruto'),
            'potongan'=>$this->input->post('potongan'),
            'netto'=>$this->input->post('netto'),
            'id_harga'=>$this->input->post('id_harga'),
            'harga'=>$this->input->post('harga')+$bonus,
            'bonus'=>$bonus,
            'total'=> str_replace(',', '',$this->input->post('total'))
        ));
        $reff = $this->db->insert_id();

        $encode_data = json_encode($var);
        $this->db->insert('logs', [
            'jenis'=>'add',
            'tabel'=>'t_sj_detail',
            'reff'=>$reff,
            'json'=>$encode_data,
            'created_at'=>$tanggal,
            'created_by'=>$user_id
        ]);

        if($this->db->trans_complete()){
            $return_data['status']= "sukses";
        }else{
            $return_data['status']= "error";
            $return_data['message']= "Gagal menambahkan item detail!";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    function view(){
        $id = $this->uri->segment(3);

        $data['content']= "surat_jalan/view";
        $data['h'] = $this->Model_sj->get_sj_match($id)->row_array();
        $data['lb'] = $this->Model_master->get_supplier($data['h']['id_supplier'])->row_array();
        $data['list_data'] = $this->Model_sj->get_sj_detail($id)->result();
        $data['bank'] = $this->Model_master->bank()->result();
        if($data['h']['status']!=0){
            $data['pembayaran'] = $this->Model_sj->get_sj_pembayaran($id)->result();
        }
        if($data['h']['id_invoice']!=0){
            $data['invoice'] = $this->Model_sj->get_sj_invoice($id)->result();
        }
        //var_dump($data['list_data']);die();
        $this->load->view('layout', $data);
    }

    function approve_sj(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $id = $this->input->post('id');
        $id_supplier = $this->input->post('id_supplier');
        $grand_total = $this->input->post('grand_total');
        $nilai_deposit = str_replace(',', '',$this->input->post('nilai_deposit'));
        $nilai_bayar = 0;
        $tanggal_lunas = null;
        $flag_matching = 0;

        $this->db->trans_start();

        // $data = $this->Model_sj->get_nilai_sj($id)->row_array();
        // if($nilai_deposit>0){
        //     $this->db->insert('f_spl_deposit', [
        //         'jenis'=> 1,
        //         'id_supplier'=> $id_supplier,
        //         'tanggal'=> $tgl_input,
        //         'nilai'=> $nilai_deposit,
        //         'id_sj'=> $id,
        //         'created_at'=> $tanggal,
        //         'created_by'=> $user_id
        //     ]);

        // //Potong Deposit
        //     $deposit_id = $this->db->insert_id();
        //     $this->db->insert('f_match_detail',[
        //         'id_match'=> $deposit_id,
        //         'jenis_pmb'=> 1,//Deposit
        //         'id_sj'=>$id,
        //         'sj_bayar'=>$nilai_deposit
        //     ]);
        // }

        if($this->input->post('jenis_lb')==1){
            $nilai_lb = str_replace(',', '',$this->input->post('nilai_lb'));
            if($nilai_lb > 0){
                $this->db->insert('f_spl_lebihbayar', [
                    'jenis'=> 1,
                    'id_supplier'=> $id_supplier,
                    'tanggal'=> $tgl_input,
                    'nilai'=> $nilai_lb,
                    'id_sj'=> $id,
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id
                ]);
                $lb_id = $this->db->insert_id();

                $this->db->insert('f_match_detail',[
                    'id_match'=> $lb_id,
                    'jenis_pmb'=> 3,//Lebih Bayar Keluar
                    'id_sj'=>$id,
                    'sj_bayar'=>$nilai_lb
                ]);
            }
        }else{
            $nilai_lb = 0;
        }

        if($this->input->post('denda_1')>0){
            $flag_denda = 0;
        }else{
            $flag_denda = 1;
        }
        if($this->input->post('denda_2')>0){
            $flag_denda_2 = 0;
        }else{
            $flag_denda_2 = 1;
        }
        #Update SJ
        $this->db->where('id', $id);
        $this->db->update('t_sj', array(
            'status'=> 1,
            'nilai'=> $this->input->post('grand_total'),
            'nilai_potong'=> $nilai_deposit+$nilai_lb,
            'nilai_tiket'=> $this->input->post('nilai_tiket'),
            'flag_denda'=> $flag_denda,
            'flag_denda_2'=> $flag_denda_2,
            'modified_at'=> $tanggal,
            'modified_by'=>$user_id
        ));
        if($nilai_deposit>0){
            $this->db->insert('f_spl_deposit', [
                'jenis'=> 1,
                'id_supplier'=> $id_supplier,
                'tanggal'=> $tgl_input,
                'nilai'=> $nilai_deposit,
                'id_sj'=> $id,
                'created_at'=> $tanggal,
                'created_by'=> $user_id
            ]);

            $deposit_id = $this->db->insert_id();
            $this->db->insert('f_match_detail',[
                'id_match'=> $deposit_id,
                'jenis_pmb'=> 1,//Deposit
                'id_sj'=>$id,
                'sj_bayar'=>$nilai_deposit
            ]);
        }

        //Potong Lebih Bayar
        if($this->input->post('jenis_lb')==1){
            $nilai_lb = str_replace(',', '',$this->input->post('nilai_lb'));
            if($nilai_lb > 0){
                $this->db->insert('f_spl_lebihbayar', [
                    'jenis'=> 1,
                    'id_supplier'=> $id_supplier,
                    'tanggal'=> $tgl_input,
                    'nilai'=> $nilai_lb,
                    'id_sj'=> $id,
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id
                ]);
                $lb_id = $this->db->insert_id();

                $this->db->insert('f_match_detail',[
                    'id_match'=> $lb_id,
                    'jenis_pmb'=> 3,//Lebih Bayar Keluar
                    'id_sj'=>$id,
                    'sj_bayar'=>$nilai_lb
                ]);
            }
        }else{
            $nilai_lb = 0;
        }

        $get = $this->Model_master->get_supplier($id_supplier)->row_array();
        $this->db->where('id',$id_supplier);
        $this->db->update('m_supplier',[
            'nilai'=> $get['nilai']-$nilai_deposit,
            'lebihbayar'=> $get['lebihbayar']-$nilai_lb,
            'modified_at'=> $tanggal,
            'modified_by'=> $user_id
        ]);

        //Langsung Bayar
        if($this->input->post('langsung_bayar')==1){
            $flag_matching = 1;
            $nilai_bayar = $grand_total-$nilai_deposit-$nilai_lb;
            $tanggal_lunas = $this->input->post('tanggal_bayar');

            $code = $this->Model_master->getNumbering('MATCH', $tanggal_lunas);
            $data = array(
                'no_matching' => $code,
                'tanggal' => $tanggal_lunas,
                'id_supplier' => $id_supplier,
                'status' => 1,
                'keterangan' => 'BAYAR LANGSUNG',
                'created_at' => $tanggal,
                'created_by' => $user_id
            );

            $this->db->insert('f_match', $data);
            $id_match_bayar = $this->db->insert_id();

            $data = array(
                'id_match'=>$id_match_bayar,
                'jenis_pmb'=>0,
                'id_sj'=>$id,
                'sj_bayar'=>$nilai_bayar
            );
            $this->db->insert('f_match_detail', $data);

            $code_uk = $this->Model_master->getNumbering('UK', $tanggal_lunas);
            $this->db->insert('f_uang_keluar',[
                'no_uang_keluar'=>$code_uk,
                'id_supplier'=>$id_supplier,
                'status'=>1,
                'jenis'=>1,
                'id_matching'=>$id_match_bayar,
                'tanggal'=>$tanggal_lunas,
                'jenis_pembayaran' => $this->input->post('jenis_pmb_id'),
                'rekening_tujuan' => $this->input->post('rekening_tujuan'),
                'id_bank' => $this->input->post('bank'),
                'nominal' => $nilai_bayar,
                'created_at'=> $tanggal,
                'created_by'=>$user_id
            ]);
        }elseif(($nilai_deposit+$nilai_lb)==$grand_total){
            $flag_matching = 1;
        }
        // echo $grand_total;die();
        //Update SJ
        $this->db->where('id', $id);
        $this->db->update('t_sj', array(
            'status'=> 1,
            'nilai'=> $grand_total,
            'nilai_potong'=> $nilai_deposit+$nilai_lb,
            'nilai_bayar'=>$nilai_bayar,
            'tanggal_lunas'=>$tanggal_lunas,
            'flag'=>$flag_matching,
            'modified_at'=> $tanggal,
            'modified_by'=>$user_id
        ));

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Surat Jalan berhasil diapprove');
        }else{
            $this->session->set_flashdata('gagal', 'Data Surat Jalan gagal diapprove');
        }
        redirect('SuratJalan/index');
    }

    function open_sj(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $id = $this->input->post('id');

        $this->db->trans_start();
        if($id!=0){
            #Update status SPB
            $this->db->where('id', $id);
            $this->db->update('t_sj', array(
                'status'=> 0,
                'nilai'=> 0,
                'nilai_bayar'=> 0,
                'nilai_potong'=> 0,
                'nilai_tiket'=> 0,
                'flag_denda'=> 0,
                'flag_denda_2'=> 0,
                'modified_at'=> $tanggal,
                'modified_by'=>$user_id
            ));

            $this->load->model('Model_finance');
            $dps = $this->Model_finance->get_deposit_sj($id)->row_array();
            $lb = $this->Model_finance->get_lb_sj($id)->row_array();
            $get = $this->Model_master->get_supplier($dps['id_supplier'])->row_array();

            $this->db->where('id_sj',$id);
            $this->db->delete('f_spl_deposit');

            $this->db->where('jenis_pmb', 1);
            $this->db->where('id_sj',$id);
            $this->db->delete('f_match_detail');

            $this->db->where('id_sj',$id);
            $this->db->delete('f_spl_lebihbayar');

            $this->db->where('jenis_pmb', 3);
            $this->db->where('id_sj',$id);
            $this->db->delete('f_match_detail');

            $this->db->where('id',$dps['id_supplier']);
            $this->db->update('m_supplier',[
                'nilai'=> $get['nilai'] + $dps['nilai'],
                'lebihbayar'=> $get['lebihbayar'] + $lb['nilai']
            ]);
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Surat Jalan berhasil diopen');
        }else{
            $this->session->set_flashdata('gagal', 'Data Surat Jalan gagal diopen');
        }
        redirect('SuratJalan/view/'.$id);
    }

    function load_detail_html(){
        $id = $this->input->post('id');
        $tabel = "";
        $no = 2;
        $this->load->model('Model_master');

        $this->load->Model('Model_sj');
        $myDetail = $this->Model_sj->load_detail($id)->result();
        foreach ($myDetail as $row) {
            $tabel .= '<tr>';
            $tabel .= '<td class="text-right">'.($no-1).'</td>';
            $tabel .= '<td><label id="lbl_barang_'.$no.'">'.$row->barang.'</label><input type="text" id="barang_'.$no.'" name="barang" class="form-control" value="'.$row->id_jb.'" style="display:none"></td>';
            $tabel .= '<td class="text-right"><label id="lbl_bruto_'.$no.'">'.number_format($row->bruto,2,',','.').'</label>';
            $tabel .= '<input type="text" id="bruto_'.$no.'" name="bruto" class="form-control" value="'.$row->bruto.'" style="display:none" onkeyup="hitung('.$no.')"></td>';
            $tabel .= '<td class="text-right"><label id="lbl_potongan_'.$no.'">'.number_format($row->potongan,2,',','.').'</label>';
            $tabel .= '<input type="text" id="potongan_'.$no.'" name="potongan" class="form-control" '
                . ' value="'.$row->potongan.'" style="display:none" onkeyup="hitung('.$no.')" readonly>';
            $tabel .= '<td class="text-right"><label id="lbl_netto_'.$no.'">'.number_format($row->netto,2,',','.').'</label>';
            $tabel .= '<input type="text" id="netto_'.$no.'" name="netto" class="form-control" value="'.$row->netto.'" style="display:none"></td>';
            $tabel .= '<td class="text-right"><label id="lbl_harga_option_'.$no.'">'.number_format($row->harga,2,',','.').' ('.$row->tanggal.')</label>';
                $tabel .= '<select id="harga_option_'.$no.'" name="harga_option" class="form-control select2bs4" ';
                $tabel .= 'data-placeholder="Pilih..." style="margin-bottom:5px; display:none" onchange="get_total(this.value,'.$no.')">';
                $tabel .= '<option value=""></option>';
                $tabel .= '</select>';
                $tabel .= '<input type="hidden" id="harga_id_'.$no.'" name="harga_id_'.$no.'" value="'.$row->id_harga.'">';
                $tabel .= '<input type="hidden" id="harga_barang_'.$no.'" name="harga_barang_'.$no.'" value="'.$row->harga.'">';
            $tabel .= '</td>';
            $tabel .= '<td class="text-right"><label id="lbl_bonus_'.$no.'">'.number_format($row->bonus,2,',','.').'</label>';
            $tabel .= '<input type="text" id="bonus_'.$no.'" name="bonus" class="form-control" '
                . ' value="'.$row->bonus.'" style="display:none" onkeyup="hitung('.$no.')">';
            $tabel .= '</td>';
            $tabel .= '<td class="text-right"><label id="lbl_sub_total_'.$no.'">'.number_format($row->total,2,',','.').'</label>';
            $tabel .= '<input type="text" id="sub_total_'.$no.'" name="sub_total" class="form-control" '
                . ' value="'.number_format($row->total,2,'.',',').'" style="display:none" readonly>';
            $tabel .= '</td>';
            
            $tabel .= '<td style="text-align:center;">';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-circle btn-primary'
                    . '" onclick="editDetail('.$row->id_jb.','.$row->id_harga.','.$no.');" style="margin-top:5px" id="btnEdit_'.$no.'"> '
                    . '<i class="fa fa-edit"></i> Edit &nbsp; </a>';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-circle btn-success'
                    . '" onclick="updateDetail('.$row->id.','.$no.');" style="margin-top:5px; display:none" id="btnUpdate_'.$no.'"> '
                    . '<i class="fa fa-save"></i> Update </a>';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-circle btn-danger'
                    . '" onclick="hapusDetail('.$row->id.');" style="margin-top:5px"> '
                    . '<i class="fa fa-trash"></i> Delete </a>';
            $tabel .= '</td>';
            $tabel .= '</tr>';
            $no++;
        }
        $data['no'] = $no;
        $data['tabel'] = $tabel;
        header('Content-Type: application/json');
        echo json_encode($data); 
    }
    
    function delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();

        $msg_status = 'sukses';
        $msg = 'Data Faktur berhasil di hapus';

        if(!empty($id)){
            $sj = $this->Model_sj->get_sj($id)->row_array();
            if($this->session->userdata('id_roles')==3){
                if($sj['created_by']==$this->session->userdata('user_id')){
                    $this->db->where('id', $id);
                    $this->db->update('t_sj',[
                        'del'=>1
                    ]);
                }else{
                    $msg_status = 'gagal';
                    $msg = 'Anda tidak dapat akses untuk menghapus faktur '.$sj['no_surat_jalan'];
                }
            }else{
                $this->db->where('id', $id);
                $this->db->delete('t_sj');

                $this->db->where('id_sj', $id);
                $this->db->delete('t_sj_details');
            }
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata($msg_status, $msg);
        }else{
            $this->session->set_flashdata($msg_status, $msg);
        }
        redirect('SuratJalan/index');
    }

    function update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $id = $this->input->post('id');
        
        $this->db->trans_start();

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('t_sj', [
            'no_surat_jalan'=>$this->input->post('no_surat_jalan'),
            'tanggal'=>$this->input->post('tanggal'),
            'status'=>0,
            'id_supplier'=>$this->input->post('supplier'),
            'id_group_supplier'=>$this->input->post('group_supplier'),
            'jenis_kendaraan'=>strtoupper($this->input->post('jenis_kendaraan')),
            'no_kendaraan'=>strtoupper($this->input->post('no_kendaraan')),
            'no_tbt'=>$this->input->post('no_tbt'),
            'bonus'=>$this->input->post('bonus'),
            'denda'=>(int)$this->input->post('denda_1')+(int)$this->input->post('denda_2'),
            'denda_1'=>$this->input->post('denda_1'),
            'denda_2'=>$this->input->post('denda_2'),
            'id_obm'=>$this->input->post('bongkar_muat'),
            'ppn'=>$this->input->post('ppn'),
            'bb_cash'=>$this->input->post('bb_cash'),
            'tiket'=>$this->input->post('tiket'),
            'keterangan'=>strtoupper($this->input->post('keterangan')),
            'modified_by'=>$user_id,
            'modified_at'=>$tanggal
        ]);

        if($this->input->post('already_insert')==0){
            //Insert Details
            $bonus = $this->input->post('bonus');

            $return_data = array();
            if(empty($bonus)){
                $bonus = 0;
            }

            $this->db->insert('t_sj_details', $var = array(
                'id_sj'=>$this->input->post('id'),
                'id_jb'=>$this->input->post('id_jb'),
                'bruto'=>$this->input->post('bruto'),
                'potongan'=>$this->input->post('potongan'),
                'netto'=>$this->input->post('netto'),
                'id_harga'=>$this->input->post('id_harga'),
                'harga'=>$this->input->post('harga')+$bonus,
                'bonus'=>$bonus,
                'total'=> str_replace(',', '',$this->input->post('total'))
            ));
            $reff = $this->db->insert_id();

            $encode_data = json_encode($var);
            $this->db->insert('logs', [
                'jenis'=>'add',
                'tabel'=>'t_sj_details',
                'reff'=>$reff,
                'json'=>$encode_data,
                'created_at'=>$tanggal,
                'created_by'=>$user_id
            ]);
        }else{
            $return_data = array();
            if(empty($bonus)){
                $bonus = 0;
            }

            $var = [
                'id_jb'=>$this->input->post('id_jb'),
                'bruto'=>$this->input->post('bruto'),
                'potongan'=>$this->input->post('potongan'),
                'netto'=>$this->input->post('netto'),
                'id_harga'=>$this->input->post('id_harga'),
                'harga'=>$this->input->post('harga')+$bonus,
                'bonus'=>$bonus,
                'total'=> str_replace(',', '',$this->input->post('total'))
            ];

            $this->db->where('id_sj', $id);
            $this->db->update('t_sj_details', $var);
            
            $encode_data = json_encode($var);
            $this->db->insert('logs', [
                'jenis'=>'update',
                'tabel'=>'t_sj_details',
                'reff'=>$id,
                'json'=>$encode_data,
                'created_at'=>$tanggal,
                'created_by'=>$user_id
            ]);
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Surat Jalan berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data Surat Jalan gagal disimpan');
        }
        redirect('SuratJalan/view/'.$this->input->post('id'));
    }

    function update_detail(){
        $this->load->model('Model_sj');
        $id = $this->input->post('id');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $cek = $this->Model_sj->list_sj_detail($id)->result();
        $bonus = $this->input->post('bonus');

        $this->db->trans_start();

        $return_data = array();
        if(empty($bonus)){
            $bonus = 0;
        }

        $var = [
            'id_jb'=>$this->input->post('id_jb'),
            'bruto'=>$this->input->post('bruto'),
            'potongan'=>$this->input->post('potongan'),
            'netto'=>$this->input->post('netto'),
            'id_harga'=>$this->input->post('id_harga'),
            'harga'=>$this->input->post('harga')+$bonus,
            'bonus'=>$bonus,
            'total'=> str_replace(',', '',$this->input->post('total'))
        ];

        $this->db->where('id', $id);
        $this->db->update('t_sj_details', $var);
        
        $encode_data = json_encode($var);
        $this->db->insert('logs', [
            'jenis'=>'update',
            'tabel'=>'t_sj_detail',
            'reff'=>$id,
            'json'=>$encode_data,
            'created_at'=>$tanggal,
            'created_by'=>$user_id
        ]);
        
        if($this->db->trans_complete()){
            $return_data['status']= "sukses";
            $return_data['message'] = "Berhasil Mengupdate data!";
        }else{
            $return_data['status']= "error";
            $return_data['message']= "Gagal mengupdate detail! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    public function delete_detail()
    {
        $this->load->model('Model_sj');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $id = $this->input->post('id');

        $this->db->trans_start();

        $return_data = array();
        $cek = $this->Model_sj->list_sj_detail($id)->result();
        $this->db->where('id', $id);
        $this->db->delete('t_sj_details');

        $encode_data = json_encode($cek);
        $this->db->insert('logs', [
            'jenis'=>'delete',
            'tabel'=>'t_sj_detail',
            'reff'=>$this->input->post('id'),
            'json'=>$encode_data,
            'created_at'=>$tanggal,
            'created_by'=>$user_id
        ]);

        if($this->db->trans_complete()){
            $return_data['status']= "sukses";
        }else{
            $return_data['status']= "error";
            $return_data['message']= "Gagal menghapus item! Silahkan coba kembali";
        }           
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    public function print_sj()
    {
        $id = $this->uri->segment(3);
        if($id){        
            $this->load->model('Model_sj');
            $this->load->helper('tanggal_indo');
            // $data['h']  = $this->Model_sj->show_header_sj($id)->row_array();
            $data['h'] = $this->Model_sj->get_sj_match($id)->row_array();
            $data['details'] = $this->Model_sj->get_sj_detail($id)->result();
            $data['pembayaran'] = $this->Model_sj->get_sj_pembayaran_deposit($id)->result();

            $this->load->view('surat_jalan/print_sj', $data);
        }
    }

    /** Matching Surat Jalan */

    public function MatchingSJ()
    {
        $this->load->model('Model_finance');
        $data['roles'] = $this->session->userdata('id_roles');
        $data['matching'] = $this->Model_finance->get_inv_supplier()->result();
        $data['content'] = "surat_jalan/matching_sj";
        $this->load->view('layout', $data);
    }

    public function addMatchingSJ()
    {
        $this->load->model('Model_master');
        $data['supplier'] = $this->Model_master->get_supplier()->result();
        $data['content'] = "surat_jalan/add_match";
        $this->load->view('layout', $data);
    }

    public function save_match_sj()
    {
        $user_id   = $this->session->userdata('user_id');
        $tanggal   = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $this->db->trans_start();
        $code = $this->Model_master->getNumbering('MATCH', $tgl_input);
        $data = array(
            'no_matching' => $code,
            'tanggal' => $tgl_input,
            'id_supplier' => $this->input->post('supplier'),
            'status' => 0,
            'keterangan' => strtoupper($this->input->post('keterangan')),
            'created_at' => $tanggal,
            'created_by' => $user_id
        );

        $this->db->insert('f_match', $data);
        $id = $this->db->insert_id();
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Matching berhasil dibuat');
        }else{
            $this->session->set_flashdata('gagal', 'Data Matching gagal dibuat');
        }
        redirect('SuratJalan/view_matching/'.$id); 
    }


    public function view_matching()
    {
        $id = $this->uri->segment(3);
        
        $this->load->model('Model_finance');
        $data['h'] = $this->Model_finance->matching_header($id)->row_array();
        if($data['h']['status']==0){
            $data['content'] = "surat_jalan/view_matching";
        }else{
            $data['cek_inv'] = $this->Model_finance->count_inv($id)->row_array();
            $data['details'] = $this->Model_finance->view_matching_details($id)->result();
            $data['content'] = "surat_jalan/view_matching2";
        }
        $data['bank'] = $this->Model_master->bank()->result();

        $this->load->view('layout', $data);
    }

    public function delete_matching()
    {
        $id = $this->uri->segment(3);
        $user_id = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');

        $this->db->trans_start();
        if(!empty($id)){
            if($id!=0){
                $this->load->model('Model_sj');
                $data = $this->Model_sj->list_match_detail($id)->result();
                // print_r($data);die();
                foreach ($data as $value) {
                    if($value->jenis_pmb==0){
                        $sj = $this->Model_sj->get_nilai_sj($value->id_sj)->row_array();
                        $nilai_sj = $sj['nilai_bayar']-$value->sj_bayar;
                        if($nilai_sj==0){
                            $flag = 0;
                        }else{
                            $flag = 1;
                        }
                        // echo $sj['nilai_bayar'].'-'.$sj['nilai_potong'].'-'.$value->sj_bayar;die();

                        $this->db->where('id',$value->id_sj);
                        $this->db->update('t_sj', [
                            'nilai_bayar'=> $nilai_sj,
                            'tanggal_lunas'=>'0000-00-00',
                            'flag'=>$flag,
                            'modified_at'=> $tanggal,
                            'modified_by'=>$user_id
                        ]);
                    }elseif($value->jenis_pmb==2){
                        //Lebih Bayar
                        $this->db->where('id',$value->id_sj);
                        $this->db->delete('f_spl_lebihbayar');

                        $get = $this->Model_master->get_supplier($value->id_supplier)->row_array();
                        $this->db->where('id',$value->id_supplier);
                        $this->db->update('m_supplier',[
                            'lebihbayar'=> $get['lebihbayar']-$value->sj_bayar,
                            'modified_at'=> $tanggal,
                            'modified_by'=> $user_id
                        ]);
                    }
                }

                $this->db->where('id_match',$id);
                $this->db->delete('f_match_detail');

                $this->db->delete('f_match', ['id' => $id]);

                $this->db->delete('f_uang_keluar', ['id_matching' => $id]);
            }
        }

        if($this->db->trans_complete()) {
            $this->session->set_flashdata('sukses', 'Data Matching berhasil dihapus');
            redirect('SuratJalan/MatchingSJ');
        }
    }

    public function load_list_sj()
    {
        $id = $this->input->post('id');
        $idm = $this->input->post('id_match');

        $tabel = "";
        $total_invoice = 0;
        $no    = 1;
        $this->load->model('Model_sj');
        $myDetail = $this->Model_sj->load_sj_full($id,$idm)->result();
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center;width:5%;">'.$no.'</td>';
            $tabel .= '<td>'.$row->no_surat_jalan.'</td>';
            $tabel .= '<td style="text-align:right;">'.number_format($row->total,2,',','.').'</td>';
            $tabel .= '<td style="text-align:center">';
            if($row->count==0){
                $tabel .= '<a href="javascript:;" class="btn btn-warning btn-sm" onclick="input_sj('.$row->id.');" style="margin-top:2px; margin-bottom:2px;" id="addInv"><i class="fa fa-plus"></i> Tambah </a>';
            }else{
                $tabel .= 'Added!';
            }            
            $tabel .= '</td>';
            $no++;
            $total_invoice += $row->total;
        }
        $tabel .= '<tr>';
        $tabel .= '<td style="text-align:right;" colspan="2"><strong>Total Harga </strong></td>';
        $tabel .= '<td style="text-align:right;">';
        $tabel .= '<strong>'.number_format($total_invoice,2,',','.').'</strong>';
        $tabel .= '</td>';
        $tabel .= '<td></td>';
        $tabel .= '</tr>';

        header('Content-Type: application/json');
        echo json_encode($tabel); 
    }

    function get_list_sj() {
        $id = $this->input->post('id');
        $idm = $this->input->post('idm');
        $arr_params = [
            'id' => $id,
            'idm' => $idm
        ];
        $this->load->model('Model_finance');
        $list = $this->Model_finance->get_datatables($arr_params,'sj_list');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $row = array();
            $row[] = $no.".";
            $row[] = $item->no_surat_jalan;
            $row[] = $item->nama_barang;
            $row[] = '('.$item->no_kendaraan.')'.$item->jenis_kendaraan;
            $row[] = number_format($item->netto,2,',','.');
            $row[] = number_format($item->total,2,',','.');
            // add html for action
            if($item->count==0){
                $row[] = '<a href="javascript:;" class="btn btn-warning btn-xs" onclick="input_sj('.$item->id.');" style="margin-top:2px; margin-bottom:2px;" id="addInv"><i class="fa fa-plus"></i> Tambah </a>';
            }else{
                $row[] = 'Added!';
            }            
            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    // "recordsTotal" => $this->Model_finance->count_all($id),
                    // "recordsFiltered" => $this->Model_finance->count_filtered($id),
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    public function get_data_sj()
    {
        $id = $this->input->post('id');

        $this->load->model('Model_sj');
        $result= $this->Model_sj->get_data_sj($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function add_sj_match()
    {   
        $this->db->trans_start();
        if($this->input->post('sisa_sj')<=0){
            $flag_matching = 1;//sudah lunas
            $tanggal_lunas = $this->input->post('tanggal');
        }else{
            $flag_matching = 0;
            $tanggal_lunas = '0000-00-00';
        }


        $get_inv = $this->Model_sj->get_data_sj($this->input->post('id_sj'))->row_array();
        $nilai_bayar = $get_inv['nilai_bayar'] + str_replace(',', '', $this->input->post('nominal_bayar'));

        $this->db->where('id',$this->input->post('id_sj'));
        $this->db->update('t_sj', array(
            'nilai_bayar'=>$nilai_bayar,
            'tanggal_lunas'=>$tanggal_lunas,
            'flag'=>$flag_matching
        ));

        $data = array(
            'id_match'=>$this->input->post('id_modal'),
            'jenis_pmb'=>0,
            'id_sj'=>$this->input->post('id_sj'),
            'sj_bayar'=>str_replace(',', '', $this->input->post('nominal_bayar'))
        );
        $this->db->insert('f_match_detail', $data);

        if($this->db->trans_complete()){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan item barang! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function load_data_sj()
    {
        $id = $this->input->post('id');

        $tabel = "";
        $total_invoice = 0;
        $no    = 1;
        $this->load->model('Model_sj');
        $myDetail = $this->Model_sj->load_sj_match($id)->result();
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center">'.$no.'</td>';

            $total_invoice += $row->sj_bayar;
            $tabel .= '<td>'.$row->no_surat_jalan.'</td>';
            $tabel .= '<td style="text-align:right;">'.number_format($row->sj_bayar,2,',','.').'</td>';
            $tabel .= '<td style="text-align:center">';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-primary" onclick="view_sj('.$row->id.');" style="margin-top:2px; margin-bottom:2px;" id="delSJ"><i class="fa fa-eye"></i> View </a>';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-danger" onclick="delSJ('.$row->id.','.$row->id_sj.');" style="margin-top:2px; margin-bottom:2px;margin-left:2px;" id="delSJ"><i class="fa fa-trash"></i> Delete </a></td>';
            $no++;
        }
        $tabel .= '<tr>';
        $tabel .= '<td style="text-align:right;" colspan="2"><strong>Total Nilai SJ </strong></td>';
        $tabel .= '<td style="text-align:right;">';
        $tabel .= '<strong>'.number_format($total_invoice,2,',','.').'</strong>';
        $tabel .= '<input type="hidden" id="load_total_sj" name="total_sj" value="'.$total_invoice.'">';
        $tabel .= '</td>';
        $tabel .= '<td id="view_total_sj"></td>';
        $tabel .= '</tr>';
        $data['tabel'] = $tabel;
        $data['total_sj'] = $total_invoice;

        header('Content-Type: application/json');
        echo json_encode($data); 
    }

    function get_data_match_detail() {
        $id = $this->input->post('id');
        $this->load->model('Model_finance');
        $list = $this->Model_finance->get_datatables($id,'sj_data_match');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $row = array();
            $row[] = $no.".";
            $row[] = $item->no_surat_jalan;
            $row[] = $item->nama_barang;
            $row[] = '('.$item->no_kendaraan.')'.$item->jenis_kendaraan;
            $row[] = number_format($item->netto,2,',','.');
            $row[] = number_format($item->total,2,',','.');
            // add html for action
            $row[] = '
                <a href="javascript:;" class="btn btn-xs btn-primary" onclick="view_sj('.$item->id.');" style="margin-top:2px; margin-bottom:2px;" id="delSJ"><i class="fa fa-eye"></i> View </a>
                <a href="javascript:;" class="btn btn-xs btn-danger" onclick="delSJ('.$item->id.','.$item->id_sj.');" style="margin-top:2px; margin-bottom:2px;margin-left:2px;" id="delSJ"><i class="fa fa-trash"></i> Delete </a></td>';
            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    public function view_data_sj()
    {
        $id = $this->input->post('id');

        $this->load->model('Model_sj');
        $result= $this->Model_sj->view_sj_match($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function del_sj_match()
    {
        $return_data = array();
        $id = $this->input->post('id');

        $this->db->trans_start();

        $this->load->model('Model_sj');
        $get = $this->Model_sj->view_sj_match($id)->row_array();
        $nilai_bayar = $get['nilai_bayar'] - $get['sj_bayar'];

        // if($get['jenis_trx']==0){
            $this->db->where('id',$get['id_sj']);
            $this->db->update('t_sj', array(
                'nilai_bayar'=>$nilai_bayar,
                'tanggal_lunas'=>'0000-00-00',
                'flag'=>0
            ));
        // }

        $this->db->where('id', $this->input->post('id'));
        $this->db->delete('f_match_detail');

        if($this->db->trans_complete()){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan item barang! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function approve_match_sj()
    {
        // print_r($this->input->post());die();
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $id_match = $this->input->post('id');
        $id_supplier = $this->input->post('id_supplier');
        $nilai_lb = $this->input->post('nilai_lb');

        $this->db->trans_start();

        $total_invoice = 0;
        $myDetail = $this->Model_sj->load_sj_match($id_match)->result();
        foreach ($myDetail as $row){
            $total_invoice += $row->sj_bayar;
        }
        if($total_invoice>0){

            #Update status F_Match
            $this->db->where('id', $id_match);
            $this->db->update('f_match', array(
                'status'=> 1,
                'modified_at'=> $tanggal,
                'modified_by'=>$user_id
            ));

            if($nilai_lb>0){
                $total_invoice += $nilai_lb;

                $code = $this->Model_master->getNumbering('LB', $tgl_input);
                $this->db->insert('f_spl_lebihbayar', [
                    'nomor'=> $code,
                    'jenis'=> 0,//masuk
                    'id_supplier'=> $id_supplier,
                    'id_match'=> $id_match,
                    'tanggal'=> $tgl_input,
                    'nilai'=> $nilai_lb,
                    'keterangan'=> $this->input->post('keterangan'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id
                ]);
                $id_lb = $this->db->insert_id();

                $get = $this->Model_master->get_supplier($id_supplier)->row_array();
                $this->db->where('id',$id_supplier);
                $this->db->update('m_supplier',[
                    'lebihbayar'=> $get['lebihbayar']+$nilai_lb,
                    'modified_at'=> $tanggal,
                    'modified_by'=> $user_id
                ]);

                $this->db->insert('f_match_detail',[
                    'id_match'=> $id_match,
                    'jenis_pmb'=> 2,//Lebih Bayar IN
                    'id_sj'=> $id_lb,
                    'sj_bayar'=> $nilai_lb
                ]);
            }

            $code = $this->Model_master->getNumbering('UK', $tgl_input);
            $this->db->insert('f_uang_keluar',[
                'no_uang_keluar'=>$code,
                'id_supplier'=>$id_supplier,
                'status'=>1,
                'jenis'=>1,
                'id_matching'=>$id_match,
                'tanggal'=>$tgl_input,
                'jenis_pembayaran' => $this->input->post('jenis_id'),
                'rekening_tujuan' => $this->input->post('rekening_tujuan'),
                'id_bank' => $this->input->post('bank'),
                'nominal' => $total_invoice,
                'created_at'=> $tanggal,
                'created_by'=>$user_id
            ]);

            if($this->db->trans_complete()){
                $this->session->set_flashdata('sukses', 'Data Matching berhasil diapprove');
            }else{
                $this->session->set_flashdata('gagal', 'Data Matching gagal diapprove');
            }
            redirect('SuratJalan/MatchingSJ');
        }else{
            $this->session->set_flashdata('gagal', 'Data Matching tidak boleh kosong');
            redirect('SuratJalan/view_matching/'.$id_match);
        }
    }

    function cek_total_match(){
        $id = $this->input->post('id');
        $this->load->model('Model_sj');
        $total_invoice = 0;
        $myDetail = $this->Model_sj->load_sj_match($id)->result();
        foreach ($myDetail as $row){
            $total_invoice += $row->sj_bayar;
        }
        $data['total_format'] = number_format($total_invoice,2,',','.');
        $data['total'] = $total_invoice;
        
        header('Content-Type: application/json');
        echo json_encode($data); 
    }

    public function OSSJ()
    {
        $this->load->model('Model_sj');
        $data['roles'] = $this->session->userdata('id_roles');
        $data['matching'] = $this->Model_sj->list_sj_belum_lunas()->result();
        $data['bank'] = $this->Model_master->bank()->result();
        $data['supplier'] = $this->Model_master->get_supplier()->result();
        $data['group_supplier'] = $this->Model_master->group_supplier()->result();
        $data['customer'] = $this->Model_master->customer()->result();
        $data['content'] = "surat_jalan/ossj";
        $this->load->view('layout', $data);
    }


    function get_sj_belum_lunas() {
        $this->load->model('Model_finance');
        $ids = $this->input->post('id_supplier');
        $idc = $this->input->post('id_customer');
        $gs = $this->input->post('id_gs');
        $s = $this->input->post('startDate');
        $e = $this->input->post('endDate');
        $arr = [
            'supplier' => $ids,
            'customer' => $idc,
            'gs' => $gs,
            'start' => $s,
            'end' => $e
        ];

        $list = $this->Model_finance->get_datatables($arr,'get_sj_belum_lunas');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $row = array();
            $row[] = $no.".";
            $row[] = $item->no_surat_jalan;
            $row[] = date('d-m-Y', strtotime($item->tanggal));
            $row[] = $item->nama_supplier;
            $row[] = $item->nama_group_supplier;
            $row[] = $item->nama_customer;
            $row[] = '('.$item->no_kendaraan.')'.$item->jenis_kendaraan;
            $row[] = number_format($item->nilai_sisa,2,',','.');
            // add html for action
            $row[] = '<a href="javascript:;" class="btn btn-success btn-xs" onclick="input_sj('.$item->id.');" style="margin-top:2px; margin-bottom:2px;"><i class="fa fa-plus"></i> Bayar </a>';
            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    public function add_sj_match_single()
    {   
        $user_id   = $this->session->userdata('user_id');
        $tanggal   = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $sisa_sj = str_replace(',', '', $this->input->post('sisa_sj'));
        $flag_lebih = 0;
        $this->db->trans_start();
        if($sisa_sj<=0){
            $flag_matching = 1;//sudah lunas
            $tanggal_lunas = $tgl_input;
        }else{
            $flag_matching = 0;
            $tanggal_lunas = '0000-00-00';
        }

        $id_supplier = $this->input->post('id_supplier');
        $nominal = str_replace(',', '', $this->input->post('nominal_bayar'));
        $get_inv = $this->Model_sj->get_data_sj($this->input->post('id_sj'))->row_array();
        $nilai_bayar = $get_inv['nilai_bayar'] + $nominal;

        $this->db->where('id',$this->input->post('id_sj'));
        $this->db->update('t_sj', array(
            'nilai_bayar'=>$nilai_bayar,
            'tanggal_lunas'=>$tanggal_lunas,
            'flag'=>$flag_matching
        ));

        $code = $this->Model_master->getNumbering('MATCH', $tgl_input);
        $data = array(
            'no_matching' => $code,
            'tanggal' => $tgl_input,
            'id_supplier' => $id_supplier,
            'status' => 1,
            'keterangan' => 'BAYAR LANGSUNG',
            'created_at' => $tanggal,
            'created_by' => $user_id
        );

        $this->db->insert('f_match', $data);
        $id_match = $this->db->insert_id();

        $data = array(
            'id_match'=>$id_match,
            'jenis_pmb'=>0,
            'id_sj'=>$this->input->post('id_sj'),
            'sj_bayar'=>$nominal
        );
        $this->db->insert('f_match_detail', $data);

            if($sisa_sj<0){
                $nilai_lb = $sisa_sj*-1;

                $code = $this->Model_master->getNumbering('LB', $tgl_input);
                $this->db->insert('f_spl_lebihbayar', [
                    'nomor'=> $code,
                    'jenis'=> 0,//masuk
                    'id_supplier'=> $id_supplier,
                    'id_match'=> $id_match,
                    'tanggal'=> $tgl_input,
                    'nilai'=> $nilai_lb,
                    'keterangan'=> $this->input->post('keterangan'),
                    'created_at'=> $tanggal,
                    'created_by'=> $user_id
                ]);
                $id_lb = $this->db->insert_id();

                $get = $this->Model_master->get_supplier($id_supplier)->row_array();
                $this->db->where('id',$id_supplier);
                $this->db->update('m_supplier',[
                    'lebihbayar'=> $get['lebihbayar']+$nilai_lb,
                    'modified_at'=> $tanggal,
                    'modified_by'=> $user_id
                ]);

                $this->db->insert('f_match_detail',[
                    'id_match'=> $id_match,
                    'jenis_pmb'=> 2,//Lebih Bayar IN
                    'id_sj'=> $id_lb,
                    'sj_bayar'=> $nilai_lb
                ]);
            }

        $code_uk = $this->Model_master->getNumbering('UK', $tgl_input);
        $this->db->insert('f_uang_keluar',[
            'no_uang_keluar'=>$code_uk,
            'id_supplier'=>$id_supplier,
            'status'=>1,
            'jenis'=>1,
            'id_matching'=>$id_match,
            'tanggal'=>$tgl_input,
            'jenis_pembayaran' => $this->input->post('jenis_id'),
            'rekening_tujuan' => $this->input->post('rekening_tujuan'),
            'id_bank' => $this->input->post('bank'),
            'nominal' => $nominal,
            'created_at'=> $tanggal,
            'created_by'=>$user_id
        ]);

        if($this->db->trans_complete()){
            $return_data['message_type']= "sukses";
        }else{
            $return_data['message_type']= "error";
            $return_data['message']= "Gagal menambahkan item barang! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function histori_faktur()
    {
        $data['content']= "surat_jalan/histori_faktur";
        $data['data'] = $this->Model_sj->histori_sj_list()->result();
        $this->load->view('layout', $data);
    }

    public function delete_all_55693953b81a93e51dfed1c79bfabda(){
        $this->db->trans_start();

        $loop = $this->Model_sj->histori_sj_list()->result();

        foreach ($loop as $key => $value) {
            $this->db->where('id_sj', $value->id);
            $this->db->delete('t_sj_details');

            $this->db->where('id', $value->id);
            $this->db->delete('t_sj');
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data surat jalan berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data surat jalan gagal dihapus, silahkan kontak admin!');
        }
        redirect('SuratJalan/histori_faktur');
    }
}