<?php

class Laporan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('user_logged') === null) redirect(site_url('login'));
    }

    public function index_lap()
    {
        $data['content']= "laporan/laporan_pengiriman_cust";
        $this->load->model("Model_sj");
        $data['data'] = $this->Model_sj->sj_list()->result();
        $this->load->view('layout', $data);
    }

    public function print_laporan_rekap_cust()
    {
        $s = date('Y-m-d', strtotime($_GET['ts']));
        $e = date('Y-m-d', strtotime($_GET['te']));
        $this->load->helper('tanggal_indo');
        $this->load->model('Model_sj');

        $data['detailLaporan'] = $this->Model_sj->print_laporan_rekap_cust($s,$e)->result();
        $this->load->view('laporan/print_laporan_rekap_cust', $data);
    }

    public function LHarga(){
        $data['content'] = "laporan/harga";
        $this->load->model("Model_master");
        $data['customer'] = $this->Model_master->customer()->result();
        $this->load->view('layout', $data);
    }

    public function print_laporan_harga_cust()
    {
        $c = $_GET['c'];
        $this->load->helper('tanggal_indo');
        $this->load->model('Model_laporan');
        $this->load->model('Model_master');

        $data['customer'] = $this->Model_master->get_customer($c)->row_array();
        $data['tgl_jam'] = array_reverse($this->Model_laporan->print_laporan_harga_cust($c)->result());
        $jb = $this->Model_master->get_barang_customer($c)->result();
        $details = [];
        // foreach ($jb as $key => $v) {
        //     $details[$key]['nama_barang'] = $v->nama_barang;
        //     $no = 0;
        //     foreach ($data['tgl_jam'] as $key => $j) { $no++;
        //         $dat = $this->Model_laporan->get_tgl_harga($v->id,$c,$j->tanggal)->row_array();
        //         $details[$key]['l'.$no] = (!empty($dat))? $dat['harga']:0;
        //     }
        // }
        $details = new stdClass;
        $details->data = array();
        foreach ($jb as $key => $v) {
            $detail = new stdClass;
            $detail->nama_barang = $v->nama_barang;
            $no = 0;
            foreach ($data['tgl_jam'] as $key => $j) { $no++;
                $dat = $this->Model_laporan->get_tgl_harga($v->id,$c,$j->tanggal)->row_array();
                $detail->{'l'.$no} = (!empty($dat))? $dat['harga']:0;
            }
            $details->data[] = $detail;
        }
        // print_r($details);die();
        $data['details'] = $details->data;
        $this->load->view('laporan/print_laporan_rekap_cust', $data);
    }
}