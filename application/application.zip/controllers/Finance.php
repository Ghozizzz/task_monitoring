<?php

class Finance extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('user_logged') === null) redirect(site_url('login'));
        $this->load->model(['Model_master'], ['Model_sj']);
    }

    /** Deposit **/
    public function deposit()
    {
        $this->load->model('Model_master');
        $data['list_data'] = $this->Model_master->get_supplier()->result();
        $data['content'] = "finance/deposit";
        $this->load->view('layout', $data);
    }

    public function deposit_detail()
    {
        $id = $this->uri->segment(3);
        $this->load->model('Model_finance');
        $data['list_data'] = $this->Model_finance->list_deposit_detail($id)->result();
        $data['content'] = "finance/deposit_detail";
        $this->load->view('layout', $data);
    }

    public function addDeposit()
    {
        $this->load->model('Model_master');
        $data['bank'] = $this->Model_master->bank()->result();
        $data['supplier'] = $this->Model_master->get_supplier()->result();
        $data['content'] = "finance/add_deposit";
        $this->load->view('layout', $data);
    }

    public function save_deposit()
    {
        $user_id   = $this->session->userdata('user_id');
        $tanggal   = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $id_supplier = $this->input->post('supplier');
        $nominal = str_replace(',', '', $this->input->post('nominal'));

        $this->db->trans_start();

        $this->load->model("Model_master");

        $code = $this->Model_master->getNumbering('DEPOSIT', $tgl_input); 
        if($code){
            $this->db->insert('f_spl_deposit', [
                'nomor'=> $code,
                'jenis'=> 0,
                'id_supplier'=> $id_supplier,
                'tanggal'=> $tgl_input,
                'nilai'=> $nominal,
                'keterangan'=> $this->input->post('keterangan'),
                'created_at'=> $tanggal,
                'created_by'=> $user_id
            ]);

            $get = $this->Model_master->get_supplier($id_supplier)->row_array();
            $this->db->where('id',$id_supplier);
            $this->db->update('m_supplier',[
                'nilai'=> $get['nilai']+$nominal,
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ]);
        }else{
            $this->session->set_flashdata('gagal', 'Penomoran Belum di SET-UP');
            redirect('Finance/deposit');
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Deposit berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data Deposit gagal disimpan');
        }
        redirect('Finance/deposit');
    }

    function delete_deposit(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){

            $user_id   = $this->session->userdata('user_id');
            $tanggal   = date('Y-m-d H:i:s');
            $this->load->model('Model_finance');
            $dps = $this->Model_finance->get_deposit($id)->row_array();
            $get = $this->Model_master->get_supplier($dps['id_supplier'])->row_array();

            $this->db->where('id', $id);
            $this->db->delete('f_spl_deposit');

            $this->db->where('id',$dps['id_supplier']);
            $this->db->update('m_supplier',[
                'nilai'=> $get['nilai']-$dps['nilai'],
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ]);
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Deposit berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data Deposit gagal dihapus');
        }
        redirect('Finance/deposit');
    }

    /** Invoice **/
    public function Invoice()
    {
        $this->load->model('Model_finance');
        $data['inv'] = $this->Model_finance->list_invoice()->result();
        $data['customer'] = $this->Model_master->customer()->result();
        $data['content'] = "finance/invoice";
        $this->load->view('layout', $data);
    }


    function list_invoice() {
        $this->load->model('Model_finance');
        $idc = $this->input->post('id_customer');
        $m = $this->input->post('matching');
        $s = $this->input->post('startDate');
        $e = $this->input->post('endDate');
        $arr = [
            'cust' => $idc,
            'm' => $m,
            'start' => $s,
            'end' => $e
        ];

        $list = $this->Model_finance->get_datatables($arr,'list_invoice_index');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $action = '';
            $row = array();
            $row[] = $no.".";
            $row[] = $item->no_invoice;
            $row[] = $item->nama_customer;
            $row[] = date('d-m-Y', strtotime($item->tanggal));
            $row[] = number_format($item->nilai_invoice,2,',','.');
                if($item->status==0){
                  $status = '<td class="bg-secondary"><span>Draft</span></td>'; 
                }elseif($item->status==1){
                  $status = '<td class="bg-success"><span>Approved</span></td>';
                }elseif($item->status==2){
                  $status = '<td class="bg-info"><b>Settle</b></td>';
                }elseif($item->status==9){
                  $status = '<td class="bg-danger color-palette"><span>Rejected</span></td>';
                }
            $row[] = $status;

                if($item->flag==0){
                  $status_inv = '<div class="bg-danger">Belum Lunas</div>';
                }else{
                  $status_inv = '<div class="bg-success">Sudah Lunas</div>';
                }
            $row[] = $status_inv;


                if($item->status != 1 && $item->flag == 0){
                    $action .= '<a class="btn btn-danger btn-sm" href="'.site_url().'Finance/delete_invoice/'.$item->id.'" onclick="return confirm(\'Anda yakin menghapus data ini?\');"><i class="fa fa-trash"></i> Delete</a> |';
                }
                if($item->status==0){
                    $action .= '<a class="btn btn-info btn-sm" href="'.base_url().'Finance/edit_invoice/'.$item->id.'" ><i class="fa fa-edit"></i> Edit</a>';
                 }
                if($item->status == 2){
                    $action .= '<a class="btn btn-info btn-sm" href="'.base_url().'Finance/qc_invoice/'.$item->id.'" ><i class="fa fa-edit"></i> Edit</a>';
                }
                    $action .= '<a class="btn btn-success btn-sm" href="'.base_url().'Finance/view_invoice/'. $item->id.'"><i class="fa fa-file"></i> View</a>';
                    $action .= '<a class="btn btn-primary btn-sm" href="'.base_url().'Finance/print_invoice/'. $item->id.'" target="_blank"><i class="fa fa-print"></i> Print</a>';
            $row[] = $action;

            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    public function addInvoice()
    {
        $this->load->model(['Model_finance'], ['Model_master']);
        $data['customer'] = $this->Model_master->customer()->result();
        $data['content'] = "finance/add_invoice";
        $this->load->view('layout', $data);
    }

    public function saveInvoice()
    {
        $user_id   = $this->session->userdata('user_id');
        $tanggal   = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $id_sj = $this->input->post('surat_jalan_id');
        $idc = $this->input->post('customer');
        $this->load->helper('tanggal_romawi');
        $code_front = bulan_romawi(date("m", strtotime($tgl_input)));
        $code_year = date("y", strtotime($tgl_input));

        $this->db->trans_start();
        $get = $this->Model_master->get_customer($idc)->row_array();
        $no_invoice = $code_front.'/'.$code_year.'/'.$this->input->post('no_invoice').'-'.$get['kode_customer'];

        $this->load->model('Model_finance');
        $cek = $this->Model_finance->get_no_invoice($no_invoice)->num_rows();
        if($cek==0){
            //Insert Invoice Header
            $data = array(
                'no_invoice'=> $no_invoice,
                'tanggal'=> $tgl_input,
                'id_customer' => $idc,
                'term_of_payment' => $this->input->post('term_of_payment'),
                'ppn'=>$this->input->post('ppn'),
                'bunga'=>$this->input->post('bunga'),
                'tanggal' =>$tgl_input,
                'keterangan' => strtoupper($this->input->post('keterangan')),
                'created_at'=> $tanggal,
                'created_by'=> $user_id
            );
            $this->db->insert('f_invoice', $data);
            $id_invoice = $this->db->insert_id();
        }else{
            $this->session->set_flashdata('gagal', 'Nomor Invoice sudah ada');
            redirect('Finance/addInvoice');
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Invoice berhasil Ditambahkan');
        }else{
            $this->session->set_flashdata('gagal', 'Data Invoice gagal Ditambahkan');
        }
        redirect('Finance/edit_invoice/'.$id_invoice);
    }

    public function edit_invoice()
    {
        $id = $this->uri->segment(3);

        $this->load->model('Model_finance');
        $this->load->model('Model_master');
        $data['h'] = $this->Model_finance->show_header_invoice($id)->row_array();
        $data['barang'] = $this->Model_master->get_barang_customer($data['h']['id_customer'])->result();
        if($data['h']['jenis_customer']==0){
            $view = "finance/edit_invoice";
        }else{
            $view = "finance/edit_invoice2";
        }

        $data['content'] = $view;

        if($data['h']['status']==0){
            $this->load->view('layout', $data);
        }else{
            $this->session->set_flashdata('gagal', 'Halaman tidak dapat di akses');
            redirect('Finance/invoice');
        }
    }

    public function view_invoice()
    {
        $id = $this->uri->segment(3);

        $this->load->model('Model_finance');
        $this->load->model('Model_sj');
        $data['h'] = $this->Model_finance->show_header_invoice($id)->row_array();
        $c = $data['h']['id_customer'];
        $jenis = $data['h']['jenis_customer'];
        if($c==5){//INDAHKIAT
            $view = "finance/view_invoice_indahkiat";
            $details = $this->Model_finance->get_inv_summary_view($id)->result();
            $data['tiket'] = $this->Model_finance->get_tiket_sj($id)->result();
            // $data['credit_memo'] = $this->Model_finance->get_inv_creditmemo2($id)->result();
        }elseif($c==6 || $c==7 || $c==9){//PINDO DELI or PELITA
            $view = "finance/view_invoice_pindodeli";
            $details = $this->Model_finance->get_inv_summary_view($id)->result();
            $data['credit_memo'] = $this->Model_finance->get_inv_creditmemo($id)->result();
        }elseif($c==8){
            $view = "finance/view_invoice_fajar";
            $details = $this->Model_finance->get_inv_summary_view_grouping($id)->result();
            $data['rekapan'] = $this->Model_finance->get_inv_summary_view_ordered($id)->result();
        }
        $data['content'] = $view;
        $data['list_data'] = $details;
        $data['list_denda'] = $this->Model_finance->get_inv_denda($id)->result();

        $data['list_obm'] = $this->Model_finance->group_obm_inv($id)->result();

        $this->load->view('layout', $data);
    }

    public function print_invoice()
    {
        $id = $this->uri->segment(3);

        $this->load->model('Model_finance');
        $this->load->helper('terbilang_helper');
        $this->load->helper('tanggal_indo');
        $data['h'] = $this->Model_finance->show_header_invoice($id)->row_array();
        $c = $data['h']['id_customer'];
        if($c==5){//INDAHKIAT
            $view = "finance/print_invoice_indahkiat";
            $details = $this->Model_finance->get_inv_summary_view($id)->result();
            $data['tiket'] = $this->Model_finance->get_tiket_sj($id)->result();
            $data['list_obm'] = $this->Model_finance->group_obm_inv($id)->result();
            $data['list_denda'] = $this->Model_finance->get_inv_denda_group($id)->result();
            $data['loop_obm'] = $this->Model_master->bongkar_muat()->result();
        }elseif($c==6 || $c==9){//PINDO DELI or PELITA
            $view = "finance/print_invoice_pindodeli";
            $details = $this->Model_finance->get_inv_summary_view($id)->result();
        }elseif($c==7){
            $view = "finance/print_invoice_papertech";
            $details = $this->Model_finance->get_inv_summary_view($id)->result();
        }elseif($c==8){
            $view = "finance/print_invoice_fajar";
            $details = $this->Model_finance->get_inv_summary_view_grouping($id)->result();
        }
        $data['details'] = $details;

        $this->load->view($view, $data);
    }

    public function print_invoice2()
    {
        $id = $this->uri->segment(3);

        $this->load->model('Model_finance');
        $this->load->helper('terbilang_helper');
        $this->load->helper('tanggal_indo');
        $data['h'] = $this->Model_finance->show_header_invoice($id)->row_array();
        $c = $data['h']['id_customer'];
        if($c==5){
            $view = "finance/print_invoice_indahkiat2";
            $details = $this->Model_finance->get_inv_ppn($id)->row_array();
        }elseif($c==6 || $c==9){//PINDO DELI or PELITA
            $view = "finance/print_invoice_pindodeli2";
            $details = $this->Model_finance->get_inv_creditmemo($id)->result();
        }elseif($c==7){//PAPERTECH
            $view = "finance/print_invoice_papertech2";
            $details = $this->Model_finance->get_inv_creditmemo($id)->result();
        }elseif($c==8){//FAJAR
            $view = "finance/print_invoice_fajar2";
            $details = $this->Model_finance->get_inv_summary_view_ordered($id)->result();
        }
        $data['details'] = $details;

        $this->load->view($view, $data);
    }

    public function delete_invoice(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('f_invoice');         

            $this->db->where('id_invoice', $id);
            $this->db->delete('f_invoice_detail');

            $this->load->model('Model_finance');
            $denda_loop = $this->Model_finance->get_inv_denda($id)->result();
            foreach($denda_loop as $row){
                $this->db->where('id',$row->id_sj);
                $this->db->update('t_sj',[
                    'flag_denda'=>0
                ]);
            }

            $this->db->where('id_invoice', $id);
            $this->db->delete('f_invoice_summary');

            $this->db->where('id_invoice', $id);
            $this->db->update('t_sj', [
                'id_invoice'=>0,
                'modified_at'=> $tanggal,
                'modified_by'=> $user_id
            ]);
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Invoice berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data Invoice gagal dihapus');
        }
        redirect('Finance/Invoice');
    }

    public function proceed_invoice()
    {
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s'); 
        $id =$this->input->post('id');

        $this->db->trans_start();

        $jenis = $this->input->post('jenis_customer');
        $this->load->model('Model_finance');
        $loop= $this->Model_finance->get_inv_detail($id,$jenis)->result();
        //jenis 0 detail, jenis 1 group
        foreach ($loop as $key => $value) {
            $sub_total = $value->netto*$value->harga;
            $this->db->insert('f_invoice_summary', [
                'id_invoice'=>$id,
                'id_sj'=>$value->id_sj,
                'id_jb'=>$value->id_jb,
                'bruto'=>$value->bruto,
                'netto'=>$value->netto,
                'harga'=>$value->harga,
                'sub_total'=>$sub_total
            ]);
        }

        $this->db->where('id', $id);
        $this->db->update('f_invoice', [
            'no_invoice'=> $this->input->post('no_invoice'),
            'tanggal'=> date('Y-m-d', strtotime($this->input->post('tanggal'))),
            'term_of_payment'=> $this->input->post('term_of_payment'),
            'keterangan'=> $this->input->post('keterangan'),
            'ppn'=> $this->input->post('ppn'),
            'bunga'=> $this->input->post('bunga'),
            'status'=> 2,
            'modified_at'=> $tanggal,
            'modified_by'=> $user_id
        ]);

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Invoice berhasil disimpan');
            redirect('Finance/qc_invoice/'.$id);
        }else{
            $this->session->set_flashdata('gagal', 'Data Invoice gagal disimpan');
            redirect('Finance/qc_invoice/'.$id);
        }
    }

    function back_edit_invoice(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $id = $this->input->post('id');
        $this->db->trans_start();

        $this->load->model('Model_finance');
        $denda_loop = $this->Model_finance->get_inv_denda($id)->result();
        foreach($denda_loop as $row){
            $this->db->where('id',$row->id_sj);
            $this->db->update('t_sj',[
                'flag_denda'=>0
            ]);
        }

        $this->db->where('id_invoice',$id);
        $this->db->delete('f_invoice_summary');

        #Update status SPB
        $this->db->where('id', $id);
        $this->db->update('f_invoice', array(
            'status'=> 0,
            'modified_at'=> $tanggal,
            'modified_by'=>$user_id
        ));

        $this->db->trans_complete();
        redirect('Finance/edit_invoice/'.$id);
    }

    public function qc_invoice()
    {
        $id = $this->uri->segment(3);

        $data['content'] = "finance/qc_invoice";
        $this->load->model('Model_finance');
        $this->load->model('Model_sj');
        $data['h'] = $this->Model_finance->show_header_invoice($id)->row_array();
        $jenis = $data['h']['jenis_customer'];
        $data['list_data'] = $this->Model_finance->get_inv_summary($id)->result();

        $this->load->view('layout', $data);
    }

    public function add_denda_invoice()
    {
        $id = $this->uri->segment(3);

        $data['content'] = "finance/add_denda_invoice";
        $this->load->model('Model_finance');
        $this->load->model('Model_sj');
        $data['h'] = $this->Model_finance->show_header_invoice($id)->row_array();

        $this->load->view('layout', $data);
    }

    public function update_invoice()
    {
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s'); 
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $id =$this->input->post('id');
        $jenis = $this->input->post('jenis_customer');

        $this->db->trans_start();

        $this->db->where('id', $id);
        $this->db->update('f_invoice', [
            'no_invoice'=> $this->input->post('no_invoice'),
            'tanggal'=> $tgl_input,
            'ppn'=> $this->input->post('ppn'),
            'status'=> 2,
            'modified_at'=> $tanggal,
            'modified_by'=> $user_id
        ]);

        $details = $this->input->post('details');
        foreach ($details as $key => $v) {
            $sub_total = $v['netto'] * $v['harga_jual'];
            $this->db->where('id', $v['id']);
            $this->db->update('f_invoice_summary', [
                'harga'=> $v['harga_jual'],
                'harga_manual'=> $v['harga_manual'],
                'sub_total'=> $sub_total,
                'adjustment'=> $v['adjustment']
            ]);
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Invoice berhasil disimpan');
            redirect('Finance/view_invoice/'.$id);
        }else{
            $this->session->set_flashdata('gagal', 'Data Invoice gagal disimpan');
            redirect('Finance/view_invoice/'.$id);
        }
    }

    public function load_list_sj()
    {
        $id = $this->input->post('id');

        $tabel = "";
        $total_netto = 0;
        $no    = 1;
        $this->load->model('Model_finance');
        $myDetail = $this->Model_finance->sj_customer_list($id)->result();
        foreach ($myDetail as $row){
            $tabel .= '<tr>';
            $tabel .= '<td style="text-align:center;width:5%;">'.$no.'</td>';
            $tabel .= '<td>'.$row->nama_barang.'</td>';
            $tabel .= '<td>('.$row->no_kendaraan.')'.$row->jenis_kendaraan.'</td>';
            $tabel .= '<td style="text-align:right;">'.number_format($row->netto,2,',','.').'</td>';
            $tabel .= '<td style="text-align:center">';
            $tabel .= '<a href="javascript:;" class="btn btn-success btn-sm" onclick="add_sj('.$row->id.');" style="margin-top:2px; margin-bottom:2px;" id="addInv"><i class="fa fa-plus"></i> Tambah </a>';
            $tabel .= '</td>';
            $no++;
            $total_netto += $row->netto;
        }
        $tabel .= '<tr>';
        $tabel .= '<td style="text-align:right;" colspan="3"><strong>Total Harga </strong></td>';
        $tabel .= '<td style="text-align:right;">';
        $tabel .= '<strong>'.number_format($total_netto,2,',','.').'</strong>';
        $tabel .= '</td>';
        $tabel .= '<td></td>';
        $tabel .= '</tr>';

        header('Content-Type: application/json');
        echo json_encode($tabel); 
    }

    public function get_data_sj()
    {
        $id = $this->input->post('id');

        $this->load->model('Model_finance');
        $result= $this->Model_finance->get_data_sj($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function get_data_denda()
    {
        $id = $this->input->post('id');

        $this->load->model('Model_finance');
        $result= $this->Model_finance->get_data_denda($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function get_jenis_denda()
    {
        $id = $this->input->post('id');
        $jenis = $this->input->post('jenis');

        $this->load->model('Model_finance');
        $result= $this->Model_finance->get_jenis_denda($id,$jenis)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function get_data_sj_group()
    {
        $id = $this->input->post('id');
        $id = implode(",",$id);

        $this->load->model('Model_finance');
        $data= $this->Model_finance->get_data_sj_group($id)->row_array();
        // print_r($this->db->error());die();
        if($data['count_barang']>1){
            $result['status']=9;
            $result['message']='Barang tidak boleh beda, Mohon cek kembali pilihan';
        }else{
            $result['status']=1;
            $result['data']=$data;
        }
        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function get_data_denda_group()
    {
        $id = $this->input->post('id');
        $id = implode(",",$id);

        $this->load->model('Model_finance');
        $result= $this->Model_finance->get_data_denda_group($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }

    /** Datatables Server Side **/
    function get_list_sj() {
        $id = $this->input->post('id');
        $s = $this->input->post('startDate');
        $e = $this->input->post('endDate');
        $id_jb = $this->input->post('barang');

        $arr = [
            'id' => $id,
            'id_jb' => $id_jb,
            's' => $s,
            'e' => $e
        ];

        $this->load->model('Model_finance');

        $list = $this->Model_finance->get_datatables($arr,'sj_list_di_inv');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $row = array();
            $row[] = $no.".";
            $row[] = $item->nama_barang;
            $row[] = $item->tanggal;
            $row[] = '('.$item->no_kendaraan.')'.$item->jenis_kendaraan;
            $row[] = number_format($item->netto,2,',','.');
            $row[] = number_format($item->harga,2,',','.');
            // add html for action
            $row[] = '<a href="javascript:;" class="btn btn-success btn-xs" onclick="add_sj('.$item->id.');" style="margin-top:2px; margin-bottom:2px;"><i class="fa fa-plus"></i> Tambah </a>';
            $row[] = '<input name="id_sj[]" value="'.$item->id.'" type="checkbox" class="cekbox">';
            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    // "recordsTotal" => $this->Model_finance->count_all($id),
                    // "recordsFiltered" => $this->Model_finance->count_filtered($id),
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    function get_list_denda_sj() {
        $id = $this->input->post('id');
        $s = $this->input->post('startDate');
        $e = $this->input->post('endDate');
        $arr = [];
        array_push($arr,$id);
        if(!empty($s)){
            array_push($arr,$s);
        }
        if(!empty($e)){
            array_push($arr,$e);
        }
        $this->load->model('Model_finance');

        $list = $this->Model_finance->get_datatables($arr,'denda_sj_list_di_inv');
        $data = array();
        // print_r($this->db->last_query());  die();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $row = array();
            $row[] = $no.".";
            $row[] = $item->no_surat_jalan;
            $row[] = $item->nomor;
            $row[] = $item->tanggal;
            $row[] = '('.$item->no_kendaraan.')'.$item->jenis_kendaraan;
            $row[] = number_format($item->harga,2,',','.');
            // add html for action
            $row[] = '<a href="javascript:;" class="btn btn-success btn-xs" onclick="add_sj('.$item->id.','.$item->jenis_denda.');" style="margin-top:2px; margin-bottom:2px;"><i class="fa fa-plus"></i> Tambah </a>';
            // $row[] = '<input name="id_sj[]" value="'.$item->id.'" type="checkbox" class="cekbox">';
            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    // "recordsTotal" => $this->Model_finance->count_all($id),
                    // "recordsFiltered" => $this->Model_finance->count_filtered($id),
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    function get_list_denda_inv() {
        $id = $this->input->post('id');
        $this->load->model('Model_finance');

        $list = $this->Model_finance->get_datatables($id,'list_denda_di_inv');
        $data = array();
        // print_r($this->db->last_query());  die();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $row = array();
            $row[] = $no.".";
            $row[] = $item->no_surat_jalan;
            $row[] = $item->nomor;
            $row[] = $item->tanggal;
            $row[] = '('.$item->no_kendaraan.')'.$item->jenis_kendaraan;
            $row[] = number_format($item->denda,2,',','.');
            // add html for action
            $row[] = '<a href="javascript:;" class="btn btn-danger btn-xs" onclick="delete_item('.$item->id.','.$item->id_sj.','.$item->jenis.');" style="margin-top:2px; margin-bottom:2px;"><i class="fa fa-trash"></i> Delete </a>';
            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    // "recordsTotal" => $this->Model_finance->count_all($id),
                    // "recordsFiltered" => $this->Model_finance->count_filtered($id),
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }
    /** End Datatables **/

    public function add_sj_inv()
    {   
        $this->db->trans_start();
        $id = $this->input->post('id_sj');
        $id_inv = $this->input->post('id_modal');
        $id_jenis = $this->input->post('id_jenis');//0 : satuan, 1 : checkbox
        $tanggal = date('Y-m-d h:i:s');

        $this->load->model('Model_sj');

        if($id_jenis==0){
            $loop = $this->Model_sj->get_sj_detail($id)->result();
        }else{
            $loop = $this->Model_sj->get_sj_detail_multiple($id)->result();
        }
            foreach ($loop as $key => $v) {
                $uid = null;
                if($id_jenis!=0){
                    $uid = date('Ymdhis');
                }

                $this->db->insert('f_invoice_detail', [
                    'id_invoice' => $id_inv,
                    'id_sj' => $v->id_sj,
                    'id_sj_detail' => $v->id,
                    'id_jb' => $v->id_jb,
                    'bruto' => $v->bruto,
                    'netto' => $v->netto,
                    'harga' => $this->input->post('harga_jual'),
                    'uid' => $uid,
                    'modified' => $tanggal
                ]);

                $this->db->where('id',$v->id_sj);
                $this->db->update('t_sj',[
                    'id_invoice'=>$id_inv
                ]);
            }

        if($this->db->trans_complete()){
            $return_data['message_type']= 1;
        }else{
            $return_data['message_type']= 0;
            $return_data['message']= "Gagal menambahkan sj! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function add_denda_inv()
    {   
        $this->db->trans_start();
        $id = $this->input->post('id_sj');
        $id_inv = $this->input->post('id_modal');
        $id_jenis = $this->input->post('id_jenis');//0 : satuan, 1 : checkbox
        $jenis_denda = $this->input->post('jenis_denda');
        $tanggal = date('Y-m-d h:i:s');

        $this->load->model('Model_sj');

        if($id_jenis==0){
            $loop = $this->Model_sj->get_sj_only($id)->result();
        }else{
            $loop = $this->Model_sj->get_sj_multiple($id)->result();
        }
            foreach ($loop as $key => $v) {
                if($jenis_denda==1){
                    $denda = $v->denda_1;
                    $this->db->where('id',$v->id);
                    $this->db->update('t_sj',[
                        'flag_denda'=>1
                    ]);
                }else{
                    $denda = $v->denda_2;
                    $this->db->where('id',$v->id);
                    $this->db->update('t_sj',[
                        'flag_denda_2'=>1
                    ]);
                }

                $this->db->insert('f_invoice_summary', [
                    'jenis' => $jenis_denda,//1: Denda, 2: Denda K3
                    'id_invoice' => $id_inv,
                    'id_sj' => $v->id,
                    'id_jb' => 0,
                    'harga' => $denda,
                    'sub_total' => $denda
                ]);

            }

        if($this->db->trans_complete()){
            $return_data['message_type']= 1;
        }else{
            $return_data['message_type']= 0;
            $return_data['message']= "Gagal menambahkan denda! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    // public function load_list_inv()
    // {
    //     $id = $this->input->post('id');

    //     $tabel = "";
    //     $total_netto = 0;
    //     $no    = 1;
    //     $this->load->model('Model_finance');
    //     $myDetail = $this->Model_finance->sj_inv_list($id)->result();
    //     foreach ($myDetail as $row){
    //         $tabel .= '<tr>';
    //         $tabel .= '<td style="text-align:center;width:5%;">'.$no.'</td>';
    //         $tabel .= '<td>'.$row->nama_barang.'</td>';
    //         $tabel .= '<td>('.$row->no_kendaraan.')'.$row->jenis_kendaraan.'</td>';
    //         $tabel .= '<td style="text-align:right;">'.number_format($row->netto,2,',','.').'</td>';
    //         $tabel .= '<td style="text-align:right;">'.number_format($row->harga,2,',','.').'</td>';
    //         $tabel .= '<td style="text-align:center">';
    //         $tabel .= '<a href="javascript:;" class="btn btn-danger btn-sm" onclick="delete_sj('.$row->id.');" style="margin-top:2px; margin-bottom:2px;" id="addInv"><i class="fa fa-trash"></i> Delete </a>';
    //         $tabel .= '</td>';
    //         $no++;
    //         $total_netto += $row->netto;
    //     }
    //     $tabel .= '<tr>';
    //     $tabel .= '<td style="text-align:right;" colspan="3"><strong>Total Harga </strong></td>';
    //     $tabel .= '<td style="text-align:right;">';
    //     $tabel .= '<strong>'.number_format($total_netto,2,',','.').'</strong>';
    //     $tabel .= '</td>';
    //     $tabel .= '<td></td>';
    //     $tabel .= '</tr>';

    //     header('Content-Type: application/json');
    //     echo json_encode($tabel); 
    // }

    function get_list_sj_inv() {
        $id = $this->input->post('id');
        $this->load->model('Model_finance');
        $list = $this->Model_finance->get_datatables($id,'inv_list_di_sj');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $row = array();
            $row[] = $no.".";
            $row[] = $item->nama_barang;
            $row[] = $item->tanggal;
            $row[] = '('.$item->no_kendaraan.')'.$item->jenis_kendaraan;
            $row[] = number_format($item->netto,2,',','.');
            $row[] = number_format($item->harga,2,',','.');
            // add html for action
            $row[] = '<a href="javascript:;" class="btn btn-danger btn-xs" onclick="delete_sj('.$item->id.');" style="margin-top:2px; margin-bottom:2px;"><i class="fa fa-trash"></i> Delete </a>';
            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    function get_list_sj_inv2() {
        $id = $this->input->post('id');
        $this->load->model('Model_finance');
        $list = $this->Model_finance->get_datatables($id,'inv_list_di_sj2');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $row = array();
            $row[] = $no.".";
            $row[] = $item->nama_barang;
            $row[] = number_format($item->bruto,2,',','.');
            $row[] = number_format($item->netto,2,',','.');
            $row[] = number_format($item->harga,2,',','.');
            $row[] = number_format($item->netto*$item->harga,2,',','.');
            // add html for action
            $row[] = '<a href="javascript:;" class="btn btn-danger btn-xs" onclick="delete_sj('.$item->uid.','.$id.');" style="margin-top:2px; margin-bottom:2px;"><i class="fa fa-trash"></i> Delete </a>';
            $data[] = $row;
        }
        $output = array(
                    "draw" => @$_POST['draw'],
                    "recordsTotal" => $list['count_all'],
                    "recordsFiltered" => $list['count_filtered'],
                    "data" => $data,
                );
        // output to json format
        echo json_encode($output);
    }

    public function delete_sj_inv()
    {   
        $this->db->trans_start();
        $id = $this->input->post('id');

        $this->db->where('id_sj', $id);
        $this->db->delete('f_invoice_detail');

        $this->db->where('id',$id);
        $this->db->update('t_sj',[
            'id_invoice'=>0
        ]);

        if($this->db->trans_complete()){
            $return_data['message_type']= 1;
        }else{
            $return_data['message_type']= 0;
            $return_data['message']= "Gagal menambahkan sj! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function delete_sj_inv2()
    {   
        $this->db->trans_start();
        $id = $this->input->post('id');
        $uid = $this->input->post('uid');
        $this->load->model('Model_finance');
        $list = $this->Model_finance->get_group_inv_detail($uid,$id)->result();
        // print_r($list);die();
        foreach ($list as $key => $row) {
            $this->db->where('id', $row->id);
            $this->db->delete('f_invoice_detail');

            $this->db->where('id', $row->id_sj);
            $this->db->update('t_sj',[
                'id_invoice'=>0
            ]);
        }

        if($this->db->trans_complete()){
            $return_data['message_type']= 1;
        }else{
            $return_data['message_type']= 0;
            $return_data['message']= "Gagal menambahkan sj! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function delete_item_inv()
    {   
        $this->db->trans_start();
        $id = $this->input->post('id');
        $id_sj = $this->input->post('id_sj');
        $jenis_denda = $this->input->post('jenis_denda');

        $this->db->where('id', $id);
        $this->db->delete('f_invoice_summary');

        if($jenis_denda==1){
            $this->db->where('id',$id_sj);
            $this->db->update('t_sj',[
                'flag_denda'=>0
            ]);
        }else{
            $this->db->where('id',$id_sj);
            $this->db->update('t_sj',[
                'flag_denda_2'=>0
            ]);
        }

        if($this->db->trans_complete()){
            $return_data['message_type']= 1;
        }else{
            $return_data['message_type']= 0;
            $return_data['message']= "Gagal menambahkan sj! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data); 
    }

    public function cek_no_invoice_update()
    {   
        $code = $this->input->post('no_invoice');

        $cek = $this->db->query("Select *from f_invoice where id = ".$this->input->post('id'))->row_array();
        if ($cek['no_invoice'] == $code) {
            $data['type'] = 'sukses';
        } else {
            $count = $this->db->query("Select count(id) as count from f_invoice where no_invoice = '".$code."'")->row_array();
            if($count['count']>0){
                $data['type'] = 'duplicate';
            }else{
                $data['type'] = 'sukses';
            }
        }
        
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    function get_sj_list(){ 
        $id = $this->input->post('id');
        $this->load->model('Model_finance');
        $data = $this->Model_finance->get_sj_list($id)->result();
        $arr_sj[0] = 'Silahkan Pilih ...';
        foreach ($data as $row) {
            $arr_sj[$row->id] = $row->no_surat_jalan;
        } 
        print form_dropdown('surat_jalan_id', $arr_sj);
    }

    public function get_customer_sj()
    {
        $id = $this->input->post('id');

        $this->load->model('Model_sj');
        $result= $this->Model_sj->sj_list($id)->row_array();

        header('Content-Type: application/json');
        echo json_encode($result);
    }

    public function save_detail()
    {
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $this->db->trans_start();

        $this->db->insert('f_invoice_detail', $var = array(
            'no_invoice'=>$this->input->post('no_invoice'),
            'id_jb'=>$this->input->post('id_jb'),
            'bruto'=>$this->input->post('bruto'),
            'potongan'=>$this->input->post('potongan'),
            'netto'=>$this->input->post('netto'),
            'id_harga_beli'=>$this->input->post('id_harga_beli'),
            'id_harga_jual'=>$this->input->post('id_harga_jual'),
            'total'=> str_replace(',', '',$this->input->post('total'))
        ));
        $reff = $this->db->insert_id();

        $encode_data = json_encode($var);
        $this->db->insert('logs', [
            'jenis'=>'add',
            'tabel'=>'f_invoice_detail',
            'reff'=>$reff,
            'json'=>$encode_data,
            'created_at'=>$tanggal,
            'created_by'=>$user_id
        ]);

        if($this->db->trans_complete()){
            $return_data['status']= "sukses";
        }else{
            $return_data['status']= "error";
            $return_data['message']= "Gagal menambahkan item detail!";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    function approve_inv(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $id = $this->input->post('id');

        $this->db->trans_start();

        #Update status SPB
        $this->db->where('id', $id);
        $this->db->update('f_invoice', array(
            'status'=> 1,
            'no_skbdn'=> $this->input->post('no_skbdn'),
            'no_ppn'=> $this->input->post('no_ppn'),
            'nilai_invoice'=> $this->input->post('grandtotal'),
            'modified_at'=> $tanggal,
            'modified_by'=>$user_id
        ));

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Invoice berhasil diapprove');
        }else{
            $this->session->set_flashdata('gagal', 'Data Invoice gagal diapprove');
        }
        redirect('Finance/invoice');
    }

    function open_inv(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $id = $this->input->post('id');

        $this->db->trans_start();

        #Update status SPB
        $this->db->where('id', $id);
        $this->db->update('f_invoice', array(
            'status'=> 2,
            'nilai_invoice'=> 0,
            'modified_at'=> $tanggal,
            'modified_by'=>$user_id
        ));

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Invoice berhasil di open');
        }else{
            $this->session->set_flashdata('gagal', 'Data Invoice gagal di open');
        }
        redirect('Finance/view_invoice/'.$id);
    }

    function RekapSupplier()
    {
        $this->load->model('Model_master');
        $data['content']= "finance/laporan_supplier";
        $data['gs'] = $this->Model_master->group_supplier()->result();
        $this->load->view('layout', $data);
    }

    function proses_rekap()
    {

		$bulan = $_GET['b'];
        $tahun = $_GET['t'];
        $group = $_GET['g'];
        $j = $_GET['j'];
        
        $this->load->helper('tanggal_indo');
        $this->load->model('Model_sj');
        
        $a = $tahun.'-'.$bulan.'-01';
        $data['time'] = date("M Y", strtotime($a));
        if ($j == 1) {
            $data['detailLaporan'] = $this->Model_sj->print_rekap_supplier($bulan,$tahun,0)->result();
        } else if ($j == 2) {
            $data['detailLaporan'] = $this->Model_sj->print_rekap_supplier_by_group($bulan,$tahun,$group)->result();
        }

        
        $this->load->view('finance/print_laporan_rekap_supplier', $data);
    }


    /** Uang Masuk */

    public function uang_masuk()
    {
        $this->load->model('Model_finance');
        $data['list_data'] = $this->Model_finance->list_um()->result();
        $data['content'] = "finance/uang_masuk";
        $this->load->view('layout', $data);
    }

    public function add_uang_masuk()
    {
        $this->load->model('Model_master');
        $data['bank'] = $this->Model_master->bank()->result();
        $data['customer'] = $this->Model_master->customer()->result();
        $data['content'] = "finance/add_uang_masuk";
        $this->load->view('layout', $data);
    }

    public function save_uang_masuk()
    {
        $user_id   = $this->session->userdata('user_id');
        $tanggal   = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $jenis = $this->input->post('jenis_id');
        $id_customer = $this->input->post('customer');
        $nominal = str_replace(',', '', $this->input->post('nominal'));

        $this->db->trans_start();

        $this->load->model("Model_master");
        $code = $this->Model_master->getNumbering('UM', $tgl_input); 
        if($code){
            $this->db->insert('f_uang_masuk', [
                'no_uang_masuk' => $code,
                'id_customer' => $id_customer,
                'status' => 0,
                'tanggal' => $tgl_input,
                'id_bank' => $this->input->post('bank'),
                'jenis_pembayaran' => $jenis,
                'rekening_pengirim' => $this->input->post('rekening_pengirim'),
                'currency' => $this->input->post('currency'),
                'nominal'=> $nominal,
                'keterangan' => $this->input->post('keterangan'),
                'created_at'=> $tanggal,
                'created_by'=> $user_id
            ]);
        }else{
            $this->session->set_flashdata('gagal', 'Penomoran Belum di SET-UP');
            redirect('Finance/uang_masuk');
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Pembayaran berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data Pembayaran gagal disimpan');
        }
        if($jenis == 'Deposit'){
            redirect('Finance/deposit');
        }else{
            redirect('Finance/uang_masuk');
        }
    }

    public function view_uang_masuk()
    {
        $id = $this->uri->segment(3);

        $this->load->model('Model_finance');
        $this->load->model('Model_master');
        $data['h'] = $this->Model_finance->view_uang_masuk($id)->row_array();
        $data['list_bank'] = $this->Model_master->bank()->result();
        $data['content']= "finance/view_uang_masuk";
        $this->load->view('layout', $data);
    }

    function delete_uang_masuk(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('f_uang_masuk');
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Uang masuk berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data Uang masuk gagal dihapus');
        }
        redirect('Finance/uang_masuk');
    }
}