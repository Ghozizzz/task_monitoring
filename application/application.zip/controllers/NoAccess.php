<?php

class NoAccess extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        // tampilkan halaman login
        $data['content'] = "no_access";
        $this->load->view('layout', $data);
    }
}