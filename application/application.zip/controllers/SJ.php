<?php

class SJ extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if($this->session->userdata('user_logged') === null) redirect(site_url('login'));
        $this->load->model('Model_master');
        $this->load->model('Model_sj2');
    }

    public function index()
    {
        $data['content']= "sj/index";
        $data['data'] = $this->Model_sj2->sj_list()->result();
        $this->load->view('layout', $data);
    }

    function list_sj() {
        $s = $this->input->post('startDate');
        $e = $this->input->post('endDate');
        $arr = [
            's' => $s,
            'e' => $e
        ];

        $list = $this->Model_sj2->get_datatables($arr,'list_sj');
        $data = array();
        $no = @$_POST['start'];
        foreach ($list['data'] as $item) {
            $no++;
            $action = '';
            $row = array();
            $row[] = $no.".";
            $row[] = $item->no_surat_jalan;
            $row[] = $item->tanggal;
            $row[] = $item->nama_supplier;
                if($item->status==0){
                  $status = '<div class="bg-secondary"><span>Draft</span></div>'; 
                }elseif($item->status==1){
                  if($item->flag>0){
                    $status = '<div class="bg-navy"><span>Sudah Dibayar</span></div>';
                  }else{
                    $status = '<div class="bg-success"><span>Approved</span></div>';
                  }
                }elseif($item->status==2){
                  $status = '<div class="bg-navy"><b>Finished</b></div>';
                }elseif($item->status==9){
                  $status = '<div class="bg-danger color-palette"><span>Rejected</span></div>';
                }
            $row[] = $status;
                if($item->status==0){
                  $action .= '<a class="btn btn-danger btn-sm" href="'.site_url().'SJ/delete/'.$item->id.'" onclick="return confirm(\'Anda yakin menghapus data ini?\');"><i class="fa fa-trash"></i> Delete</a> |';
                  $action .= '<a class="btn btn-info btn-sm" href="'.site_url().'SJ/edit/'.$item->id.'" ><i class="fa fa-edit"></i> Edit</a> ';
                }
                  $action .= '<a class="btn btn-primary btn-sm" href="'.site_url().'SJ/view/'.$item->id.'" ><i class="fa fa-file-alt"></i> View</a>';
                if($item->status!=0){
                  $action .= '<a class="btn btn-dark btn-sm" href="'.site_url().'SJ/print_sj/'.$item->id.'" target="_blank"><i class="fa fa-print"></i> Print</a>';
                }  
            $row[] = $action;

            $data[] = $row;
        }
        $output = array(
            "draw" => @$_POST['draw'],
            "recordsTotal" => $list['count_all'],
            "recordsFiltered" => $list['count_filtered'],
            "data" => $data,
        );
        // output to json format
        echo json_encode($output);
    }

    public function add()
    {
        $data['content']= "sj/add";
        $data['supplier'] = $this->Model_master->get_supplier()->result();
        $data['customer'] = $this->Model_master->get_customer(5)->row_array();
        $data['group_supplier'] = $this->Model_master->group_supplier()->result();
        // $data['bongkar_muat'] = $this->Model_master->bongkar_muat()->result();
        $this->load->view('layout', $data);
    }

    public function edit()
    {
        $id = $this->uri->segment(3);

        $data['content']= "sj/edit";
        $data['h'] = $this->Model_sj2->get_sj($id)->row_array();

        $data['barang'] = $this->Model_master->get_barang_customer($data['h']['id_customer'])->result();
        $data['details'] = $this->Model_sj2->detail_sj($id)->row_array();
        $data['bongkar_muat'] = $this->Model_master->bongkar_muat()->result();
        $this->load->view('layout', $data);
    }

    public function getSupplier()
    {
        $id = $this->input->post('id');
        $data = $this->Model_master->get_supplier_by_group($id)->result();
        echo json_encode($data);
    }

    function save(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $this->db->trans_start();

        $code = $this->Model_master->getNumbering('SJ', $tgl_input);
        $data = array(
            'no_surat_jalan'=> $code,
            'tanggal'=> $tgl_input,
            'nama_supplier'=>strtoupper($this->input->post('nama_supplier')),
            'id_customer'=>5,
            'jenis_kendaraan'=>strtoupper($this->input->post('jenis_kendaraan')),
            'no_kendaraan'=>strtoupper($this->input->post('no_kendaraan')),
            'ppn'=>$this->input->post('ppn'),
            'keterangan'=>strtoupper($this->input->post('keterangan')),
            'status'=>0,
            'created_at'=> $tanggal,
            'created_by'=> $user_id
        );
        $this->db->insert('sj', $data);
        $sj_id = $this->db->insert_id();
        if($this->db->trans_complete()){
            redirect('SJ/edit/'.$sj_id);
        }else{
            $this->session->set_flashdata('gagal', 'Data surat jalan gagal disimpan, silahkan dicoba kembali!');
            redirect('SJ');  
        }
    }

    function save_detail(){
        $user_id = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $this->db->trans_start();
        $bonus = $this->input->post('bonus');

        $return_data = array();
        if(empty($bonus)){
            $bonus = 0;
        }

        $this->db->insert('sj_details', $var = array(
            'id_sj'=>$this->input->post('id'),
            'id_jb'=>$this->input->post('id_jb'),
            'bruto'=>$this->input->post('bruto'),
            'potongan'=>$this->input->post('potongan'),
            'netto'=>$this->input->post('netto'),
            'id_harga'=>$this->input->post('id_harga'),
            'harga'=>$this->input->post('harga')+$bonus,
            'bonus'=>$bonus,
            'total'=>str_replace(',', '',$this->input->post('total'))
        ));
        $reff = $this->db->insert_id();

        if($this->db->trans_complete()){
            $return_data['status']= "sukses";
        }else{
            $return_data['status']= "error";
            $return_data['message']= "Gagal menambahkan item detail!";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    function view(){
        $id = $this->uri->segment(3);

        $data['content']= "sj/view";
        $data['h'] = $this->Model_sj2->get_sj($id)->row_array();
        $data['list_data'] = $this->Model_sj2->get_sj_detail($id)->result();
        //var_dump($data['list_data']);die();
        $this->load->view('layout', $data);
    }

    function approve_sj(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $tgl_input = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $id = $this->input->post('id');
        $grand_total = $this->input->post('grand_total');

        $this->db->trans_start();

        //Update SJ
        $this->db->where('id', $id);
        $this->db->update('sj', array(
            'status'=> 1,
            'nilai'=> $this->input->post('grand_total'),
            'modified_at'=> $tanggal,
            'modified_by'=>$user_id
        ));

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Surat Jalan berhasil diapprove');
        }else{
            $this->session->set_flashdata('gagal', 'Data Surat Jalan gagal diapprove');
        }
        redirect('SJ/index');
    }

    function open_sj(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal = date('Y-m-d H:i:s');
        $id = $this->input->post('id');

        $this->db->trans_start();
        if($id!=0){
            #Update status SPB
            $this->db->where('id', $id);
            $this->db->update('sj', array(
                'status'=> 0,
                'nilai'=> 0,
                'modified_at'=> $tanggal,
                'modified_by'=>$user_id
            ));
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Surat Jalan berhasil diopen');
        }else{
            $this->session->set_flashdata('gagal', 'Data Surat Jalan gagal diopen');
        }
        redirect('SJ/view/'.$id);
    }

    function load_detail_html(){
        $id = $this->input->post('id');
        $tabel = "";
        $no = 2;
        $this->load->model('Model_master');

        $this->load->Model('Model_sj2');
        $myDetail = $this->Model_sj2->load_detail($id)->result();
        foreach ($myDetail as $row) {
            $tabel .= '<tr>';
            $tabel .= '<td class="text-right">'.($no-1).'</td>';
            $tabel .= '<td><label id="lbl_barang_'.$no.'">'.$row->barang.'</label><input type="text" id="barang_'.$no.'" name="barang" class="form-control" value="'.$row->id_jb.'" style="display:none"></td>';
            $tabel .= '<td class="text-right"><label id="lbl_bruto_'.$no.'">'.number_format($row->bruto,2,',','.').'</label>';
            $tabel .= '<input type="text" id="bruto_'.$no.'" name="bruto" class="form-control" value="'.$row->bruto.'" style="display:none" onkeyup="hitung('.$no.')"></td>';
            $tabel .= '<td class="text-right"><label id="lbl_potongan_'.$no.'">'.number_format($row->potongan,2,',','.').'</label>';
            $tabel .= '<input type="text" id="potongan_'.$no.'" name="potongan" class="form-control" '
                . ' value="'.$row->potongan.'" style="display:none" onkeyup="hitung('.$no.')" readonly>';
            $tabel .= '<td class="text-right"><label id="lbl_netto_'.$no.'">'.number_format($row->netto,2,',','.').'</label>';
            $tabel .= '<input type="text" id="netto_'.$no.'" name="netto" class="form-control" value="'.$row->netto.'" style="display:none"></td>';
            $tabel .= '<td class="text-right"><label id="lbl_harga_option_'.$no.'">'.number_format($row->harga,2,',','.').' ('.$row->tanggal.')</label>';
                $tabel .= '<select id="harga_option_'.$no.'" name="harga_option" class="form-control select2bs4" ';
                $tabel .= 'data-placeholder="Pilih..." style="margin-bottom:5px; display:none" onchange="get_total(this.value,'.$no.')">';
                $tabel .= '<option value=""></option>';
                $tabel .= '</select>';
                $tabel .= '<input type="hidden" id="harga_id_'.$no.'" name="harga_id_'.$no.'" value="'.$row->id_harga.'">';
                $tabel .= '<input type="hidden" id="harga_barang_'.$no.'" name="harga_barang_'.$no.'" value="'.$row->harga.'">';
            $tabel .= '</td>';
            $tabel .= '<td class="text-right"><label id="lbl_bonus_'.$no.'">'.number_format($row->bonus,2,',','.').'</label>';
            $tabel .= '<input type="text" id="bonus_'.$no.'" name="bonus" class="form-control" '
                . ' value="'.$row->bonus.'" style="display:none" onkeyup="hitung('.$no.')">';
            $tabel .= '</td>';
            $tabel .= '<td class="text-right"><label id="lbl_sub_total_'.$no.'">'.number_format($row->total,2,',','.').'</label>';
            $tabel .= '<input type="text" id="sub_total_'.$no.'" name="sub_total" class="form-control" '
                . ' value="'.number_format($row->total,2,'.',',').'" style="display:none" readonly>';
            $tabel .= '</td>';
            
            $tabel .= '<td style="text-align:center;">';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-circle btn-primary'
                    . '" onclick="editDetail('.$row->id_jb.','.$row->id_harga.','.$no.');" style="margin-top:5px" id="btnEdit_'.$no.'"> '
                    . '<i class="fa fa-edit"></i> Edit &nbsp; </a>';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-circle btn-success'
                    . '" onclick="updateDetail('.$row->id.','.$no.');" style="margin-top:5px; display:none" id="btnUpdate_'.$no.'"> '
                    . '<i class="fa fa-save"></i> Update </a>';
            $tabel .= '<a href="javascript:;" class="btn btn-xs btn-circle btn-danger'
                    . '" onclick="hapusDetail('.$row->id.');" style="margin-top:5px"> '
                    . '<i class="fa fa-trash"></i> Delete </a>';
            $tabel .= '</td>';
            $tabel .= '</tr>';
            $no++;
        }
        $data['no'] = $no;
        $data['tabel'] = $tabel;
        header('Content-Type: application/json');
        echo json_encode($data); 
    }
    
    function delete(){
        $id = $this->uri->segment(3);
        $this->db->trans_start();
        if(!empty($id)){
            $this->db->where('id', $id);
            $this->db->delete('sj');         

            $this->db->where('id_sj', $id);
            $this->db->delete('sj_details');   
        }
        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Surat Jalan berhasil dihapus');
        }else{
            $this->session->set_flashdata('gagal', 'Data Surat Jalan gagal dihapus');
        }
        redirect('SJ/index');
    }

    function update(){
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $id = $this->input->post('id');
        
        $this->db->trans_start();

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('sj', [
            'no_surat_jalan'=>$this->input->post('no_surat_jalan'),
            'tanggal'=>$this->input->post('tanggal'),
            'status'=>0,
            'nama_supplier'=>$this->input->post('nama_supplier'),
            'jenis_kendaraan'=>strtoupper($this->input->post('jenis_kendaraan')),
            'no_kendaraan'=>strtoupper($this->input->post('no_kendaraan')),
            'bonus'=>$this->input->post('bonus'),
            'nilai_deposit'=>$this->input->post('nilai_deposit'),
            'denda'=>(int)$this->input->post('denda_1')+(int)$this->input->post('denda_2'),
            'denda_1'=>$this->input->post('denda_1'),
            'denda_2'=>$this->input->post('denda_2'),
            'id_obm'=>$this->input->post('bongkar_muat'),
            'ppn'=>$this->input->post('ppn'),
            'bb_cash'=>$this->input->post('bb_cash'),
            'tiket'=>$this->input->post('tiket'),
            'keterangan'=>strtoupper($this->input->post('keterangan')),
            'modified_by'=>$user_id,
            'modified_at'=>$tanggal
        ]);

        if($this->input->post('already_insert')==0){
            //Insert Details
            $bonus = $this->input->post('bonus');

            $return_data = array();
            if(empty($bonus)){
                $bonus = 0;
            }

            $this->db->insert('sj_details', $var = array(
                'id_sj'=>$this->input->post('id'),
                'id_jb'=>$this->input->post('id_jb'),
                'bruto'=>$this->input->post('bruto'),
                'potongan'=>$this->input->post('potongan'),
                'netto'=>$this->input->post('netto'),
                'id_harga'=>$this->input->post('id_harga'),
                'harga'=>$this->input->post('harga')+$bonus,
                'bonus'=>$bonus,
                'total'=> str_replace(',', '',$this->input->post('total'))
            ));
            $reff = $this->db->insert_id();
        }else{
            $return_data = array();
            if(empty($bonus)){
                $bonus = 0;
            }

            $var = [
                'id_jb'=>$this->input->post('id_jb'),
                'bruto'=>$this->input->post('bruto'),
                'potongan'=>$this->input->post('potongan'),
                'netto'=>$this->input->post('netto'),
                'id_harga'=>$this->input->post('id_harga'),
                'harga'=>$this->input->post('harga')+$bonus,
                'bonus'=>$bonus,
                'total'=> str_replace(',', '',$this->input->post('total'))
            ];

            $this->db->where('id_sj', $id);
            $this->db->update('sj_details', $var);
        }

        if($this->db->trans_complete()){
            $this->session->set_flashdata('sukses', 'Data Surat Jalan berhasil disimpan');
        }else{
            $this->session->set_flashdata('gagal', 'Data Surat Jalan gagal disimpan');
        }
        redirect('SJ/view/'.$this->input->post('id'));
    }

    function update_detail(){
        $this->load->model('Model_sj');
        $id = $this->input->post('id');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $cek = $this->Model_sj->list_sj_detail($id)->result();
        $bonus = $this->input->post('bonus');

        $this->db->trans_start();

        $return_data = array();
        if(empty($bonus)){
            $bonus = 0;
        }

        $var = [
            'id_jb'=>$this->input->post('id_jb'),
            'bruto'=>$this->input->post('bruto'),
            'potongan'=>$this->input->post('potongan'),
            'netto'=>$this->input->post('netto'),
            'id_harga'=>$this->input->post('id_harga'),
            'harga'=>$this->input->post('harga')+$bonus,
            'bonus'=>$bonus,
            'total'=> str_replace(',', '',$this->input->post('total'))
        ];

        $this->db->where('id', $id);
        $this->db->update('sj_details', $var);
        
        if($this->db->trans_complete()){
            $return_data['status']= "sukses";
            $return_data['message'] = "Berhasil Mengupdate data!";
        }else{
            $return_data['status']= "error";
            $return_data['message']= "Gagal mengupdate detail! Silahkan coba kembali";
        }
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    public function delete_detail()
    {
        $this->load->model('Model_sj');
        $user_id  = $this->session->userdata('user_id');
        $tanggal  = date('Y-m-d H:i:s');
        $id = $this->input->post('id');

        $this->db->trans_start();

        $return_data = array();
        $cek = $this->Model_sj->list_sj_detail($id)->result();
        $this->db->where('id', $id);
        $this->db->delete('t_sj_details');

        $encode_data = json_encode($cek);
        $this->db->insert('logs', [
            'jenis'=>'delete',
            'tabel'=>'t_sj_detail',
            'reff'=>$this->input->post('id'),
            'json'=>$encode_data,
            'created_at'=>$tanggal,
            'created_by'=>$user_id
        ]);

        if($this->db->trans_complete()){
            $return_data['status']= "sukses";
        }else{
            $return_data['status']= "error";
            $return_data['message']= "Gagal menghapus item! Silahkan coba kembali";
        }           
        header('Content-Type: application/json');
        echo json_encode($return_data);
    }

    public function print_sj()
    {
        $id = $this->uri->segment(3);
        if($id){        
            $this->load->model('Model_sj');
            $this->load->helper('tanggal_indo');
            // $data['h']  = $this->Model_sj->show_header_sj($id)->row_array();
            $data['h'] = $this->Model_sj->get_sj_match($id)->row_array();
            $data['details'] = $this->Model_sj->get_sj_detail($id)->result();

            $this->load->view('surat_jalan/print_sj', $data);
        }
    }
}