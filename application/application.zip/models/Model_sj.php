<?php
class Model_sj extends CI_Model{

    function sj_list($id = null){
        $this->db->select('t.*, s.nama_supplier, c.nama_customer, gs.nama_group_supplier, mbm.nama_bongkar_muat, mbm.harga as harga_bongkar_muat');
        $this->db->from('t_sj t');
        $this->db->join('m_supplier s', 't.id_supplier = s.id', 'left');
        $this->db->join('m_customer c', 't.id_customer = c.id', 'left');
        $this->db->join('m_group_supplier gs', 't.id_group_supplier = gs.id', 'left');
        $this->db->join('m_bongkar_muat mbm', 't.id_obm = mbm.id', 'left');
        if ($id != null) {
            $this->db->where('t.id', $id);
        }
        $this->db->order_by('t.no_surat_jalan', 'desc');
        $query = $this->db->get();
        return $query;
    }

    function get_sj($id){
    	return $this->db->query("Select t_sj.*, c.nama_customer From t_sj
            left join m_customer c on t_sj.id_customer = c.id 
            where t_sj.id=".$id);
    }

    function get_sj_match($id){
        return $this->db->query("Select t.*, s.nama_supplier, gs.nama_group_supplier, mbm.nama_bongkar_muat, mbm.harga as harga_bongkar_muat, c.nama_customer, s.nilai as nilai_deposit,
            COALESCE((select count(id) from f_match_detail where jenis_pmb = 0 and id_sj = t.id),0)as count 
            From t_sj t
            left join m_supplier s on t.id_supplier = s.id
            left join m_customer c on t.id_customer = c.id
            left join m_group_supplier gs on t.id_group_supplier = gs.id
            left join m_bongkar_muat mbm on t.id_obm = mbm.id
            where t.id=".$id);
    }

    function list_match_detail($id){
        return $this->db->query("Select fmd.*, fm.id_supplier From f_match_detail fmd
            left join f_match fm on fmd.id_match = fm.id
            where jenis_pmb in (0,2) and id_match = ".$id);
    }

    function get_nilai_sj($id){
        return $this->db->query("Select sj.*, bm.harga as harga_bongkar_muat From t_sj sj 
            left join m_bongkar_muat bm on sj.id_obm = bm.id
            where sj.id=".$id);
    }

    function get_nilai_lb($id){
        return $this->db->query("Select * From f_spl_lebihbayar where id=".$id);
    }

    function get_sj_pembayaran($id){
        return $this->db->query("
                Select fmd.id, fmd.id_match, fmd.sj_bayar as nilai,
                    ( CASE 
                        WHEN fmd.jenis_pmb = 0 THEN fm.no_matching
                        WHEN fmd.jenis_pmb = 1 THEN 'Potong Deposit'
                        WHEN fmd.jenis_pmb = 3 THEN 'Potong Lebih Bayar'
                        ELSE 'KOSONG' END
                    ) as no_matching,
                    ( CASE 
                        WHEN fmd.jenis_pmb = 0 THEN fm.tanggal
                        WHEN fmd.jenis_pmb = 1 THEN fsd.tanggal
                        WHEN fmd.jenis_pmb = 3 THEN flb.tanggal
                        ELSE '0000-00-00' END
                    ) as tanggal, fmd.jenis_pmb
                From f_match_detail fmd
                    Left Join f_match fm on fmd.jenis_pmb = 0 and fmd.id_match = fm.id
                    Left Join f_spl_deposit fsd on fmd.jenis_pmb = 1 and fmd.id_match = fsd.id
                    Left Join f_spl_lebihbayar flb on fmd.jenis_pmb = 3 and fmd.id_match = flb.id
                    where fmd.id_sj =".$id);
    }

    function get_sj_pembayaran_deposit($id){
        return $this->db->query("
                Select fmd.id, fmd.id_match, fmd.sj_bayar as nilai,
                    ( CASE 
                        WHEN fmd.jenis_pmb = 0 THEN fm.no_matching
                        WHEN fmd.jenis_pmb = 1 THEN 'Potong Deposit'
                        WHEN fmd.jenis_pmb = 3 THEN 'Potong Lebih Bayar'
                        ELSE 'KOSONG' END
                    ) as no_matching,
                    ( CASE 
                        WHEN fmd.jenis_pmb = 0 THEN fm.tanggal
                        WHEN fmd.jenis_pmb = 1 THEN fsd.tanggal
                        WHEN fmd.jenis_pmb = 3 THEN flb.tanggal
                        ELSE '0000-00-00' END
                    ) as tanggal, fmd.jenis_pmb
                From f_match_detail fmd
                    Left Join f_match fm on fmd.jenis_pmb = 0 and fmd.id_match = fm.id
                    Left Join f_spl_deposit fsd on fmd.jenis_pmb = 1 and fmd.id_match = fsd.id
                    Left Join f_spl_lebihbayar flb on fmd.jenis_pmb = 3 and fmd.id_match = flb.id
                    where fmd.jenis_pmb in (1,3) and fmd.id_sj =".$id);
    }

    function detail_sj($id){
        return $this->db->query("Select * From t_sj_details where id_sj=".$id);
    }

    function list_sj_detail($id){
        return $this->db->query("Select * From t_sj_details where id=".$id);
    }

    function get_sj_detail($id){
        return $this->db->query("SELECT td.*, tsj.no_surat_jalan, tsj.tanggal, tsj.id_supplier, tsj.id_group_supplier, 
            tsj.no_kendaraan, tsj.jenis_kendaraan, tsj.denda, tsj.id_obm, tsj.tiket, tsj.bb_cash, tsj.keterangan, 
            mb.nama_barang, mh.harga
                FROM t_sj_details td 
            LEFT JOIN t_sj tsj ON td.id_sj=tsj.id 
            LEFT JOIN m_barang mb ON td.id_jb=mb.id 
            LEFT JOIN m_harga mh ON td.id_harga=mh.id
            WHERE tsj.id=".$id);
    }

    function get_sj_detail_multiple($id){
        return $this->db->query("
            SELECT * FROM t_sj_details where id_sj in (".$id.")
            ");
    }

    function get_sj_multiple($id){
        return $this->db->query("
            SELECT * FROM t_sj where id in (".$id.")
            ");
    }

    function get_sj_only($id){
        return $this->db->query("
            SELECT * FROM t_sj where id =".$id);
    }

    function load_sj_full($id,$idm){
        $data = $this->db->query("SELECT tsj.id, tsj.no_surat_jalan, 
                    COALESCE(
                        (select count(id) 
                        from f_match_detail 
                        where jenis_pmb = 0 and id_sj = tsj.id and id_match =".$idm."),0) as count, 
                    (tsj.nilai-tsj.nilai_bayar-tsj.nilai_potong) as total 
                    FROM t_sj tsj 
                    WHERE tsj.id_supplier=".$id." AND tsj.flag = 0 AND tsj.status = 1");
        return $data;
    }

    function load_sj_match($id){
        return $this->db->query("SELECT fmd.*, fmd.sj_bayar as total, tsj.no_surat_jalan FROM f_match_detail fmd
        LEFT JOIN t_sj tsj on tsj.id=fmd.id_sj 
        WHERE fmd.jenis_pmb = 0 and fmd.id_match=".$id);
    }

    function load_detail($id){
        $this->db->select('td.id, td.id_sj, td.id_jb, td.bruto, td.potongan, td.netto, td.id_harga, td.bonus, td.total, mb.nama_barang
                           as barang, mh.harga, mh.tanggal');
        $this->db->from('t_sj_details td');
        $this->db->join('m_barang mb', 'td.id_jb=mb.id', 'left');
        $this->db->join('m_harga mh', 'td.id_harga=mh.id', 'left');
        $this->db->where('td.id_sj', $id);
        $query = $this->db->get();
        return $query;
    }

    function get_data_sj($id){
        return $this->db->query("SELECT id, no_surat_jalan, id_supplier,
                nilai, nilai_bayar, nilai_potong, 
                (nilai_bayar+nilai_potong) as nilai_total_bayar, 
                (nilai-nilai_bayar-nilai_potong) as nilai_sisa 
            FROM t_sj 
            WHERE id=".$id);
    }

    function view_sj_match($id){
        return $this->db->query("SELECT fmd.*, tsj.no_surat_jalan, tsj.nilai, tsj.nilai_bayar,
            COALESCE((select sum(fmd2.sj_bayar) from f_match_detail fmd2 where fmd2.id_sj = tsj.id and fmd2.id != fmd.id),0) as nilai_sdh_bayar 
        FROM f_match_detail fmd
        LEFT JOIN t_sj tsj on tsj.id=fmd.id_sj 
        WHERE fmd.jenis_pmb = 0 and fmd.id=".$id);
    }

    function get_invoice($id=null)
    {
        $this->db->select('fm.*, mc.nama_customer');
        $this->db->from('f_match fm');
        $this->db->join('m_customer mc', 'fm.id_customer=mc.id');
        if ($id != null) {
            $this->db->where('fm.id', $id);
        }
        $query = $this->db->get();
        return $query;
    }

    function print_laporan_rekap_cust($s,$e)
    {
        return $this->db->query("SELECT sum(tsjd.bruto) as bruto, sum(tsjd.potongan) as potongan, sum(tsjd.netto) as netto, sum(tsjd.bonus) as bonus, sum(tsj.nilai) as total, sum(tsj.nilai_bayar) as bayar, tsj.keterangan as catatan, mc.nama_customer as nama, tsj.no_kendaraan as nopol, tsj.tanggal, fi.no_invoice as kwitansi, mhb.harga as harga  FROM t_sj_details tsjd LEFT JOIN t_sj tsj ON tsjd.id_sj=tsj.id LEFT JOIN m_harga_barang mhb ON mhb.id=tsjd.id_harga LEFT JOIN m_customer mc ON tsj.id_customer=mc.id LEFT JOIN f_invoice fi ON tsj.id_supplier=fi.id_supplier WHERE tsj.tanggal between '".$s."' and '".$e."' group by tsjd.id_jb, nopol
        order by tsjd.id_jb, tsj.tanggal asc");
    }

    function get_data_pmb($id)
    {
        return $this->db->query("SELECT fpmb.*, mc.nama_customer FROM f_pmb fpmb JOIN m_customer mc ON mc.id=fpmb.id_customer WHERE fpmb.id=".$id);
    }

    function get_data_invoice($s)
    {
        return $this->db->query("SELECT * FROM f_invoice WHERE id_customer=".$s);
    }

    function get_pembayaran()
    {
        return $this->db->query("SELECT fpmb.*, mc.nama_customer FROM f_pmb fpmb JOIN m_customer mc ON mc.id=fpmb.id_customer");
    }

    function show_header_sj($id)
    {
        return $this->db->query("SELECT tsj.*, ms.nama_supplier, ms.alamat FROM t_sj tsj JOIN m_supplier ms ON tsj.id_supplier=ms.id WHERE tsj.id=".$id);
    }

    function print_rekap_supplier($bulan,$tahun)
    {
        return $this->db->query("SELECT tsj.*, sum(tsjd.bruto) as bruto, sum(tsjd.potongan) as pot, sum(tsjd.netto) as netto, mbm.nama_bongkar_muat as nbm, mhb.harga as harga_b, ms.nama_supplier, mb.nama_barang from t_sj tsj LEFT JOIN t_sj_details tsjd ON tsj.id=tsjd.id_sj LEFT JOIN m_bongkar_muat mbm ON tsj.id_obm=mbm.id LEFT JOIN m_supplier ms ON tsj.id_supplier=ms.id LEFT JOIN m_barang mb ON tsjd.id_jb=mb.id LEFT JOIN m_harga_barang mhb ON tsjd.id_harga=mhb.id WHERE MONTH(tsj.tanggal)= '".$bulan."' AND YEAR(tsj.tanggal)= '".$tahun."' GROUP BY tsjd.id_sj, tsjd.id_jb ORDER BY tsj.tanggal asc");
    }

    function print_rekap_supplier_by_group($bulan,$tahun,$group)
    {
        return $this->db->query("SELECT tsj.*, sum(tsjd.bruto) as bruto, sum(tsjd.potongan) as pot, sum(tsjd.netto) as netto, mbm.nama_bongkar_muat as nbm, mhb.harga as harga_b, ms.nama_supplier, mb.nama_barang from t_sj tsj LEFT JOIN t_sj_details tsjd ON tsj.id=tsjd.id_sj LEFT JOIN m_bongkar_muat mbm ON tsj.id_obm=mbm.id LEFT JOIN m_supplier ms ON tsj.id_supplier=ms.id LEFT JOIN m_barang mb ON tsjd.id_jb=mb.id LEFT JOIN m_harga_barang mhb ON tsjd.id_harga=mhb.id WHERE tsj.id_group_supplier = '".$group."' AND MONTH(tsj.tanggal)= '".$bulan."' AND YEAR(tsj.tanggal)= '".$tahun."' GROUP BY tsjd.id_sj, tsjd.id_jb ORDER BY tsj.tanggal asc");
    }

    function get_sj_invoice($id){
        return $this->db->query("SELECT fi.* FROM t_sj
            left join f_invoice fi on t_sj.id_invoice = fi.id
            where t_sj.id = ".$id);
    }

    function list_sj_belum_lunas(){
        $this->db->select('t.*, s.nama_supplier, c.nama_customer, gs.nama_group_supplier, (t.nilai-t.nilai_bayar-t.nilai_potong) as nilai_sisa');
        $this->db->from('t_sj t');
        $this->db->join('m_supplier s', 't.id_supplier = s.id', 'left');
        $this->db->join('m_customer c', 't.id_customer = c.id', 'left');
        $this->db->join('m_group_supplier gs', 't.id_group_supplier = gs.id', 'left');
        $this->db->where('status',1);
        $this->db->where('flag',0);
        $this->db->order_by('t.no_surat_jalan', 'desc');
        $query = $this->db->get();
        return $query;
    }

    function histori_sj_list($id = null){
        $this->db->select('t.*, s.nama_supplier, c.nama_customer, gs.nama_group_supplier, mbm.nama_bongkar_muat, mbm.harga as harga_bongkar_muat, u.name as nama_user');
        $this->db->from('t_sj t');
        $this->db->join('m_supplier s', 't.id_supplier = s.id', 'left');
        $this->db->join('m_customer c', 't.id_customer = c.id', 'left');
        $this->db->join('m_group_supplier gs', 't.id_group_supplier = gs.id', 'left');
        $this->db->join('m_bongkar_muat mbm', 't.id_obm = mbm.id', 'left');
        $this->db->join('users u', 't.created_by = u.id', 'left');
        if ($id != null) {
            $this->db->where('t.id', $id);
        }
        $this->db->where('del',1);
        $this->db->order_by('t.no_surat_jalan', 'desc');
        $query = $this->db->get();
        return $query;
    }
}