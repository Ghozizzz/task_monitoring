<?php
class Model_sj2 extends CI_Model{

    function sj_list($id = null){
        $this->db->select('t.*, c.nama_customer');
        $this->db->from('sj t');
        $this->db->join('m_customer c', 't.id_customer = c.id', 'left');
        if ($id != null) {
            $this->db->where('t.id', $id);
        }
        $this->db->order_by('t.no_surat_jalan', 'desc');
        $query = $this->db->get();
        return $query;
    }

    function get_sj($id){
    	return $this->db->query("Select sj.*, c.nama_customer, mbm.nama_bongkar_muat, mbm.harga as harga_bongkar_muat From sj
            left join m_customer c on sj.id_customer = c.id 
            left join m_bongkar_muat mbm on sj.id_obm = mbm.id
            where sj.id=".$id);
    }

    function get_sj_detail($id){
        return $this->db->query("SELECT td.*, tsj.no_surat_jalan, tsj.tanggal, tsj.no_kendaraan, tsj.jenis_kendaraan, tsj.denda, tsj.id_obm, 
            tsj.tiket, tsj.bb_cash, tsj.keterangan, mb.nama_barang, mh.harga
                FROM sj_details td 
            LEFT JOIN sj tsj ON td.id_sj=tsj.id 
            LEFT JOIN m_barang mb ON td.id_jb=mb.id 
            LEFT JOIN m_harga mh ON td.id_harga=mh.id
            WHERE tsj.id=".$id);
    }

    function detail_sj($id){
        return $this->db->query("Select * From sj_details where id_sj=".$id);
    }

    function load_detail($id){
        $this->db->select('td.id, td.id_sj, td.id_jb, td.bruto, td.potongan, td.netto, td.id_harga, td.bonus, td.total, mb.nama_barang
                           as barang, mh.harga, mh.tanggal');
        $this->db->from('sj_details td');
        $this->db->join('m_barang mb', 'td.id_jb=mb.id', 'left');
        $this->db->join('m_harga mh', 'td.id_harga=mh.id', 'left');
        $this->db->where('td.id_sj', $id);
        $query = $this->db->get();
        return $query;
    }

    private function list_sj($id){
        // start datatables
        $this->column_order = array(null, 'tsj.no_surat_jalan', 'tsj.tanggal', 'tsj.nama_supplier', 'tsj.no_kendaraan'); //set column field database for datatable orderable
        $this->column_search = array('tsj.no_surat_jalan', 'tsj.tanggal', 'tsj.nama_supplier', 'tsj.no_kendaraan'); //set column field database for datatable searchable
        $this->order = array('tsj.tanggal' => 'asc'); // default order 
     
        $this->db->select('tsj.*');
        $this->db->from('sj tsj');
        $this->db->where('tsj.tanggal >=', $id['s']);
        $this->db->where('tsj.tanggal <=', $id['e']);
    }

    private function _get_datatables_query($id,$func_name) {
        $this->$func_name($id);

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if(@$_POST['search']['value']) { // if datatable send POST for search
                if($i===0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if(isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }  else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($id,$func_name) {
        $this->_get_datatables_query($id,$func_name);
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        $data['data'] = $query->result();

        $this->_get_datatables_query($id,$func_name);
        $query = $this->db->get();
        $data['count_filtered'] = $query->num_rows();

        $this->$func_name($id);
        $query2 = $this->db;
        $data['count_all'] = $query2->count_all_results();
        return $data;
    }
}