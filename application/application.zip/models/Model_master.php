<?php
class Model_master extends CI_Model{
/** Bank **/
    function bank(){
        return $this->db->query("Select * From m_bank Order By nama_bank");
    }
    function get_bank($id){
    	return $this->db->query("Select * From m_bank where id=".$id);
    }

/** Barang **/
    function barang(){
        return $this->db->query("Select * From m_barang Order By nama_barang");
    }

    function get_barang($id){
    	return $this->db->query("Select * From m_barang where id=".$id);
    }

/** Barang Relasi **/

    function barang_relasi(){
        return $this->db->query("Select mbr.*, mb.nama_barang, mc.nama_customer From m_barang_relasi mbr
            left join m_barang mb on mbr.id_barang = mb.id
            left join m_customer mc on mbr.id_customer = mc.id");
    }

    function get_barang_relasi($id){
        return $this->db->query("Select * From m_barang_relasi where id =".$id);
    }

    function cek_barang_relasi($idb,$idc){
        return $this->db->query("Select * From m_barang_relasi where id_barang =".$idb." and id_customer =".$idc);
    }

    function get_barang_customer($id){
        return $this->db->query("Select mb.* From m_barang_relasi mbr
            left join m_barang mb on mbr.id_barang = mb.id
            where mbr.id_customer =".$id);
    }

/** Harga Barang **/
    function harga_barang(){
        // return $this->db->query("SELECT h.id, harga, tanggal, mb.nama_barang FROM m_harga_barang h 
        //             left join m_barang mb on h.id_barang = mb.id
        //             WHERE tanggal IN (SELECT MAX(tanggal) FROM m_harga_barang GROUP BY id_barang order by id desc) group by h.id_barang
        //             ");
        return $this->db->query("Select h.*, mb.nama_barang 
                        From m_harga h
                        left join m_barang mb on h.id_barang = mb.id
                        inner join (
                            select id_barang, max(tanggal) as maxdate
                                from m_harga
                                group by id_barang
                        ) mhl on h.id_barang = mhl.id_barang and h.tanggal = mhl.maxdate
                        group by h.id_barang
                        order by nama_barang");
    }

    function get_harga_barang($id){
        return $this->db->query("Select * From m_harga where id=".$id);
    }

    function get_harga_barang_list($id,$idc,$cur_date){
        // return $this->db->query("Select * From m_harga where id_barang=".$id." and id_customer=".$idc." order by tanggal desc limit 10");
        // return $this->db->query("Select * From m_harga where id_barang=".$id." and id_customer=".$idc." and tanggal>=CURRENT_DATE()");
        return $this->db->query("
            (
                SELECT * FROM m_harga
                where id_barang =".$id." and
                 CAST(tanggal AS DATE) = (SELECT CAST(MAX(tanggal) AS DATE) FROM m_harga where id_barang =".$id." and CAST(tanggal AS DATE)='".$cur_date."')
            )
            UNION ALL
            (
                SELECT * FROM m_harga
                where id_barang =".$id." and
                 CAST(tanggal AS DATE) = (SELECT CAST(MAX(tanggal) AS DATE) FROM m_harga where id_barang =".$id." and tanggal < '".$cur_date."')
            )");
    }

    function get_harga_barang_list2($id){
        return $this->db->query("Select h.*, mb.nama_barang, mc.nama_customer From m_harga h 
                    left join m_barang mb on h.id_barang = mb.id
                    left join m_customer mc on h.id_customer = mc.id
                    where id_barang=".$id." order by tanggal desc limit 10");
    }

    function get_harga_barang_customer($id){
        return $this->db->query("Select h.*, mb.nama_barang, mc.nama_customer From m_harga h
                    left join m_barang mb on h.id_barang = mb.id
                    left join m_customer mc on h.id_customer = mc.id
                    where h.id=".$id);
    }

    function check_harga($id){
        return $this->db->query("Select count(id) as count From t_sj_details where id_harga =".$id);
    }

/** Harga Jual **/
    function harga_jual(){
        return $this->db->query("SELECT h.id, harga, tanggal, mb.nama_barang FROM m_harga_jual h 
                    left join m_barang mb on h.id_barang = mb.id
                    WHERE tanggal IN (SELECT MAX(tanggal) FROM m_harga_jual GROUP BY id_barang order by id desc) group by h.id_barang
                    ");
    }

    function get_harga_jual($id){
        return $this->db->query("Select * From m_harga_jual where id=".$id);
    }

    function get_harga_jual_list($id){
        return $this->db->query("Select * From m_harga_jual where id_barang=".$id." order by tanggal desc limit 50");
    }

/** Customer **/
    function customer(){
        return $this->db->query("Select * From m_customer Order By nama_customer");
    }

    function get_customer($id){
    	return $this->db->query("Select * From m_customer where id=".$id);
    }

/** Supplier **/

    function get_supplier($id = null){
            $this->db->select('*');
            $this->db->from('m_supplier');
            if ($id != null) {
                $this->db->where('id', $id);
            }
            $this->db->order_by('nama_supplier','asc');
            $query = $this->db->get();
            return $query;

    }

    function get_supplier_by_group($id){
        // return $this->db->query("SELECT * FROM m_supplier WHERE group_supplier_id =".$id);
        $this->db->select();
        $this->db->from('m_supplier');
        $this->db->where('group_supplier_id', $id);
        $query = $this->db->get();
        return $query;
    }

/** Group Supplier **/
    function group_supplier(){
        return $this->db->query("Select * From m_group_supplier Order By nama_group_supplier");
    }

    function get_group_supplier($id){
    	return $this->db->query("Select * From m_group_supplier where id=".$id);
    }

/** Bongkar Muat **/
    function bongkar_muat(){
        return $this->db->query("Select * From m_bongkar_muat Order By nama_bongkar_muat");
    }

    function get_bongkar_muat($id){
        return $this->db->query("Select * From m_bongkar_muat where id=".$id);
    }

/** users **/
    function users(){
        return $this->db->query("Select u.*, r.roles From users u
            left join roles r on u.id_roles = r.id
            Order By name");
    }
    function get_users($id){
        return $this->db->query("Select * From users where id=".$id);
    }
    function roles(){
        return $this->db->query("Select * From roles");
    }

/** Numberings **/
    function list_numbering(){
        $data = $this->db->query("Select * From m_numberings");      
        return $data;
    }

    function cek_numbering($code){
        $data = $this->db->query("Select * From m_numberings Where prefix='".$code."'");        
        return $data;
    }
    
    function show_numbering($id){
        $data = $this->db->query("Select * From m_numberings Where id=".$id);        
        return $data;
    }
        
    function getNumbering($bill_type, $date=null){              
        $MNumbers = $this->db->query("Select * From m_numberings Where prefix='".$bill_type."' order by id limit 1 ")->row_array();  
       
        if($MNumbers !== null){
            //Generate Prefix
            $prefix      = $MNumbers['prefix'];
            
            $prefix .= $MNumbers['prefix_separator'];
            if($MNumbers['date_info']==1){
                if($date != null || $date !=""){
                    $date = $date;
                }else{              
                    $date =date('Y-m-d');
                }
                $prefix .= date('Ym', strtotime($date));//Reset Per Bulan
            }else if($MNumbers['date_info']==2){
                if($date != null || $date !=""){
                    $date = $date;
                }else{              
                    $date =date('Y-m-d');
                }
                $prefix .= date('Y', strtotime($date));//Reset Per Tahun
            }
            $padding = $MNumbers['padding'];            

            //Cek Prefix            
            $MNumberDetails = $this->db->query("Select * From m_numbering_details Where "
                    . "prefix='".$prefix."' order by id limit 1 ")->row_array();  
            // var_dump($MNumberDetails); die();
            if($MNumberDetails !== null){
                //Jika ada ambil last_number
                $last_number    = $MNumberDetails['last_number'];
                $current_number = $last_number + 1;

                $this->db->query("UPDATE m_numbering_details SET last_number='".$current_number."' WHERE prefix='".$prefix."'");
            }else{
                // echo "kesini null"; die();
                //Jika belum ada insert prefix dan mulai penomoran dari 1
                $current_number = 1;
                $this->db->query("INSERT INTO m_numbering_details(prefix, last_number)VALUES('".$prefix."', '".$current_number."')");
            }
                $code = str_pad($current_number,$padding,0,STR_PAD_LEFT);
                $code = $prefix.$MNumbers['date_separator'].$code;
        }else{
            $code = '';
        }
        return $code;
    }
}