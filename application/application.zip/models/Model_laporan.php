<?php
class Model_laporan extends CI_Model
{
    function print_laporan_harga_cust($c){
        $data = $this->db->query("SELECT tanggal FROM `m_harga` where id_customer = ".$c." GROUP BY tanggal order by tanggal desc limit 10");
        return $data;
    }

    function get_tgl_harga($jb,$idc,$tgl){
    	$data = $this->db->query("SELECT harga FROM `m_harga` 
    		where id_barang = ".$jb." and id_customer = ".$idc." and tanggal <= '".$tgl."' order by tanggal desc limit 1");
    	return $data;
    }
}