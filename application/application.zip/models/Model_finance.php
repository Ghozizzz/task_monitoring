<?php
class Model_finance extends CI_Model
{
    private $column_order;
    private $column_search;
    private $order;
    /**List Surat Jalan */
    function get_sj_list($id){
        $data = $this->db->query("Select tsj.id, tsj.no_surat_jalan from t_sj tsj where tsj.id_supplier = ".$id." and tsj.status = 1 and tsj.id_invoice = 0");
        return $data;
    }

    /** PO */
    function get_po(){
        $data = $this->db->query("SELECT tpo.*, ms.nama_supplier FROM t_po tpo JOIN m_supplier ms ON tpo.id_supplier=ms.id");
        return $data;
    }

    function get_po_list($id) {
        $data = $this->db->query("SELECT tpo.*, ms.nama_supplier FROM t_po tpo JOIN m_supplier ms ON tpo.id_supplier=ms.id WHERE tpo.id=".$id);
        return $data;
    }

    /** PO Detail */
    function load_detail($id){
        $this->db->select('td.id, td.id_po, td.id_jb, td.bruto, td.potongan, td.netto, td.id_harga, td.bonus, td.total, mb.nama_barang
                           as barang, mhh.harga');
        $this->db->from('t_po_id td');
        $this->db->join('m_barang mb', 'td.id_jb=mb.id', 'left');
        $this->db->join('m_harga_barang mhh', 'td.id_harga=mhh.id', 'left');
        $this->db->where('td.id_po', $id);
        $query = $this->db->get();
        return $query;
    }

    /** Invoice */

    function list_invoice(){
        $data = $this->db->query("SELECT fi.*, ms.nama_customer FROM f_invoice fi
            LEFT JOIN m_customer ms ON fi.id_customer=ms.id
            ORDER BY fi.tanggal desc");
        return $data;
    }

    private function list_invoice_index($id){
        // start datatables
        $this->column_order = array(null, 'f.no_invoice', 'c.nama_customer', 'f.tanggal', 'f.status', 'f.flag');
        $this->column_search = array('f.no_invoice', 'c.nama_customer', 'f.tanggal');
        $this->order = array('f.tanggal' => 'desc'); // default order 
     
        $this->db->select('f.*, c.nama_customer');
        $this->db->from('f_invoice f');
        $this->db->join('m_customer c', 'f.id_customer = c.id', 'left');
        if($id['cust']!=0){
            $this->db->where('f.id_customer',$id['cust']);
        }
        if(!empty($id['m'])){
            if($id['m']==0){
                $this->db->where('flag',0);
            }else{
                $this->db->where('flag >',0);
            }
        }
        if(!empty($id['start']) && !empty($id['end'])){
            $this->db->where('f.tanggal >=', $id['start']);
            $this->db->where('f.tanggal <=', $id['end']);
        }
    }

    function get_invoice_detail($id){
        return $this->db->query("SELECT fid.*,mb.nama_barang, tsjd.harga as harga_beli
        FROM f_invoice_detail fid 
        LEFT JOIN f_invoice fi ON fid.id_invoice=fi.id
        LEFT join t_sj_details tsjd ON fid.id_sj_detail = tsjd.id 
        LEFT JOIN m_barang mb ON fid.id_jb=mb.id 
        WHERE fi.id=".$id." order by mb.nama_barang");
    }

    function group_obm_inv($id){
        return $this->db->query("SELECT COALESCE(mbm.nama_bongkar_muat,'Tidak ada Ongkos') as nama_bongkar_muat, mbm.id as id_obm, mbm.harga, sum(bruto) as bruto, sum(netto) as netto
            From f_invoice_detail fid
            LEFT JOIN t_sj tsj on fid.id_sj = tsj.id
            LEFT JOIN m_bongkar_muat mbm on tsj.id_obm = mbm.id
            WHERE fid.id_invoice = ".$id."
            GROUP BY tsj.id_obm");
    }

    function get_no_invoice($no){
        return $this->db->query("SELECT id FROM f_invoice where no_invoice ='".$no."'");
    }

    function get_inv_supplier(){
        // $data = $this->db->query("SELECT fm.*, ms.nama_supplier FROM f_match fm JOIN m_supplier ms ON ms.id=fm.id_supplier");
        // $data = $this->db->query("SELECT fm.id, fm.no_matching, fm.keterangan, fm.tanggal, fm.status,
        //         sum(CASE WHEN tsj.id_invoice = 0 THEN 0 ELSE 1 END) as c, ms.nama_supplier
        //     FROM f_match_detail fmd
        //     INNER JOIN f_match fm on fmd.id_match = fm.id
        //     INNER JOIN t_sj tsj on fmd.id_sj = tsj.id
        //     INNER JOIN m_supplier ms on ms.id = fm.id_supplier
        //     WHERE fmd.id_match > 0
        //     GROUP BY fmd.id_match
        //     ORDER BY fm.tanggal desc");
        $data = $this->db->query("SELECT fm.id, fm.no_matching, fm.keterangan, fm.tanggal, fm.status,
                coalesce(sum(CASE WHEN tsj.id_invoice > 0 THEN 1 ELSE 0 END),0) as c, ms.nama_supplier
            FROM f_match fm
            LEFT JOIN f_match_detail fmd on fmd.jenis_pmb = 0 and fm.id = fmd.id_match
            LEFT JOIN t_sj tsj on fmd.id_sj = tsj.id
            LEFT JOIN m_supplier ms on ms.id = fm.id_supplier
            GROUP BY fm.id
            ORDER BY fm.tanggal desc
            ");
        return $data;
    }

    function show_header_invoice($id){
        $data = $this->db->query("select fi.*, c.nama_customer, c.alamat, c.jenis as jenis_customer, c.nama_bank, c.no_rekening,
            c.atas_nama, c.kcp
            from f_invoice fi
            left join m_customer c on c.id = fi.id_customer
            where fi.id = ".$id);
        return $data;
    }

    function get_inv_detail($id,$j){
        if($j==0){
            $data = $this->db->query("Select d.*, b.nama_barang, tsjd.harga as harga_beli From f_invoice_detail d
            left join t_sj_details tsjd on d.id_sj_detail = tsjd.id
            left join m_barang b on d.id_jb = b.id
            where id_invoice =".$id." order by d.id_jb");
        }else{
            $data = $this->db->query("Select d.id, 0 as id_sj, d.id_jb, sum(d.bruto) as bruto, sum(d.netto) as netto, d.harga, b.nama_barang, tsjd.harga as harga_beli From f_invoice_detail d
            left join t_sj_details tsjd on d.id_sj_detail = tsjd.id
            left join m_barang b on d.id_jb = b.id
            where id_invoice =".$id."
            group by d.harga, d.id_jb
            order by d.id_jb");
        }
        return $data;
    }

    function get_inv_summary_view($id){
        return $this->db->query("Select fis.id, fis.bruto, fis.netto, COALESCE(NULLIF(fis.harga_manual,0),fis.harga) as harga, fis.sub_total, fis.adjustment, b.nama_barang, tsj.no_kendaraan From f_invoice_summary fis
            left join t_sj tsj on fis.id_sj = tsj.id
            left join m_barang b on fis.id_jb = b.id
            where jenis = 0 and fis.id_invoice = ".$id);
    }

    function get_inv_summary_view_ordered($id){
        return $this->db->query("Select fis.id, fis.id_jb, fis.bruto, fis.netto, COALESCE(NULLIF(fis.harga_manual,0),fis.harga) as harga, fis.sub_total, fis.adjustment, b.nama_barang, tsj.no_kendaraan, tsj.no_tbt From f_invoice_summary fis
            left join t_sj tsj on fis.id_sj = tsj.id
            left join m_barang b on fis.id_jb = b.id
            where jenis = 0 and fis.id_invoice = ".$id."
            order by fis.id_jb");
    }

    function get_inv_summary_view_grouping($id){
        return $this->db->query("Select fis.id, sum(fis.bruto) as bruto, sum(fis.netto) as netto, COALESCE(NULLIF(fis.harga_manual,0),fis.harga) as harga, sum(fis.sub_total) as sub_total, sum(fis.adjustment) adjustment, b.nama_barang, tsj.no_kendaraan From f_invoice_summary fis
            left join t_sj tsj on fis.id_sj = tsj.id
            left join m_barang b on fis.id_jb = b.id
            where jenis = 0 and fis.id_invoice = ".$id."
            group by fis.id_jb");
    }

    function get_inv_summary($id){
        return $this->db->query("Select fis.*, b.nama_barang From f_invoice_summary fis
            join m_barang b on fis.id_jb = b.id
            where fis.jenis = 0 and fis.id_invoice = ".$id);
    }

    function get_inv_denda($id){
        return $this->db->query("Select fis.*, tsj.no_surat_jalan, tsj.no_kendaraan, tsj.jenis_kendaraan,
            (CASE WHEN fis.jenis=1 THEN 'Denda' ELSE 'Denda K3' END) as nomor
            From f_invoice_summary fis
            left join t_sj tsj on fis.id_sj = tsj.id
            where fis.jenis in (1,2) and fis.id_invoice = ".$id);
    }

    function get_inv_denda_group($id){
        return $this->db->query("Select sum(harga) as denda, sum(harga_manual) as denda_k3, sum(sub_total) as total_denda
            From f_invoice_summary fis
            left join t_sj tsj on fis.id_sj = tsj.id
            where fis.jenis = 1 and fis.id_invoice = ".$id."
            group by fis.id_invoice");
    }

    function get_inv_ppn($id){
        return $this->db->query("Select fid.*, sum(fid.netto * fid.harga)*10/100 as nilai_ppn 
            From f_invoice_summary fid
            where fid.id_invoice=".$id);
    }

    function get_inv_creditmemo($id){
        return $this->db->query("Select fid.*, tsj.no_kendaraan, mbm.harga as harga_obm, (fid.bruto * mbm.harga) as nilai_obm 
            From f_invoice_summary fid
            left join t_sj tsj on fid.id_sj = tsj.id
            left join m_bongkar_muat mbm on tsj.id_obm = mbm.id
            where fid.id_invoice=".$id." and tsj.id_obm > 0");
    }

    function get_inv_creditmemo2($id){
        return $this->db->query("Select fis.*, tsj.no_kendaraan, mbm.harga as harga_obm, (fis.bruto * mbm.harga) as nilai_obm 
            From f_invoice_detail fis
            left join t_sj tsj on fis.id_sj = tsj.id
            left join m_bongkar_muat mbm on tsj.id_obm = mbm.id
            where fis.id_invoice=".$id." and tsj.id_obm > 0");
    }

    function get_tiket_sj($id){
        return $this->db->query("Select tiket, sum(tsj.nilai_tiket) as nilai_tiket, sum(tsjd.netto) as netto from f_invoice_detail fid
            left join t_sj tsj on fid.id_sj = tsj.id
            left join t_sj_details tsjd on tsj.id = tsjd.id_sj
            where fid.id_invoice =".$id." and tsj.tiket > 0 group by tsj.tiket");
    }

    function sj_customer_list($id){
        return $this->db->query("select tsj.*, bruto, netto, mb.nama_barang, ms.nama_supplier
            from t_sj_details tsd
            left join t_sj tsj on tsd.id_sj = tsj.id
            left join m_supplier ms on tsj.id_supplier = ms.id
            left join m_barang mb on tsd.id_jb = mb.id
            where id_customer=".$id." and tsj.id_invoice = 0
            group by tsd.id_sj");
    }

    function sj_inv_list($id){
        return $this->db->query("select tsj.*, bruto, netto, mb.nama_barang, ms.nama_supplier
            from t_sj_details tsd
            left join m_harga h on tsd.id = h.id
            left join t_sj tsj on tsd.id_sj = tsj.id
            left join m_supplier ms on tsj.id_supplier = ms.id
            left join m_barang mb on tsd.id_jb = mb.id
            where id_invoice=".$id."
            group by tsd.id_sj");
    }

    function get_data_sj($id){
        return $this->db->query("Select tsj.*, tsjd.harga, b.nama_barang, sum(netto) as netto, sum(bruto) as bruto from t_sj_details tsjd
            left join t_sj tsj on tsjd.id_sj = tsj.id
            left join m_barang b on tsjd.id_jb = b.id
            where tsjd.id_sj =".$id);
    }

    function get_data_sj_group($id){
        return $this->db->query("Select GROUP_CONCAT(no_surat_jalan SEPARATOR ' | ') as no_surat_jalan, 
                b.nama_barang,
                count(distinct tsjd.id_jb) as count_barang,
                GROUP_CONCAT(no_kendaraan SEPARATOR ' | ') as no_kendaraan,
                round(sum(tsjd.harga)/count(tsjd.id),0) as avg, sum(netto) as netto, sum(bruto) as bruto 
            from t_sj_details tsjd
                left join t_sj tsj on tsjd.id_sj = tsj.id
                left join m_barang b on tsjd.id_jb = b.id
            where tsjd.id_sj in (".$id.")");
    }

    function get_data_denda($id){
        return $this->db->query("Select tsj.*, tsjd.harga, b.nama_barang, sum(denda) as denda, sum(denda_1) as denda_1, sum(denda_2) as denda_2 from t_sj_details tsjd
            left join t_sj tsj on tsjd.id_sj = tsj.id
            left join m_barang b on tsjd.id_jb = b.id
            where tsjd.id_sj =".$id);
    }

    function get_jenis_denda($id,$jenis){
        if($jenis==1){
            $data = $this->db->query("Select tsj.id, tsj.no_surat_jalan, tsj.tanggal, tsj.jenis_kendaraan, tsj.no_kendaraan, tsjd.harga, b.nama_barang, tsj.denda_1 as denda from t_sj_details tsjd
            left join t_sj tsj on tsjd.id_sj = tsj.id
            left join m_barang b on tsjd.id_jb = b.id
            where tsjd.id_sj =".$id);
        }else{
            $data = $this->db->query("Select tsj.id, tsj.no_surat_jalan, tsj.tanggal, tsj.jenis_kendaraan, tsj.no_kendaraan, tsjd.harga, b.nama_barang, tsj.denda_2 as denda from t_sj_details tsjd
            left join t_sj tsj on tsjd.id_sj = tsj.id
            left join m_barang b on tsjd.id_jb = b.id
            where tsjd.id_sj =".$id);
        }
        return $data;
    }

    function get_group_inv_detail($uid,$id){
        return $this->db->query("Select fid.* From f_invoice_detail fid
            where fid.id_invoice =".$id." and uid='".$uid."'");
    }

    function get_data_denda_group($id){
        return $this->db->query("Select GROUP_CONCAT(no_surat_jalan SEPARATOR ' | ') as no_surat_jalan, 
                GROUP_CONCAT( DISTINCT b.nama_barang SEPARATOR ' | ') as nama_barang,
                GROUP_CONCAT(no_kendaraan SEPARATOR ' | ') as no_kendaraan,
                sum(denda) as denda, sum(denda_1) as denda_1, sum(denda_2) as denda_2
            from t_sj_details tsjd
                left join t_sj tsj on tsjd.id_sj = tsj.id
                left join m_barang b on tsjd.id_jb = b.id
            where tsjd.id_sj in (".$id.")");
    }

    /** Harga Jual */
    function get_harga_jual($id){
        $this->db->select('mhj.*, mb.nama_barang');
        $this->db->from('m_harga_jual mhj');
        $this->db->join('m_barang mb', 'mhj.id_barang=mb.id', 'left');
        $this->db->where('mhj.id_barang', $id);
        $this->db->order_by('mhj.tanggal', 'desc');
        $query = $this->db->get();
        return $query;
    }

    /** Bank */
    function bank_list(){
        $data = $this->db->query("SELECT * FROM m_bank");
        return $data;
    }

    /** Matching */
    function matching_header($id){
        $data = $this->db->query("select fm.*, ms.nama_supplier from f_match fm 
        left join m_supplier ms on ms.id = fm.id_supplier
        where fm.id =".$id);
        return $data;
    }

    function count_inv($id){
        $data = $this->db->query("SELECT fm.id, fm.no_matching, fm.keterangan, fm.tanggal, fm.status,
                coalesce(sum(CASE WHEN tsj.id_invoice > 0 THEN 1 ELSE 0 END),0) as c, ms.nama_supplier
            FROM f_match fm
            LEFT JOIN f_match_detail fmd on fm.id = fmd.id_match
            LEFT JOIN t_sj tsj on fmd.id_sj = tsj.id
            LEFT JOIN m_supplier ms on ms.id = fm.id_supplier
            where fm.id = ".$id."
            GROUP BY fm.id
            ORDER BY fm.tanggal desc
            ");
        return $data;
    }

    function view_matching_details($id){
        return $this->db->query("
            Select fmd.id, fmd.id_match, fmd.sj_bayar as nilai, fmd.sj_bayar,
                ( CASE 
                    WHEN fmd.jenis_pmb = 0 THEN tsj.no_surat_jalan
                    WHEN fmd.jenis_pmb = 1 THEN 'Potong Deposit'
                    WHEN fmd.jenis_pmb = 2 THEN 'Lebih Bayar'
                    WHEN fmd.jenis_pmb = 3 THEN 'Potong Lebih Bayar'
                    ELSE 'KOSONG' END
                ) as no_matching,
                ( CASE 
                    WHEN fmd.jenis_pmb = 0 THEN tsj.tanggal
                    WHEN fmd.jenis_pmb = 1 THEN fsd.tanggal
                    WHEN fmd.jenis_pmb = 2 THEN flb1.tanggal
                    WHEN fmd.jenis_pmb = 3 THEN flb.tanggal
                    ELSE '0000-00-00' END
                ) as tanggal, fmd.jenis_pmb, COALESCE(tsj.jenis_kendaraan,'') as jenis_kendaraan, COALESCE(tsj.no_kendaraan,'') as no_kendaraan, COALESCE(mb.nama_barang,'') as nama_barang, COALESCE(tsjd.netto,0) as netto
            From f_match_detail fmd
                Left Join t_sj tsj on fmd.jenis_pmb = 0 and fmd.id_sj = tsj.id
                Left Join t_sj_details tsjd on tsj.id = tsjd.id_sj
                Left Join m_barang mb on tsjd.id_jb = mb.id
                Left Join f_spl_deposit fsd on fmd.jenis_pmb = 1 and fmd.id_match = fsd.id
                Left Join f_spl_lebihbayar flb1 on fmd.jenis_pmb = 2 and fmd.id_sj = flb1.id
                Left Join f_spl_lebihbayar flb on fmd.jenis_pmb = 3 and fmd.id_match = flb.id
                where fmd.id_match =".$id);
    }

    /** Uang Keluar */
    function get_data_uk($s){
        return $this->db->query("SELECT * from f_uang_keluar WHERE id_supplier=".$s);
    }

    function load_inv_full($id,$id_pmb){
        $data = $this->db->query("SELECT fi.*, COALESCE((select count(id) from f_pmb_detail fpd where id_pmb = ".$id_pmb." and fpd.id_inv = fi.id),0) as count FROM f_invoice fi WHERE fi.status = 1 and fi.id_customer=".$id." and fi.flag = 0");
        return $data;
    }

    function get_data_inv($id){
        return $this->db->query("SELECT *, (nilai_invoice-nilai_bayar) as nilai_sisa FROM f_invoice WHERE id=".$id);
    }

    function load_inv_dtl($id){
        return $this->db->query("SELECT fpd.*, fi.nilai_bayar as nilai_bayar, coalesce(fi.no_invoice,fpd.keterangan) as no_invoice from f_pmb_detail fpd
        left join f_pmb fp on fp.id = fpd.id_pmb
        left join f_invoice fi on fpd.jenis = 0 and fi.id = fpd.id_inv
        where fpd.id_pmb =".$id);
    }
    
    function view_inv_data($id){
        return $this->db->query("SELECT fpmbd.*, fi.no_invoice, fi.nilai_invoice, fi.nilai_bayar,
            COALESCE((select sum(fpmbd2.inv_bayar) FROM f_pmb_detail fpmbd2 
                where fpmbd2.id_inv = fi.id and fpmbd2.id != fpmbd.id),0) as nilai_sdh_bayar 
        FROM f_pmb_detail fpmbd
        LEFT JOIN f_invoice fi on fi.id=fpmbd.id_inv 
        WHERE fpmbd.id=".$id." AND fpmbd.id_inv != 0");
    }
    
/** Uang Keluar */
    function list_uk(){
        return $this->db->query("SELECT fuk.*, ms.nama_supplier From f_uang_keluar fuk 
        LEFT JOIN m_supplier ms ON ms.id=fuk.id_supplier
        WHERE jenis = 0");
    }

    function list_deposit(){
        return $this->db->query("SELECT f.id, f.id_supplier, ms.nama_supplier, ms.nilai From f_spl_deposit f 
        LEFT JOIN m_supplier ms ON ms.id=f.id_supplier
        Group by f.id_supplier");
    }

    function list_deposit_detail($id){
        return $this->db->query("SELECT f.id, COALESCE(f.nomor, tsj.no_surat_jalan) as nomor, f.tanggal,
                    f.nilai, f.keterangan, f.jenis
                    From f_spl_deposit f
                    Left Join t_sj tsj on jenis = 1 and f.id_sj = tsj.id
                    Where f.id_supplier=".$id."
                    order by tanggal desc");
    }

    function get_uk($id){
        return $this->db->query("Select * From f_uang_keluar where id =".$id);
    }

    function check_deposit($id){
        return $this->db->query("Select * From f_spl_deposit where id_supplier = ".$id);
    }

    function get_deposit($id){
        return $this->db->query("Select * From f_spl_deposit where id = ".$id);
    }

    function get_deposit_sj($id){
        return $this->db->query("Select * From f_spl_deposit where id_sj = ".$id);
    }

    function get_lb_sj($id){
        return $this->db->query("Select * From f_spl_lebihbayar where id_sj = ".$id);
    }

/** Uang Keluar */
    function list_um(){
        return $this->db->query("SELECT fum.*, ms.nama_customer From f_uang_masuk fum
            LEFT JOIN m_customer ms ON ms.id=fum.id_customer");
    }

// SJ Matching SJ
    private function sj_list($params){
        $id = $params['id'];
        $idm = $params['idm'];
        // start datatables
        $this->column_order = array(null, 'mb.nama_barang', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan', 'tsd.netto','tsd.harga'); //set column field database for datatable orderable
        $this->column_search = array('tsj.no_surat_jalan' ,'mb.nama_barang', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan','tsd.netto','tsd.harga'); //set column field database for datatable searchable
        $this->order = array('tsj.tanggal' => 'asc'); // default order 

        $this->db->select(' tsj.id, tsj.no_surat_jalan, tsj.no_kendaraan, tsj.jenis_kendaraan, tsd.netto, mb.nama_barang,
                    COALESCE(
                        (select count(id) 
                        from f_match_detail 
                        where jenis_pmb = 0 and id_sj = tsj.id and id_match ='.$idm.'),0) as count,
                    (tsj.nilai-tsj.nilai_bayar-tsj.nilai_potong) as total');
        $this->db->from('t_sj tsj');
        $this->db->join('t_sj_details tsd', 'tsj.id = tsd.id_sj','left');
        $this->db->join('m_barang mb', 'tsd.id_jb = mb.id','left');
        $this->db->where('tsj.id_supplier',$id);
        $this->db->where('tsj.flag',0);
        $this->db->where('tsj.status',1);
    }

    private function sj_data_match($id){
        // start datatables
        $this->column_order = array(null, 'mb.nama_barang', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan', 'tsd.netto','tsd.harga'); //set column field database for datatable orderable
        $this->column_search = array('tsj.no_surat_jalan' ,'mb.nama_barang', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan','tsd.netto'); //set column field database for datatable searchable
        $this->order = array('tsj.tanggal' => 'asc'); // default order 

        $this->db->select('fmd.*, fmd.sj_bayar as total, tsj.no_surat_jalan,mb.nama_barang, tsj.no_kendaraan, tsj.jenis_kendaraan, tsd.netto');
        $this->db->from('f_match_detail fmd');
        $this->db->join('t_sj tsj', 'fmd.id_sj=tsj.id','left');
        $this->db->join('t_sj_details tsd', 'tsj.id = tsd.id_sj','left');
        $this->db->join('m_barang mb', 'tsd.id_jb = mb.id','left');
        $this->db->where('fmd.id_match',$id);
        $this->db->where('fmd.jenis_pmb',0);
    }
//SJ INDEX
    private function list_sj($id){
        // start datatables
        $this->column_order = array(null, 't.no_surat_jalan', 't.tanggal', 's.nama_supplier', 'gs.nama_group_supplier', 'c.kode_customer', 't.no_kendaraan', 't.jenis_kendaraan'); //set column field database for datatable orderable
        $this->column_search = array('t.no_surat_jalan', 't.tanggal', 's.nama_supplier', 'gs.nama_group_supplier', 'c.kode_customer', 't.no_kendaraan', 't.jenis_kendaraan'); //set column field database for datatable searchable
        $this->order = array('t.tanggal' => 'desc'); // default order 
     
        $this->db->select('t.*, s.nama_supplier, gs.nama_group_supplier, c.kode_customer, mbm.nama_bongkar_muat, mbm.harga as harga_bongkar_muat');
        $this->db->from('t_sj t');
        $this->db->join('m_supplier s', 't.id_supplier = s.id', 'left');
        $this->db->join('m_customer c', 't.id_customer = c.id', 'left');
        $this->db->join('m_group_supplier gs', 't.id_group_supplier = gs.id', 'left');
        $this->db->join('m_bongkar_muat mbm', 't.id_obm = mbm.id', 'left');
        if($id['supplier']!=0){
            $this->db->where('t.id_supplier',$id['supplier']);
        }
        if($id['gs']!=0){
            $this->db->where('t.id_group_supplier',$id['gs']);
        }
        if($id['cust']!=0){
            $this->db->where('t.id_customer',$id['cust']);
        }
        if(!empty($id['start']) && !empty($id['end'])){
            $this->db->where('t.tanggal >=', $id['start']);
            $this->db->where('t.tanggal <=', $id['end']);
        }
        $this->db->where('t.del',0);
    }

//OSSJ
    private function get_sj_belum_lunas($id){
        // start datatables
        $this->column_order = array(null, 'tsj.no_surat_jalan', 'tsj.tanggal', 's.nama_supplier','c.nama_customer', 'gs.nama_group_supplier', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan'); //set column field database for datatable orderable
        $this->column_search = array('tsj.no_surat_jalan', 'tsj.tanggal', 's.nama_supplier','c.nama_customer', 'gs.nama_group_supplier', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan'); //set column field database for datatable searchable
        $this->order = array('tsj.tanggal' => 'desc'); // default order 
     
        $this->db->select('tsj.*, s.nama_supplier, c.nama_customer, gs.nama_group_supplier, (tsj.nilai-tsj.nilai_bayar-tsj.nilai_potong) as nilai_sisa');
        $this->db->from('t_sj tsj');
        $this->db->join('m_supplier s', 'tsj.id_supplier = s.id', 'left');
        $this->db->join('m_customer c', 'tsj.id_customer = c.id', 'left');
        $this->db->join('m_group_supplier gs', 'tsj.id_group_supplier = gs.id', 'left');
        $this->db->where('status',1);
        if($id['supplier']!=0){
            $this->db->where('tsj.id_supplier',$id['supplier']);
        }
        if($id['gs']!=0){
            $this->db->where('tsj.id_group_supplier',$id['gs']);
        }
        if($id['customer']!=0){
            $this->db->where('tsj.id_customer',$id['customer']);
        }
        if(!empty($id['start']) && !empty($id['end'])){
            $this->db->where('tsj.tanggal >=', $id['start']);
            $this->db->where('tsj.tanggal <=', $id['end']);
        }
        $this->db->where('tsj.flag',0);
    }

// DI INVOICE
    private function inv_list_di_sj($id){
        // start datatables
        $this->column_order = array(null, 'mb.nama_barang', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan', 'fid.netto', 'fid.harga'); //set column field database for datatable orderable
        $this->column_search = array('mb.nama_barang', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan','fid.netto', 'fid.harga'); //set column field database for datatable searchable
        $this->order = array('tsj.tanggal' => 'asc'); // default order 
     
        $this->db->select('tsj.*, fid.bruto, fid.netto, mb.nama_barang, fid.harga');
        $this->db->from('f_invoice_detail fid');
        $this->db->join('t_sj_details tsd', 'fid.id_sj_detail = tsd.id','left');
        $this->db->join('t_sj tsj', 'tsd.id_sj = tsj.id','left');
        $this->db->join('m_barang mb', 'tsd.id_jb = mb.id','left');
        $this->db->where('tsj.id_invoice',$id);
        $this->db->group_by('tsd.id_sj');
        $this->db->order_by('fid.modified');
    }

    private function inv_list_di_sj2($id){
        // start datatables
        $this->column_order = array(null, 'mb.nama_barang', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan', 'fid.harga'); //set column field database for datatable orderable
        $this->column_search = array('mb.nama_barang', 'tsj.no_kendaraan', 'tsj.jenis_kendaraan', 'fid.harga'); //set column field database for datatable searchable
        $this->order = array('tsj.tanggal' => 'asc'); // default order 
     
        $this->db->select('fid.uid, sum(fid.bruto) as bruto, sum(fid.netto) as netto, mb.nama_barang, fid.harga');
        $this->db->from('f_invoice_detail fid');
        $this->db->join('t_sj_details tsd', 'fid.id_sj_detail = tsd.id','left');
        $this->db->join('t_sj tsj', 'tsd.id_sj = tsj.id','left');
        $this->db->join('m_barang mb', 'tsd.id_jb = mb.id','left');
        $this->db->where('tsj.id_invoice',$id);
        // $this->db->group_by('tsd.id_sj');
        $this->db->group_by('fid.modified');
        $this->db->order_by('fid.modified');
    }

// DI SJ
    private function denda_sj_list_di_inv($id){
        // start datatables
        $this->column_order = array(null, 'no_surat_jalan', 'nama_barang', 'tanggal', 'no_kendaraan', 'denda'); //set column field database for datatable orderable
        $this->column_search = array('no_surat_jalan', 'nama_barang', 'tanggal', 'no_kendaraan','denda'); //set column field database for datatable searchable
        $this->order = array('tanggal' => 'asc'); // default order 
     
        // $this->db->select('tsj.*, bruto, netto, mb.nama_barang, tsd.harga');
        // $this->db->from('t_sj_details tsd');
        // $this->db->join('t_sj tsj', 'tsd.id_sj = tsj.id','left');
        // $this->db->join('m_barang mb', 'tsd.id_jb = mb.id','left');
        // $this->db->where('id_customer',$id[0]);
        // $this->db->where('tsj.denda >',0);
        // $this->db->where('tsj.flag_denda',0);
        // if(isset($id[1]) && isset($id[2])){
        //     $this->db->where('tsj.tanggal >=', $id[1]);
        //     $this->db->where('tsj.tanggal <=', $id[2]);
        // }
        // $this->db->group_by('tsd.id_sj');

        $this->db->select('*');
        $this->db->from('list_denda_view');
        $this->db->where('id_customer',$id[0]);
        if(isset($id[1]) && isset($id[2])){
            $this->db->where('tanggal >=', $id[1]);
            $this->db->where('tanggal <=', $id[2]);
        }

    }

    private function list_denda_di_inv($id){
        // start datatables
        $this->column_order = array(null, 'tsj.no_surat_jalan', 'mb.nama_barang', 'tsj.tanggal', 'tsj.no_kendaraan', 'fis.denda'); //set column field database for datatable orderable
        $this->column_search = array('tsj.no_surat_jalan', 'mb.nama_barang', 'tsj.tanggal', 'tsj.no_kendaraan','fis.denda'); //set column field database for datatable searchable
        $this->order = array('tsj.tanggal' => 'asc'); // default order 
     
        $this->db->select('fis.id, fis.id_sj, fis.jenis, tsj.no_surat_jalan, tsj.tanggal, tsj.no_kendaraan, tsj.jenis_kendaraan, mb.nama_barang,
            (CASE WHEN fis.jenis=1 THEN "Denda" ELSE "Denda K3" END) as nomor,
            (CASE WHEN fis.jenis=1 THEN tsj.denda_1 ELSE tsj.denda_2 END) as denda',FALSE);
        $this->db->from('f_invoice_summary fis');
        $this->db->join('t_sj tsj', 'fis.id_sj = tsj.id','left');
        $this->db->join('m_barang mb', 'fis.id_jb = mb.id','left');
        $this->db->where('fis.id_invoice',$id);
        $this->db->where_in('fis.jenis',[1,2]);
    }

    private function sj_list_di_inv($id){
        // start datatables
        $this->column_order = array(null, 'mb.nama_barang', 'tsj.tanggal', 'tsj.no_kendaraan', 'tsd.netto', 'tsd.harga'); //set column field database for datatable orderable
        $this->column_search = array('mb.nama_barang', 'tsj.tanggal', 'tsj.no_kendaraan', 'tsd.netto','tsd.harga'); //set column field database for datatable searchable
        $this->order = array('tsj.tanggal' => 'asc'); // default order 
     
        $this->db->select('tsj.*, bruto, netto, mb.nama_barang, tsd.harga');
        $this->db->from('t_sj_details tsd');
        $this->db->join('t_sj tsj', 'tsd.id_sj = tsj.id','left');
        $this->db->join('m_barang mb', 'tsd.id_jb = mb.id','left');
        $this->db->where('id_customer',$id['id']);
        $this->db->where('tsj.id_invoice',0);
        if($id['id_jb']!=0){
            $this->db->where('tsd.id_jb',$id['id_jb']);
        }
        if(!empty($id['s']) && !empty($id['e'])){
            $this->db->where('tsj.tanggal >=', $id['s']);
            $this->db->where('tsj.tanggal <=', $id['e']);
        }
        $this->db->group_by('tsd.id_sj');
    }

    private function _get_datatables_query($id,$func_name) {
        $this->$func_name($id);

        $i = 0;

        foreach ($this->column_search as $item) { // loop column 
            if(@$_POST['search']['value']) { // if datatable send POST for search
                if($i===0) { // first loop
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                } else {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
                if(count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }

        if(isset($_POST['order'])) { // here order processing
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        }  else if(isset($this->order)) {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function get_datatables($id,$func_name) {
        $this->_get_datatables_query($id,$func_name);
        if(@$_POST['length'] != -1)
        $this->db->limit(@$_POST['length'], @$_POST['start']);
        $query = $this->db->get();
        $data['data'] = $query->result();

        $this->_get_datatables_query($id,$func_name);
        $query = $this->db->get();
        $data['count_filtered'] = $query->num_rows();

        $this->$func_name($id);
        $query2 = $this->db;
        $data['count_all'] = $query2->count_all_results();
        return $data;
    }
    // function count_filtered($id) {
    //     $this->_get_datatables_query($id);
    //     $query = $this->db->get();
    //     return $query->num_rows();
    // }
    // function count_all() {
    //     $this->db->from('t_sj_details');
    //     return $this->db->count_all_results();
    // }
    // end datatables
}
