<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Deposit</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= site_url('Finance/deposit')?>">Deposit</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-check"></i> Sukses</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-ban"></i> Gagal</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Data Deposit</h3>
              <div class="card-tools">
                <a class="btn btn-block btn-primary btn-sm" id="tambah" href="<?=base_url();?>Finance/addDeposit"><i class="fa fa-plus"></i> Tambah</a>
              </div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example2" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <td>No</td>
                  <td>No Deposit</td>
                  <td>Tanggal</td>
                  <td>Nominal</td>
                  <td>Keterangan</td>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody>
                <?php 
                $no=1;
                foreach ($list_data as $key => $v) { ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $v->nomor ?></td>
                    <td><?= $v->tanggal ?></td>
                    <?php
                    $bg = 'bg-danger';
                    if($v->jenis==0){ 
                      $bg = 'bg-success';
                    }
                    ?>
                    <td class="text-right <?=$bg;?>">
                      <?= number_format($v->nilai,2,',','.') ?>
                    </td>
                    <td><?= $v->keterangan ?></td>
                    <td>
                      <a class="btn btn-info btn-sm" href="<?= site_url('Finance/view_uang_keluar/'.$v->id)?>"><i class="fa fa-file-alt"></i> View</a>
                      <a class="btn btn-primary btn-sm" href="<?=base_url().'Finance/print_uang_keluar/'.$v->id;?>" onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-print"></i> Print</a> 
                      <?php if($v->jenis==0){?>
                        |
                        <a class="btn btn-danger btn-sm" href="<?=base_url().'Finance/delete_deposit/'.$v->id;?>" onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-trash"></i> Delete</a>
                      <?php } ?>
                    </td>
                </tr>
                <?php }?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
          <div class="card-footer">
            <a class="btn btn-default btn-sm" href="<?= site_url('Finance/deposit')?>"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>