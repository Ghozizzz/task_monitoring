<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Pembayaran</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url('Finance/Pembayaran');?>">Pembayaran</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="no_pembayaran">No. Pembayaran</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="no_pembayaran" id="no_pembayaran" value="<?=$h['no_pembayaran'];?>" disabled>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="group_supplier">Group Supplier</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="group_supplier" id="group_supplier" value="<?=$h['nama_group_supplier'];?>" disabled>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="supplier">Supplier</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="supplier" id="supplier" value="<?=$h['nama_supplier'];?>" disabled>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Tanggal</label>
                                    </div>
                                    <div class="col-md-8">
                                    <div class="input-group date" id="date_id" data-target-input="nearest">
                                        <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" readonly />
                                        <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                        </div>
                                    </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-5">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="nominal">Nominal (IDR)</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="nominal" id="nominal" value="<?=number_format($h['nominal'],2,',','.')?>" disabled>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="jenis_pembayaran">Jenis Pembayaran</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="jenis_pembayaran" id="jenis_pembayaran" value="<?=$h['jenis_pembayaran'];?>" disabled>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="bank_id">Bank</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="bank_id" id="bank_id" value="<?=$h['nama_bank'];?>" disabled>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label for="m_invoice">Matching Invoice</label>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" class="form-control" name="m_invoice" id="m_invoice" value="<?=$h['no_matching'];?>" disabled>
                                    </div>
                                    <div class="col-md-2">
                                        <a class="btn btn-primary btn-sm" href="<?= site_url('Finance/view_matching/'.$h['id_matching'])?>"><i class="fa fa-file"></i> View</a>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Keterangan</label>
                                    </div>
                                    <div class="col-md-8">
                                        <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" readonly><?=$h['keterangan'];?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <a href="<?php echo base_url('Finance'); ?>" class="btn btn-primary"> 
                        <i class="fa fa-angle-left"></i> Kembali 
                    </a>
                    <a href="javascript:;" class="btn btn-info" id="editData" onclick="editData();" style="margin-left: 3px;"> 
                        <i class="fa fa-edit"></i> Edit 
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
function editData(){
    $("#editData").hide();
    <?php if($myData['flag_matching']==0){ ?>
    $("#nominal").prop('readonly', false);
    $("#customer_id").prop('disabled', false);
    $("#id_bank").attr("disabled", false);
    $("#tanggal").attr("readonly", false);
    $("#no_um").attr('readonly', false);
    <?php } ?>
    $("#remarks").attr("readonly", false);
    $("#tanggal").datepicker({
        showOn: "button",
        buttonImage: "<?php echo base_url(); ?>img/Kalender.png",
        buttonImageOnly: true,
        buttonText: "Select date",
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy'
    });      
    if($("#jenis").val()=="Cek"){
        $("#nama_bank").attr("readonly", false);
        $("#nomor_cek").prop('readonly', false);
    }else if($("jenis").val()=="Giro"){
        $("#no_rek").prop('readonly', false);
    }
    $("#saveData").show();
}
</script>