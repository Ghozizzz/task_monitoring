<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Input PO</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan/invoice">Purchase Order</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Form</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=base_url('Finance/save_po');?>">    
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-4">
                        <label>No. PO</label>
                        </div>
                        <div class="col-md-8">
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                            <span class="input-group-text">PO-</span>
                            </div>
                            <input type="text" class="form-control" name="no_po" id="no_po" placeholder="No. PO ...">
                        </div>
                        </div>
                    </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal PO</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                          <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." />
                          <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Supplier</label>
                    </div>
                    <div class="col-md-8">
                      <select class="supplier form-control select2bs4" name="supplier" id="supplier" style="width: 100%;" onchange="get_no_sj(this.value)">
                          <option value="0">Silahkan Pilih ...</option>
                          <?php foreach($supplier as $row) {
                            echo '<option value="'.$row->id.'">'.$row->nama_supplier.'</option>';
                          }?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                    <!-- <div class="row mb-3">
                        <div class="col-md-4">
                            <label>Tanggal Jatuh Tempo</label>
                        </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_jt" data-target-input="nearest">
                          <input type="text" name="tanggal_jt" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_jt" placeholder="Tanggal ..." />
                          <div class="input-group-append" data-target="#date_jt" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>-->
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label>Catatan</label>
                        </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Catatan"></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                <button type="button" class="btn btn-primary float-right" onclick="simpanData();"><i class="fa fa-save"></i> Save</button>
                <a href="<?= site_url('Finance/po')?>" class="btn btn-info float-right" style="margin-right:5px;"> 
                    <i class="fa fa-angle-left"></i> Kembali 
                </a>
            </div>
          </form>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<script>
function simpanData(){
  if($.trim($("#no_po").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' No PO harus diisi'
    });
  } else if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal PO harus diisi'
    });
  } else if($.trim($("#supplier").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Supplier harus diisi'
    });
  }else if($.trim($("#keterangan").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Keterangan harus diisi'
    });
  }else{
    $(this).prop('disabled', true).text('Please Wait ...');
    $('#formku').submit();
  }
};

function get_no_sj(id){
    $.ajax({
        url: "<?php echo base_url('Finance/get_sj_list'); ?>",
        type: "POST",
        data: "id="+id,
        dataType: "html",
        success: function(result) {
            console.log(result);
            $('#surat_jalan_id').html(result);
            $('#surat_jalan_id').select2('val','');
        }
    });
}
</script>