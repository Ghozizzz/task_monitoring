<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Rekap Supplier</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= site_url('RekapSupplier') ?>">Rekap Supplier</a></li>
          <li class="breadcrumb-item active">Laporan</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-check"></i> Sukses</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Gagal</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Rekap Supplier</h3>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="row">
                      <div class="col-md-4">
                        Rekap <font color="#f00">*</font>
                      </div>
                      <div class="col-md-8 mb-3">
                        <select name="jenis" id="jenis" class="form-control select2bs4" data-placeholder="Pilih..." style="width: 100%;margin-bottom:5px;" onchange="get_group(this.value)">
                          <option value="0">--Pilih--</option>
                          <option value="1">Global</option>
                          <option value="2">Order By Group Supplier</option>
                        </select>
                      </div>
                    </div>
                    <div class="row mb-3" id="show_group">
                    <div class="col-md-4">
                        Group Supplier <font color="#f00">*</font>
                    </div>
                    <div class="col-md-8">
                        <select id="group" name="group" class="form-control select2bs4" style="margin-bottom:5px;width:100%;">
                            <option value="0">Silahkan Pilih...</option>
                            <?php
                                foreach ($gs as $row){
                                    echo '<option value="'.$row->id.'">'.$row->nama_group_supplier.'</option>';
                                }
                            ?>
                        </select>
                    </div>
                  </div>
                    <div class="row">
                        <div class="col-md-4">
                            Bulan <font color="#f00">*</font>
                        </div>
                        <div class="col-md-8 mb-3">
                            <select id="bulan" name="bulan" class="form-control select2bs4" data-placeholder="Pilih..." style="margin-bottom:5px;width:100%;">
                                <option value="01">Januari</option>
                                <option value="02">Februari</option>
                                <option value="03">Maret</option>
                                <option value="04">April</option>
                                <option value="05">Mei</option>
                                <option value="06">Juni</option>
                                <option value="07">Juli</option>
                                <option value="08">Agustus</option>
                                <option value="09">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            Tahun <font color="#f00">*</font>
                        </div>
                        <div class="col-md-8">
                            <input type="text" class="form-control" style="margin-bottom:5px" id="tahun" name="tahun" maxlength="4" value="<?=date('Y');?>">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            &nbsp;
                        </div>
                        <div class="col-md-8">
                            <a href="javascript:;" class="btn btn-success" id="proses_button" onclick="cariData();"> 
                                <i class="fa fa-search"></i> Proses 
                            </a>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<script>
function get_group(id){
    if(id == "1"){
        $('#show_group').hide();
    }else if(id === "2") {
        $('#show_group').show();
    }
};

function cariData(){
    if($.trim($("#bulan").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Bulan harus diisi'
    });
    }else if($.trim($("#tahun").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tahun harus diisi'
    });
    }else{
        var j=$('#jenis').val();
        var g=$('#group').val();   
        var b=$('#bulan').val();
        var t=$('#tahun').val();
        window.open('<?= site_url();?>Finance/proses_rekap?j='+j+'&g='+g+'&b='+b+'&t='+t,'_blank');
    };
};

$(function(){
  $('#show_group').hide();
})
</script>