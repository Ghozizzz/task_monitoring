<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Tambah Invoice</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan">Invoice</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-check"></i> Sukses</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-ban"></i> Gagal</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Form</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=base_url('Finance/saveInvoice');?>">    
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>No. Invoice</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group mb-3">
                        <!-- <div class="input-group-prepend">
                          <span class="input-group-text">INV-</span>
                        </div> -->
                        <input type="text" class="form-control" name="no_invoice" id="no_invoice" placeholder="No Invoice ...">
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                      <!-- <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                        </div>
                        <input type="text" name="tanggal" id="tanggal_dm" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                      </div> -->
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                          <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." />
                          <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Term Of Payment</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="term_of_payment" id="term_of_payment" placeholder="Term Of Payment ...">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Customer</label>
                    </div>
                    <div class="col-md-8">
                      <select class="form-control select2bs4" name="customer" id="customer">
                          <option value="0">Silahkan Pilih ...</option>
                          <?php foreach ($customer as $key => $v) {
                              echo '<option value="'.$v->id.'">'.$v->nama_customer.'</option>';
                          }?>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>PPN</label>
                    </div>
                    <div class="col-md-8">
                      <select class="form-control" name="ppn" id="ppn">
                          <option value="0">No</option>
                          <option value="1">Yes</option>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Bunga</label>
                    </div>
                    <div class="col-md-8">
                      <input type="number" class="form-control" name="bunga" id="bunga" placeholder="Bunga ...">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="button" class="btn btn-primary float-right" id="saveData"><i class="fa fa-save"></i> &nbsp;Submit</button>
            </div>
          </form>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<script>
$("#saveData").click(function(){

  if($.trim($("#no_invoice").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Nomor Invoice harus diisi'
    });
  }else if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  }else if($.trim($("#customer").val()) == 0){
    Toast.fire({
      icon: 'error',
      title: ' Customer harus diisi'
    });
  }else{
    $(this).prop('disabled', true).text('Please Wait ...');
    $('#formku').submit();
  }
});

function get_no_sj(id){
  $.ajax({
    url: "<?=base_url('Finance/get_sj_list'); ?>",
    type: "POST",
    data: "id="+id,
    dataType: "html",
    success: function(result) {
      $('#surat_jalan_id').html(result);
    }
  });
}

function get_customer(id){
  $.ajax({
    url: "<?=base_url('Finance/get_customer_sj'); ?>",
    type: "POST",
    data: "id="+id,
    dataType: "json",
    success: function(result) {
      $('#customer').val(result['nama_customer']);
      $('#id_customer').val(result['id_customer']);
    }
  });
}
</script>