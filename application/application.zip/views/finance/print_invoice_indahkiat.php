<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
    <body class="margin-left:40px;">
        <table border="0" cellpadding="2" cellspacing="0" width="900px" style="font-family:Microsoft Sans Serif: font-size: 12px;">
            <tr>
                <td colspan="3" style="border-bottom: 1px solid #000;">
                    <h3 style="text-align: center; margin-bottom: 0px;">
                        PT. YAPUTRA ABADI PERKASA<br>
                        PERKANTORAN RUKO TOMANG TOL RAYA BLOK A1 No 50 RT 009 RW 004<br>
                        JAKARTA BARAT
                    </h3>
                </td>
            </tr>
            <tr>
                <td colspan="3">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%">
                        <tr>
                            <td width="50%">Kepada Yth :</td>
                            <td width="25%">INVOICE NO</td>
                            <td width="25%">: <?=$h['no_invoice'];?></td>
                        </tr>
                        <tr>
                            <td colspan="3"><?=$h['nama_customer'];?></td>
                        </tr>
                        <tr>
                            <td width="50%"><?=$h['alamat'];?></td>
                            <td width="25%">TANGGAL</td>
                            <td width="25%">: <?=tanggal_indo($h['tanggal']);?></td>
                        </tr>
                        <tr>
                            <td colspan="3">&nbsp;</td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="3">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" cellpadding="4" cellspacing="0" width="100%" style="font-family:Arial; font-size: 14px">
                        <tr>
                            <td width="5%" style="text-align:center;"><strong>No.</strong></td>
                            <td width="30%"><strong>Nama Barang</strong></td>
                            <th colspan="2" width="15%" style="text-align:center;"><strong>Qty</strong></th>
                            <th colspan="2" width="15%" style="text-align:center;"><strong>Harga @</strong></th>
                            <td colspan="2" width="25%" style="text-align:center;"><strong>Jumlah</strong></td>
                        </tr>
                        <?php
                            $no = 1;
                            $netto = 0;
                            $bruto = 0;
                            $total_amount = 0;
                            foreach ($details as $row){
                        ?>
                        <tr>
                            <td style="text-align:right; "><?=$no;?></td>
                            <td><?=$row->nama_barang;?></td>
                            <td>:</td>
                            <td style="text-align:right;"><?=number_format($row->netto,2,',','.');?> kg @</td>
                            <td>Rp</td>
                            <td style="text-align:right;"><?=number_format($row->harga,2,',','.');?></td>
                            <td>Rp</td>
                            <td style="text-align:right;">
                                <?=number_format($row->sub_total+$row->adjustment,2,',','.');?>
                            </td>
                        </tr>
                        <?php
                                $netto += $row->netto;
                                $bruto += $row->bruto;
                                $total_amount += $row->sub_total+$row->adjustment;
                                $no++;
                            }
                        ?>
                        <tr style="height:50px">
                            <td colspan="8">&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align:left;"></td>
                            <td colspan="3" style="text-align:left">JUMLAH POKOK</td>
                            <td style="border-top: 1px solid #000;">Rp</td>
                            <td style="text-align:right; border-top: 1px solid #000;">
                                <?=number_format($total_amount,2,',','.');?>
                            </td>
                        </tr>
                        <?php 
                        if ($h['ppn']==1) {
                            $ppn = $total_amount * 10 / 100;
                        }else{
                            $ppn = 0;
                        } 
                        $grand_total = $total_amount + $ppn;
                        ?>
                        <tr>
                            <td colspan="3" style="text-align:left;"></td>
                            <td colspan="3" style="text-align:left">Ppn 10%</td>
                            <td>Rp</td>
                            <td style="text-align:right;">
                                <?=number_format($ppn,2,',','.');?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align:left;"></td>
                            <td colspan="3" style="text-align:left"><strong>Jumlah Pokok + Ppn</strong></td>
                            <td style="border-top: 1px solid #000;">Rp</td>
                            <td style="text-align:right; border-top: 1px solid #000;">
                                <?=number_format($grand_total,2,',','.');?>
                            </td>
                        </tr>
                        <?php
                    if(!empty($tiket)){
                      foreach($tiket as $t){ 
                        $grand_total -= $t->nilai_tiket; ?>
                        <tr>
                            <td colspan="2">TIKET LUAR PULAU</td>
                            <td>:</td>
                            <td align="right"><?=number_format($t->netto,2,',','.');?> kg @</td>
                            <td>Rp</td>
                            <td align="right"><?=number_format($t->tiket,2,',','.');?></td>
                            <td>Rp</td>
                            <td align="right"><?=number_format($t->nilai_tiket,2,',','.');?></td>
                        </tr>
                    <?php } 
                    }
                    foreach($loop_obm as $o){
                        $data_obm[$o->id]['bruto']=0;
                        $data_obm[$o->id]['harga']=$o->harga;
                        $data_obm[$o->id]['nilai_obm']=0;
                    }

                        foreach($list_obm as $o){ 
                          if($o->harga > 0){
                            $data_obm[$o->id_obm]['bruto']+=$o->bruto;
                            $data_obm[$o->id_obm]['harga']=$o->harga;
                            $nilai_obm=$o->bruto * $o->harga;
                            $data_obm[$o->id_obm]['nilai_obm']+=$nilai_obm;
                            $grand_total -= $nilai_obm;
                          } 
                        }
                        foreach($loop_obm as $o){ 
                    ?>
                        <tr>
                            <td colspan="2">ONGKOS BONGKAR <?=$o->nama_bongkar_muat;?></td>
                            <td>:</td>
                            <td align="right"><?=number_format($data_obm[$o->id]['bruto'],2,',','.');?> kg @</td>
                            <td>Rp</td>
                            <td align="right"><?=number_format($data_obm[$o->id]['harga'],2,',','.');?></td>
                            <td>Rp</td>
                            <td align="right"><?=number_format($data_obm[$o->id]['nilai_obm'],2,',','.');?></td>
                        </tr>
                    <?php
                        }
                    if(!empty($list_denda)) { 
                        foreach ($list_denda as $val) {
                            $grand_total -= $val->total_denda;
                            if($val->denda>0){
                    ?>
                        <tr>
                            <td colspan="2">DENDA</td>
                            <td>:</td>
                            <td colspan="3"></td>
                            <td>Rp</td>
                            <td align="right"><?=number_format($val->denda,2,',','.');?></td>
                        </tr>
                    <?php   }
                            if($val->denda_k3>0){ ?>
                        <tr>
                            <td colspan="2">DENDA K3</td>
                            <td>:</td>
                            <td colspan="3"></td>
                            <td>Rp</td>
                            <td align="right"><?=number_format($val->denda_k3,2,',','.');?></td>
                        </tr>
                    <?php
                            }
                        }
                    } ?>
                        <tr>
                            <td colspan="8" style="height: 50px"></td>
                        </tr>
                        <tr>
                            <td colspan="6" align="center"><strong>TOTAL</strong></td>
                            <td style="border-left: 1px solid #000; border-top: 1px solid #000; border-bottom: 1px solid #000;"><strong>Rp</strong></td>
                            <td align="right" style="border-right: 1px solid #000; border-top: 1px solid #000; border-bottom: 1px solid #000;"><strong><?=number_format($grand_total,2,',','.');?></strong></td>
                        </tr>
                        <tr>
                            <td colspan="8">
                                <table border="0" width="100%">
                                    <tr>
                                        <td width="28%" style="text-align:left;">Terbilang</td>
                                        <td width="2%">:</td>
                                        <td width="60%"><?=ucwords(number_to_words($grand_total)); ?></td>
                                        <td width="10%">&nbsp;</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="8">
                                <table border="0" width="100%" style="font-size: 16px">
                                    <tr>
                                        <td width="28%" style="text-align:left;">TUJUAN BARANG</td>
                                        <td width="2%">:</td>
                                        <td width="45%"><?=$h['nama_customer'];?></td>
                                        <td width="25%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="28%" style="text-align:left;">PLACE OF RECEIPT</td>
                                        <td width="2%">:</td>
                                        <td width="45%">INDONESIA</td>
                                        <td width="25%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="28%" style="text-align:left;">NEGARA ASAL BARANG</td>
                                        <td width="2%">:</td>
                                        <td width="45%">INDONESIA</td>
                                        <td width="25%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="28%" style="text-align:left;">SHIPPING TERMS</td>
                                        <td width="2%">:</td>
                                        <td width="45%">FRANCO PT. INDAH KIAT SERANG MILL</td>
                                        <td width="25%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="28%" style="text-align:left;">SYARAT PEMBAYARAN</td>
                                        <td width="2%">:</td>
                                        <td colspan="2" width="70%">SKBDN BERJANGKA 180 HARI DARI TANGGAL FAKTUR/INVOICE</td>
                                    </tr>
                                    <tr>
                                        <td width="28%" style="text-align:left;"><strong>NOMOR SKBDN</strong></td>
                                        <td width="2%"><strong>:</strong></td>
                                        <td width="45%"><strong><?=$h['no_skbdn'];?></strong></td>
                                        <td width="25%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="5" style="height: 50px;">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">&nbsp;</td>
                                        <td align="center">
                                            Hormat Kami
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" style="height: 75px;">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">&nbsp;</td>
                                        <td align="center" style="font-family: Calibri">
                                            PIT RUDYANTO
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <p>&nbsp;</p>
    <body onLoad="window.print()">
    </body>
</html>