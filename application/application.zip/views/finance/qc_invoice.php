<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Detail Invoice</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan">Invoice</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
  <div class="container-fluid">
    <form class="eventInsForm" method="post" target="_self" name="formku" id="formku">
    <input type="hidden" id="id" name="id" value="<?=$h['id'];?>">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <!-- /.card-header -->
          <!-- form start -->   
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>No Invoice</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_invoice" id="no_invoice" value="<?=$h['no_invoice'];?>">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                          <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>"/>
                          <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Term Of Payment</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="term_of_payment" id="term_of_payment" value="<?=$h['term_of_payment'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" readonly><?=$h['keterangan'];?></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Customer</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="customer" id="customer" value="<?=$h['nama_customer'];?>" disabled>
                    </div>
                    <input type="hidden" id="jenis_customer" name="jenis_customer" value="<?=$h['jenis_customer'];?>">
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>PPN</label>
                    </div>
                    <div class="col-md-8">
                      <select class="form-control" name="ppn" id="ppn">
                          <option value="0" <?=($h['ppn']==0)?'selected':'';?>>No</option>
                          <option value="1" <?=($h['ppn']==1)?'selected':'';?>>Yes</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Details</h3>

            <div class="card-tools">
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body table-responsive p-0">
            <table id="dt_simple" class="table table_lowm table-bordered">
              <thead>
                <tr>
                  <th>No</th>
                  <th width="25%">Barang</th>
                  <th width="10%">Netto</th>
                  <th width="10%">Harga Jual</th>
                  <th width="15%">Harga Manual<br><small>*yang tampil di print</small></th>
                  <th width="15%">Sub Total</th>
                  <th width="20%">Adjustment  Sub Total</th>
                </tr>
              </thead>
              <tbody>
              <?php
                $no = 1;
                $total_all = 0;
                $sub_total = 0;
                $bruto = 0;

                foreach ($list_data as $row) 
                {
                  $bruto += $row->bruto;
                  $sub_total = $row->harga * $row->netto;
                  echo '<tr>';
                  echo '<input type="hidden" name="details['.$no.'][id]" value="'.$row->id.'">';
                  echo '<input type="hidden" name="details['.$no.'][harga]" value="'.$row->harga.'">';
                  echo '<td style="text-align:center">'.$no.'</td>';
                  echo '<td>'.$row->nama_barang.'</td>';
                  echo '<input type="hidden" id="netto" name="details['.$no.'][netto]" value="'.$row->netto.'">';
                  echo '<td class="text-right">'.number_format($row->netto,2,',','.').'</td>';
                  echo '<td><input type="text" class="form-control myline text-right" style="margin-bottom:5px" name="details['.$no.'][harga_jual]" value="'.$row->harga.'"></td>';
                  echo '<td><input type="text" class="form-control myline text-right" style="margin-bottom:5px" name="details['.$no.'][harga_manual]" value="'.$row->harga_manual.'"></td>';
                  echo '<td class="text-right">'.number_format($row->sub_total,2,',','.').'</td>';
                  echo '<td><input type="text" class="form-control myline text-right" style="margin-bottom:5px" name="details['.$no.'][adjustment]" value="'.$row->adjustment.'"></td>';
                  echo '</tr>';
                  $no++;
                  $total_all += $sub_total;
                }
                ?>
                    <tr>
                        <td colspan="2" class="text-right">Total Netto</td>
                        <td class="text-right"><?=number_format($bruto,2,',','.');?></td>
                        <td colspan="2"></td>
                        <td class="text-right"><?=number_format($total_all,2,',','.');?></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td colspan="7"></td>
                    </tr>
                    <input type="hidden" name="total" id="total" value="<?= $total_all ?>">
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <a href="<?= site_url('Finance/Invoice')?>" class="btn btn-default m-1 mb-3"> 
            <i class="fa fa-angle-left"></i> Kembali 
        </a>
        <button type="button" class="btn btn-info m-1 mb-3" id="editData"><i class="fa fa-edit"></i> Edit Ulang</button>
        <div class="float-right">
          <button type="button" class="btn btn-success" id="updateData"><i class="fa fa-save"></i> Update</button>
          <a href="<?=base_url();?>Finance/add_denda_invoice/<?=$h['id'];?>" class="btn btn-warning"><i class="fa fa-plus"></i> Tambah Denda</a>
        </div>
      </div>
    </div>
    </form>
  </div>
</section>
<script>
$("#updateData").click(function(){
  $('#formku').attr("action", "<?=base_url();?>Finance/update_invoice");    
  $('#formku').submit();
});

$("#editData").click(function(){
  var r = confirm("Anda yakin ingin edit ulang list ini ?");
  if (r == true) {
    $('#formku').attr("action", "<?=base_url();?>Finance/back_edit_invoice");    
    $('#formku').submit();
  }
});
</script>