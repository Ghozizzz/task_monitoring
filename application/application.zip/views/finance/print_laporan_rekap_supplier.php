<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
<body class="margin-left:40px;">
 <table width="100%" >
    <tr>
        <td width="34%" align="center">
        <h4>Laporan Rekap Supplier Global Bulan <?= $time; ?></h4></td>
    </tr>
 </table>
<table width="100%" class="table" style="font-size: 16px;" border="2">
    <thead>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">No.</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Tanggal</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Nama Supplier</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">No Mobil</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Netto</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Potongan</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Bruto</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Jenis</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">OBM</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Harga</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Denda</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Total</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">Rekapan</th>
        <th style="border-top: 1px solid; border-bottom: 1px solid;">BB</th>
    </thead>
    <tbody>
    <?php
    $no=1;
    foreach ($detailLaporan as $row) { ?>
        <tr style="text-align: center;">
            <td><?= $no++;?></td>
            <td><?= $row->tanggal;?></td>
            <td><?= $row->nama_supplier;?></td>
            <td><?= $row->no_kendaraan;?></td>
            <td><?= number_format($row->netto,2,',','.') ?></td>
            <td><?= number_format($row->pot,2,',','.') ?></td>
            <td><?= number_format($row->bruto,2,',','.') ?></td>
            <td><?= $row->nama_barang;?></td>
            <td><?= $row->nbm;?></td>
            <td><?= number_format($row->harga_b,2,',','.') ?></td>
            <td><?= number_format($row->denda,2,',','.') ?></td>
            <td><?= number_format($row->netto,2,',','.') ?></td>
            <td><?= number_format($row->nilai,2,',','.') ?></td>
            <td><?= number_format($row->bb_cash,2,',','.') ?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>
    </body>
</html>