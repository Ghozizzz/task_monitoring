<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Data Invoice</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Pembayaran</a></li>
          <li class="breadcrumb-item active">Invoice</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-check"></i> Sukses</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Gagal</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Data Invoice</h3>
              <div class="card-tools">
                <a class="btn btn-block btn-primary" id="tambah" href="<?=base_url();?>Finance/addInvoice"><i class="fa fa-plus"></i> Tambah</a>
              </div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example2" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <td>No</td>
                  <td>No. Invoice</td>
                  <td>Customer</td>
                  <td>Tanggal</td>
                  <td>Nilai</td>
                  <td>Status</td>
                  <td>Matching</td>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; foreach($inv as $row) {?>
                  <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $row->no_invoice ?></td>
                    <td><?= $row->nama_customer; ?></td>
                    <td><?= date('d-m-Y', strtotime($row->tanggal)); ?></td>
                    <td align="right"><?= number_format($row->nilai_invoice,2,',','.'); ?></td>
                    <?php if($row->status==0){
                      echo '<td class="bg-secondary"><span>Draft</span></td>'; 
                    }elseif($row->status==1){
                      echo '<td class="bg-success"><span>Approved</span></td>';
                    }elseif($row->status==2){
                      echo '<td class="bg-info"><b>Settle</b></td>';
                    }elseif($row->status==9){
                      echo '<td class="bg-danger color-palette"><span>Rejected</span></td>';
                    } ?>
                    <?=($row->flag > 0) ? '<td class="bg-success"><span>Sudah Lunas</span></td>' : '<td class="bg-danger color-palette"><span>Belum Lunas</span></td>';?>
                    <td>
                    <?php if($row->status != 1 && $row->flag == 0){ ?>
                      <a class="btn btn-danger btn-sm" href="<?= site_url().'Finance/delete_invoice/'.$row->id;?>" onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-trash"></i> Delete</a> |
                    <?php }
                      if($row->status==0){ ?>
                        <a class="btn btn-info btn-sm" href="<?=base_url().'Finance/edit_invoice/'.$row->id;?>" ><i class="fa fa-edit"></i> Edit</a>
                    <?php
                      }
                        if($row->status == 2){ ?>
                      <a class="btn btn-info btn-sm" href="<?=base_url().'Finance/qc_invoice/'.$row->id;?>" ><i class="fa fa-edit"></i> Edit</a>
                    <?php } ?>
                      <a class="btn btn-success btn-sm" href="<?=base_url(); ?>Finance/view_invoice/<?= $row->id; ?>"><i class="fa fa-file"></i> View</a>
                      <a class="btn btn-primary btn-sm" href="<?=base_url(); ?>Finance/print_invoice/<?= $row->id; ?>" target="_blank"><i class="fa fa-print"></i> Print</a>
                    </td>
                  </tr>
                <?php }?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>