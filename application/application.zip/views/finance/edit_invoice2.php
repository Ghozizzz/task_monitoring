<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Tambah Data Invoice</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan/invoice">Invoice</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-check"></i> Sukses</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Gagal</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=base_url('Finance/proceed_invoice');?>"> 
      <input type="hidden" id="id" name="id" value="<?=$h['id'];?>">
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Form</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->   
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <div class="row">
                  <div class="col-md-4">
                    <label>No. Invoice</label>
                  </div>
                  <div class="col-md-8">
                    <div class="input-group mb-3">
                      <input type="text" class="form-control" name="no_invoice" id="no_invoice" placeholder="No Invoice ..." value="<?=$h['no_invoice'];?>">
                    </div>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Tanggal</label>
                  </div>
                    <!-- <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                      </div>
                      <input type="text" name="tanggal" id="tanggal_dm" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                    </div> -->
                  <div class="col-md-8">
                    <div class="input-group date" id="date_id" data-target-input="nearest">
                        <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" />
                        <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                    </div>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Term Of Payment</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="term_of_payment" id="term_of_payment" value="<?=$h['term_of_payment'];?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Keterangan</label>
                  </div>
                  <div class="col-md-8">
                    <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"><?=$h['keterangan'];?></textarea>
                  </div>
                </div>
              </div>
              <div class="col-md-1"></div>
              <div class="col-md-5">
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Customer</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="nama_customer" id="nama_customer" value="<?=$h['nama_customer'];?>" readonly>
                    <input type="hidden" id="jenis_customer" name="jenis_customer" value="<?=$h['jenis_customer'];?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>PPN</label>
                  </div>
                  <div class="col-md-8">
                    <select class="form-control" name="ppn" id="ppn">
                        <option value="0" <?=($h['ppn']==0)? 'selected':'';?>>No</option>
                        <option value="1" <?=($h['ppn']==1)? 'selected':'';?>>Yes</option>
                    </select>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Bunga</label>
                  </div>
                  <div class="col-md-8">
                    <input type="number" class="form-control" name="bunga" id="bunga" placeholder="Bunga ..." value="<?=$h['bunga'];?>">
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
      </div>
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Details Faktur</h3>
            <div class="float-right">
              <a href="javascript:;" class="btn btn-success btn-xs" style="display: none;" id="add_checked"><i class="fa fa-plus"></i> Tambah </a>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
              <div class="col-md-1">
                <label for="Doctor-name">From</label>
              </div>
              <div class="col-md-2">
                <input type="date" id="StartDate" value="0000-00-00" 
                  class="form-control" >
              </div>
              <div class="col-md-1">
                <label for="dob">To</label>
              </div>
              <div class="col-md-2">
                <input type="date" id="EndDate" value="0000-00-00" 
                  class="form-control" >
              </div>
              <div class="col-md-1">
                <label for="dob">Barang</label>
              </div>
              <div class="col-md-3">
                <select class="form-control select2bs4" id="barang">
                    <option value="0">Silahkan Pilih ...</option>
                  <?php foreach ($barang as $k) {
                    echo '<option value="'.$k->id.'">'.$k->nama_barang.'</option>';
                  } ?>
                </select>
              </div>
              <div class="col-md-2">
                <a href="javascript:;" class="btn btn-info btn" id="filter"><i class="fa fa-search"></i> Filter </a>
                <a href="javascript:;" class="btn btn-info btn" id="reset">Reset</a>
              </div>
            </div>
            <hr>
            <table id="load_sj" class="table table-bordered">
              <thead>
                <tr>
                  <th></th>
                  <th>Barang</th>
                  <th>Tanggal</th>
                  <th>Kendaraan</th>
                  <th>Netto</th>
                  <th>Harga Beli</th>
                  <th>Action</th>
                  <th>#</th>
                </tr>
              </thead>
            </table>
          </div>
        </div>
      </div>
      <div class="col-md-12">
        <hr>
      </div>
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Details Invoice</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="load_inv" class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Barang</th>
                  <th>Bruto</th>
                  <th>Netto</th>
                  <th>Harga Jual</th>
                  <th>Total Amount</th>
                  <th>Action</th>
                </tr>
              </thead>
            </table>
          </div>
        </div>
      </div>
      <div class="col-md-12">
          <a href="<?= site_url('Finance/Invoice')?>" class="btn btn-info float-left mr-2"> 
            <i class="fa fa-angle-left"></i> Kembali 
          </a>
          <button type="button" class="btn btn-primary mb-4 float-right" onclick="simpanData();">
            <i class="fa fa-save"></i> Proceed
          </button>
        <!-- /.card -->
      </div>
    </div>
    </form>
  </div>
</section>

<div class="modal fade" id="SJModal" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">&nbsp;</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger display-hide" id="alert-danger" style="display: none;">
                            <button class="close" data-close="alert"></button>
                            <span id="message">&nbsp;</span>
                        </div>
                    </div>
                </div>
                <form class="eventInsForm" method="post" target="_self" name="frmInv" 
                    id="frmInv">
                    <input type="hidden" id="jenis_add" name="jenis_add">
                    <input type="hidden" id="id_modal_sj" name="id_modal_sj">
                    <div class="row">
                        <div class="col-md-4">
                            No. Faktur<font color="#f00">*</font>
                        </div>
                        <div class="col-md-8">
                            <input type="text" id="no_surat_jalan" name="no_surat_jalan" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                            <input type="hidden" id="sj_id" name="sj_id">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            Nama Barang<font color="#f00">*</font>
                        </div>
                        <div class="col-md-9">
                            <input type="text" id="nama_barang" name="nama_barang" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            Kendaraan<font color="#f00">*</font>
                        </div>
                        <div class="col-md-9">
                            <input type="text" id="kendaraan" name="kendaraan" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            Bruto
                        </div>
                        <div class="col-md-9">
                            <input type="text" id="bruto" name="bruto" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            Netto
                        </div>
                        <div class="col-md-9">
                            <input type="text" id="netto" name="netto" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            Harga Beli
                        </div>
                        <div class="col-md-9">
                            <input type="text" id="harga_beli" name="harga_beli" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            Harga Jual
                        </div>
                        <div class="col-md-9">
                            <input type="text" id="harga_jual" name="harga_jual" class="form-control myline" style="margin-bottom:5px" placeholder="Harga Jual ...">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">                        
                <button type="button" class="btn btn-primary" id="tambah_sj"><i class="fa fa-plus"></i> Tambah</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Tutup</button>
            </div>
        </div>
    </div>
</div>
<script>
/** sj */
$(document).ready(function() {
    $('#load_sj').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax":{
          "url":"<?=site_url('Finance/get_list_sj');?>",
          "type":"post",
          "data":function (data) {
                data.id = <?=$h['id_customer'];?>;
                var startDate = $('#StartDate').val();
                var endDate = $('#EndDate').val();
                data.barang = $('#barang').val();
                data.startDate = startDate;
                data.endDate = endDate;
          }
        },
        "columnDefs":[
          {
            "targets":'_all',
            "className":'p-1'
          },
          {
            "targets":[3,4],
            "className":'text-right'
          },
          { 
            "targets": [6,7],
            "orderable": false
          }
        ]
    } );

    $('#load_inv').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax":{
          "url":"<?=site_url('Finance/get_list_sj_inv2');?>",
          "type":"post",
          "data":{
            "id":<?=$h['id'];?>
          }
        },
        "columnDefs":[
          {
            "targets":[2,3,4,5],
            "className":'p-1 text-right'
          },
          {
            "targets":'_all',
            "className":'p-1'
          },
        ]
    } );

    var $submit = $("#add_checked").hide();
    $("#load_sj").on('change',"input[type='checkbox'][name='id_sj[]']",function(e){
        $submit.toggle( $("input[type='checkbox'][name='id_sj[]']:checked").length > 0 );
    });
} );

$("#reset").click(function () {
  $('input[type=date]').val('');
  $('#barang').val(0).trigger('change');
  $('#load_sj').DataTable().ajax.reload();
});

$("#filter").click(function () {
  $('#load_sj').DataTable().ajax.reload(); 
});

$('#add_checked').click(function(event) {
  event.preventDefault();

  var selectedID = [];
  $("input[type='checkbox'][name='id_sj[]']:checked").each (function () {
      selectedID.push(this.value);
  });

  $.ajax({
      url: "<?= site_url('Finance/get_data_sj_group'); ?>",
      type: "POST",
      data: {
          id:selectedID,
      },
      dataType: "json",
      success: function(res){
        if(res.status==1){
          result = res.data;
          $("#SJModal").find('.modal-title').text('Input Harga Jual');
          $("#SJModal").modal('show',{backdrop: 'true'});
          $(".alert").hide();
          $("#jenis_add").val(1);
          $("#id_modal_sj").val(<?php echo $h['id'];?>);
          $("#no_surat_jalan").val(result['no_surat_jalan']);
          $('#sj_id').val(selectedID);
          $("#nama_barang").val(result['nama_barang']);
          $("#bruto").val(result['bruto']);
          $("#netto").val(result['netto']);
          $("#harga_beli").val(result['avg']);
          $("#kendaraan").val(result['no_kendaraan']);
          $("#harga_jual").val('');
        }else{
          alert(res.message);
        }
      }
  });
});

function add_sj(id){
    $.ajax({
        url: "<?= site_url('Finance/get_data_sj'); ?>",
        type: "POST",
        data: {
            id:id,
        },
        dataType: "json",
        success: function(result){
            $("#SJModal").find('.modal-title').text('Input Harga Jual');
            $("#SJModal").modal('show',{backdrop: 'true'});
            $(".alert").hide();
            $("#jenis_add").val(1);
            $("#id_modal_sj").val(<?php echo $h['id'];?>);
            $("#no_surat_jalan").val(result['no_surat_jalan']);
            $("#sj_id").val(result['id']);
            $("#nama_barang").val(result['nama_barang']);
            $("#bruto").val(result['bruto']);
            $("#netto").val(result['netto']);
            $("#harga_beli").val(result['harga']);
            $("#kendaraan").val(result['no_kendaraan']+' | '+result['jenis_kendaraan']);
            $("#harga_jual").val('');
        }
    });
}

$('#tambah_sj').click(function(event) {
    event.preventDefault(); /*  Stops default form submit on click */

    if($.trim($("#harga_jual").val()) == ("" || 0)){
        $('#message').html("Harga Jual harus diisi, tidak boleh kosong!");
        $('.alert-danger').show();
    }else{
        $(this).prop('disabled', true);
        $.ajax({
            url: "<?= base_url('Finance/add_sj_inv'); ?>",
            data:{
               id_jenis:$('#jenis_add').val(),
               id_modal:$('#id_modal_sj').val(),
               id_sj:$('#sj_id').val(),
               harga_jual:$('#harga_jual').val(),
            },
            type: "POST",
            success: function(result){
                if (result['message_type'] == 1) {
                    $("#SJModal").modal('hide'); 
                    $('#load_sj').DataTable().ajax.reload();
                    $('#load_inv').DataTable().ajax.reload();
                    $('#tambah_sj').prop('disabled', false);
                } else {
                    $("#SJModal").modal('hide'); 
                }
            }
        });
    }
});

// function list_inv(){
//     $.ajax({
//         url: "<?= site_url('Finance/load_list_inv'); ?>",
//         type: "POST",
//         data: {
//             id:<?=$h['id'];?>,
//         },
//         dataType: "json",
//         success: function(result) {
//             $('#load_inv').html(result);
//         }
//     });
// }

function delete_sj(uid,id){
  var r = confirm("Anda yakin menghapus sj dari list ini ?");
  if (r == true) {
    $.ajax({
        url: "<?= site_url('Finance/delete_sj_inv2'); ?>",
        type: "POST",
        data: {
            uid:uid,
            id:id
        },
        dataType: "json",
        success: function(result){
            // console.log(result);
            $('#load_sj').DataTable().ajax.reload();
            $('#load_inv').DataTable().ajax.reload();
        }
    });
  }
}

function simpanData(){
  if($.trim($("#no_invoice").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' No Invoice harus diisi'
    });
  } else if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  }else{
    var r = confirm("Anda yakin menyimpan list ini ?");
    if (r == true) {
      $(this).prop('disabled', true).text('Please Wait ...');
      $('#formku').submit();
    }
  }
};

// list_sj();
// list_inv();
</script>