<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
    <body class="margin-left:40px;">
        <table border="0" cellpadding="2" cellspacing="0" width="900px" style="font-family:Microsoft Sans Serif: font-size: 12px;">
            <tr>
                <td colspan="3" style="border-bottom: 1px solid #000;">
                    <h3 style="text-align: center; margin-bottom: 0px;">
                        PT. YAPUTRA ABADI PERKASA<br>
                        PERKANTORAN RUKO TOMANG TOL RAYA BLOK A1 No 50 RT 009 RW 004<br>
                        JAKARTA BARAT
                    </h3>
                </td>
            </tr>
            <tr>
                <td colspan="3">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%">
                        <tr>
                            <td width="50%">Kepada Yth :</td>
                            <td width="25%">No. Inv .PPN</td>
                            <td width="25%">: <?=str_replace('SK', 'PPN', $h['no_invoice']);?></td>
                        </tr>
                        <tr>
                            <td colspan="3"><?=$h['nama_customer'];?></td>
                        </tr>
                        <tr>
                            <td width="50%"><?=$h['alamat'];?></td>
                            <td width="25%">TANGGAL</td>
                            <td width="25%">: <?=tanggal_indo($h['tanggal']);?></td>
                        </tr>
                        <tr>
                            <td colspan="3">&nbsp;</td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="3">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" cellpadding="4" cellspacing="0" width="100%" style="font-family:Arial; font-size: 14px">
                        <tr>
                            <td width="5%" style="text-align:center;"><strong>No.</strong></td>
                            <td width="30%"><strong>Nama Barang</strong></td>
                            <th colspan="2" width="15%" style="text-align:center;"><strong>Qty</strong></th>
                            <th colspan="2" width="15%" style="text-align:center;"><strong>Harga @</strong></th>
                            <td colspan="2" width="25%" style="text-align:center;"><strong>Jumlah</strong></td>
                        </tr>
                        <tr>
                            <td style="text-align:right; ">1</td>
                            <td colspan="3">PPN FAKTUR ( <?=$h['no_invoice'];?> ) ( <?=$h['no_ppn'];?> ) :</td>
                            <td></td>
                            <td style="text-align:right;"></td>
                            <td>Rp</td>
                            <td style="text-align:right;">
                                <?=number_format($details['nilai_ppn'],2,',','.');?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="8" style="height: 50px"></td>
                        </tr>
                        <tr>
                            <td colspan="3" style="text-align:left;"></td>
                            <td colspan="3" style="text-align:left"><strong>Jumlah</strong></td>
                            <td style="border-top: 1px solid #000;">Rp</td>
                            <td style="text-align:right; border-top: 1px solid #000;">
                                <?=number_format($details['nilai_ppn'],2,',','.');?>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="8">
                                <table border="0" width="100%">
                                    <tr>
                                        <td width="28%" style="text-align:left;">Terbilang</td>
                                        <td width="2%">:</td>
                                        <td width="60%"><?=ucwords(number_to_words($details['nilai_ppn'])); ?></td>
                                        <td width="10%">&nbsp;</td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="8">
                                <table border="0" width="100%" style="font-size: 16px">
                                    <tr>
                                        <td width="28%" style="text-align:left;">PEMBAYARAN DI TRANSFER</td>
                                        <td width="2%">:</td>
                                        <td width="45%"></td>
                                        <td width="25%"></td>
                                    </tr>
                                    <tr>
                                        <td width="28%" style="text-align:left;">NAMA BANK</td>
                                        <td width="2%">:</td>
                                        <td width="45%"><?=$h['nama_bank'];?></td>
                                        <td width="25%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="28%" style="text-align:left;">NO REKENING</td>
                                        <td width="2%">:</td>
                                        <td width="45%"><?=$h['no_rekening'];?></td>
                                        <td width="25%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td width="28%" style="text-align:left;">ATAS NAMA</td>
                                        <td width="2%">:</td>
                                        <td width="45%"><?=$h['atas_nama'];?></td>
                                        <td width="25%">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="5" style="height: 50px;">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">&nbsp;</td>
                                        <td align="center">
                                            Hormat Kami
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" style="height: 75px;">&nbsp;</td>
                                    </tr>
                                    <tr>
                                        <td colspan="3">&nbsp;</td>
                                        <td align="center" style="font-family: Calibri">
                                            PIT RUDYANTO
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <p>&nbsp;</p>
    <body onLoad="window.print()">
    </body>
</html>