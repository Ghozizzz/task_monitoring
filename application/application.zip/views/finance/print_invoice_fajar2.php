<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
    <body class="margin-left:40px;">
        <table border="0" cellpadding="2" cellspacing="0" width="900px" style="font-family: Arial;">
            <tr align="center">
                <td colspan="2">
                    <h3 style="text-align: center; margin-bottom: 0px;">
                        REKAPAN PENGIRIMAN HARIAN<br>
                    </h3>
                </td>
            </tr>
                <td width="60%">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%" style=" font-size: 14px;">
                        <tr>
                            <td>Detail penerimaan PT. Yaputra Abadi Perkasa</td>
                        </tr>
                    </table>
                </td>
                <td width="40%">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%" style=" font-size: 14px;">
                        <tr>
                            <td width="40%">No. Invoice :</td>
                            <td>: <?=$h['no_invoice'];?></td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" cellpadding="4" cellspacing="0" width="100%" style="font-family:Arial; font-size: 14px">
                        <tr>
                            <td width="2%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>No.</strong></td>
                            <td width="10%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>No. TBT</strong></td>
                            <td width="10%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Tanggal</strong></td>
                            <td width="15%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Nopol</strong></td>
                            <td width="20%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Jenis Barang</strong></td>
                            <th width="10%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Netto (Kg)</strong></th>
                            <th width="16%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Harga /Kg</strong></th>
                            <td width="17%" colspan="2" style="text-align:center; border:1px solid #000"><strong>Total Harga</strong></td>
                        </tr>
                <?php
                    $no=0;
                    $netto=0;
                    $total_amount=0;
                    $netto_jb=0;
                    $total_jb=0;
                    $last_series = null;
                    foreach ($details as $row){ $no++;
                      if($last_series!=$row->id_jb && $last_series!=null){
                        echo '
                            <tr>
                                <td style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000" colspan="5"><strong>SUB TOTAL '.$row->nama_barang.'</strong></td>
                                <th style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><strong>'.number_format($netto_jb,2,',','.').'</strong></th>
                                <th style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000;"></th>
                                <td style="border-left:1px solid #000; border-bottom: 1px solid #000;"><strong>Rp</strong></td>
                                <td style="text-align:right; border-right:1px solid #000; border-bottom:1px solid #000"><strong>
                                    '.number_format($total_jb,2,',','.').'</strong>
                                </td>
                            </tr>
                            <tr style="height:25px">
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                                <td>&nbsp;</td>
                            </tr>
                        </table>';
                        $netto_jb=0;
                        $total_jb=0;
                        $no=1;
                        echo '
                        <table border="0" cellpadding="4" cellspacing="0" width="100%" style="font-family:Arial; font-size: 14px">
                            <tr>
                                <td width="2%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>No.</strong></td>
                                <td width="10%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>No. TBT</strong></td>
                                <td width="10%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Tanggal</strong></td>
                                <td width="15%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Nopol</strong></td>
                                <td width="20%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Jenis Barang</strong></td>
                                <th width="10%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Netto (Kg)</strong></th>
                                <th width="16%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Harga /Kg</strong></th>
                                <td width="17%" colspan="2" style="text-align:center; border:1px solid #000"><strong>Total Harga</strong></td>
                            </tr>';
                    }
                ?>
                        <tr>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=$no;?></td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=$row->no_tbt;?></td>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000;"><?=$h['tanggal'];?></td>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000;"><?=$row->no_kendaraan;?></td>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000;"><?=$row->nama_barang;?></td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=number_format($row->netto,2,',','.');?> Kg</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;">@ Rp. <?=number_format($row->harga,2,',','.');?> /Kg</td>
                            <td style="border-left:1px solid #000; border-bottom: 1px solid #000;">Rp</td>
                            <td style="text-align:right; border-bottom:1px solid #000; border-right:1px solid #000;">
                                <?=number_format($row->sub_total+$row->adjustment,2,',','.');?>
                            </td>
                        </tr>
                    <?php
                            $netto += $row->netto;
                            $total_amount += $row->sub_total+$row->adjustment;
                            $netto_jb += $row->netto;
                            $total_jb += $row->sub_total+$row->adjustment;
                            $last_series = $row->id_jb;
                        }
                    ?>
                        <tr style="height:25px">
                            <td style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-right:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                        </tr>
                        <tr>
                            <td style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000" colspan="5"><strong>SUB TOTAL <?=$row->nama_barang;?></strong></td>
                            <th style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><strong><?=number_format($netto_jb,2,',','.');?></strong></th>
                            <th style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000;"></th>
                            <td style="border-left:1px solid #000; border-bottom: 1px solid #000;"><strong>Rp</strong></td>
                            <td style="text-align:right; border-right:1px solid #000; border-bottom:1px solid #000"><strong>
                                <?=number_format($total_jb,2,',','.');?></strong>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <p>&nbsp;</p>
    <body onLoad="window.print()">
    </body>
</html>