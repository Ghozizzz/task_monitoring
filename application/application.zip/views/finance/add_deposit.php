<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Uang Keluar</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>Finance/UangKeluar">Uang Keluar</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Form</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=site_url('Finance/save_deposit');?>">    
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>No. Deposit</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group mb-3">
                        <input type="text" class="form-control" value="Auto Generate" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                          <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." />
                          <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Nama Supplier</label>
                    </div>
                    <div class="col-md-8">
                      <select class="supplier form-control select2bs4" name="supplier" id="supplier" style="width: 100%;">
                          <option value="0">Silahkan Pilih ...</option>
                          <?php foreach ($supplier as $key => $v) {
                              echo '<option value="'.$v->id.'">'.$v->nama_supplier.'</option>';
                          }?>
                      </select>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-3">
                    <div class="col-md-4">
                       <label for="nominal">Nominal</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="nominal" name="nominal" class="form-control myline" style="margin-bottom:5px" onkeyup="getComa(this.value, this.id)">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                <button type="button" class="btn btn-primary float-right" onclick="simpanData();"><i class="fa fa-paper-plane"></i> Submit</button>
                <a href="<?= site_url('Finance/UangKeluar')?>" class="btn btn-info float-right" style="margin-right:5px;"> 
                    <i class="fa fa-angle-left"></i> Kembali 
                </a>
            </div>
          </form>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<script>
function simpanData(){
  if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  } else if($.trim($("#nominal").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Nominal harus diisi'
    });
  } else if($.trim($("#supplier").val()) == 0){
    Toast.fire({
      icon: 'error',
      title: ' Supplier harus diisi'
    });
  }else{
    $(this).prop('disabled', true).text('Please Wait ...');
    $('#formku').submit();
  }
};

function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}
</script>