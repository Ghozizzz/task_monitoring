<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
    <body class="margin-left:40px;">
        <h3 style="text-align: center; text-decoration: underline;">
            PT. YAPUTRA ABADI PERKASA<br>
            PERKANTORAN RUKO TOMANG TOL RAYA BLOK A1 No 50 RT 009 RW 004<br>
            JAKARTA BARAT
        </h3>
        <table border="0" cellpadding="2" cellspacing="0" width="900px" style="font-family:Microsoft Sans Serif: font-size: 12px;">
            <tr>
                <td width="60%">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%">
                        <tr>
                            <td>Kepada Yth :</td>
                        </tr>
                        <tr>
                            <td><?=$h['nama_customer'];?></td>
                        </tr>
                        <tr rowspan="3">
                            <td><?=$h['alamat'];?></td>
                        </tr>
                    </table>
                </td>
                <td width="40%">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%">
                        <tr>
                            <td width="40%">INVOICE NO :</td>
                            <td>: <?=$h['no_invoice'];?></td>
                        </tr>
                        <tr>
                            <td colspan="2">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="40%">TANGGAL</td>
                            <td>: <?=tanggal_indo($h['tanggal']);?></td>
                        </tr>
                        <tr rowspan="2">
                            <td colspan="2">&nbsp;</td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" cellpadding="4" cellspacing="0" width="100%" style="font-family:Arial; font-size: 14px">
                        <tr>
                            <td width="10%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>TANGGAL</strong></td>
                            <td width="10%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>NO MOBIL</strong></td>
                            <td width="30%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>BARANG</strong></td>
                            <th width="10%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>NETTO / KG</strong></th>
                            <th width="10%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>POT (QC)</strong></th>
                            <th width="10%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>BRUTO / KG</strong></th>
                            <th width="10%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>HARGA / KG</strong></th>
                            <td width="10%" style="text-align:center; border:1px solid #000"><strong>TOTAL AMOUNT</strong></td>
                        </tr>
                        <?php
                            $no = 1;
                            $netto = 0;
                            $bruto = 0;
                            $total_amount = 0;
                            foreach ($details as $row){
                        ?>
                        <tr>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=$h['tanggal'];?></td>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000;"><?=$row->no_kendaraan;?></td>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000;"><?=$row->nama_barang;?></td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=number_format($row->netto,2,',','.');?></td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=number_format($row->bruto-$row->netto,2,',','.');?></td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=number_format($row->bruto,2,',','.');?></td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=number_format($row->harga,2,',','.');?></td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000; border-right:1px solid #000;">
                                <?=number_format($row->sub_total+$row->adjustment,2,',','.');?>
                            </td>
                        </tr>
                        <?php
                                $netto += $row->netto;
                                $bruto += $row->bruto;
                                $total_amount += $row->sub_total+$row->adjustment;
                                $no++;
                            }
                        ?>
                        <tr style="height:50px">
                            <td style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-right:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                        </tr>
                        <tr style="height: 25px">
                            <td colspan="7"></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;" colspan="3"><strong>JUMLAH POKOK</strong></td>
                            <td style="text-align:right;">
                                <?=number_format($netto,2,',','.');?>
                            </td>
                            <td style="text-align:right;">
                                &nbsp;
                            </td>
                            <td style="text-align:right;">
                                <?=number_format($bruto,2,',','.');?>
                            </td>
                            <td style="text-align:right;">
                                &nbsp;
                            </td>
                            <td style="text-align:right;">
                                <?=number_format($total_amount,2,',','.');?>
                            </td>
                        </tr>
                        <?php 
                        if ($h['ppn']==1) {
                            $ppn = $total_amount * 10 / 100;
                        }else{
                            $ppn = 0;
                        } 
                        $grand_total = $total_amount + $ppn;
                        ?>
                        <tr>
                            <td style="text-align:left; border-bottom: 1px solid #000;" colspan="7"><strong>Ppn 10%</strong></td>
                            <td style="text-align:right; border-bottom:1px solid #000;">
                                <?=number_format($ppn,2,',','.');?>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;" colspan="7"><strong>GRAND TOTAL</strong></td>
                            <td style="text-align:right;">
                                <?=number_format($grand_total,2,',','.');?>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="3" style="height: 50px;">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" width="100%">
                        <tr>
                            <td width="30%">PEMBAYARAN DI TRANSFER</td>
                            <td style="text-align:right;">:</td>
                            <td colspan="2">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="30%">NAMA BANK</td>
                            <td width="15%" style="text-align:right;">:</td>
                            <td width="40%"><?=$h['nama_bank'];?></td>
                            <td width="10%" style="text-align:right;">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="30%">NO REKENING</td>
                            <td width="15%" style="text-align:right;">:</td>
                            <td width="40%"><?=$h['no_rekening'];?></td>
                            <td width="10%" style="text-align:right;">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="30%">ATAS NAMA</td>
                            <td width="15%" style="text-align:right;">:</td>
                            <td width="40%"><?=$h['atas_nama'];?></td>
                            <td width="10%" style="text-align:right;">&nbsp;</td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="3" style="height: 50px;">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="1">&nbsp;</td>
                <td colspan="2">
                    <table border="0" width="100%">
                        <tr>
                            <td align="center">Karawang, <?=tanggal_indo($h['tanggal']);?></td>
                        </tr>
                        <tr>
                            <td align="center">&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="center">Hormat Kami</td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="3" style="height: 75px;">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="1">&nbsp;</td>
                <td colspan="2" align="center" style="font-family: Calibri">
                    ROBY YAPUTRA
                </td>
            </tr>
        </table>
        <p>&nbsp;</p>
    <body onLoad="window.print()">
    </body>
</html>