<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Uang Masuk</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Uang Masuk</a></li>
          <li class="breadcrumb-item active">Data</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-check"></i> Sukses</h5>
                <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
            </div>
            <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-ban"></i> Gagal</h5>
                <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
            </div>
        </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Data Uang Masuk</h3>
              <div class="card-tools">
                <a class="btn btn-block btn-primary" id="tambah" href="<?=base_url();?>Finance/add_uang_masuk"><i class="fa fa-plus"></i> Tambah</a>
              </div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example2" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <td>No</td>
                  <td>Supplier</td>
                  <td>No Uang Masuk</td>
                  <td>Tanggal</td>
                  <td>Jenis Pembayaran</td>
                  <td>Nominal</td>
                  <td>Status</td>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody>
                <?php 
                $no=1;
                foreach ($list_data as $key => $v) { ?>

                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= $v->nama_customer ?></td>
                    <td><?= $v->no_uang_masuk ?></td>
                    <td><?= $v->tanggal ?></td>
                    <td><?= $v->jenis_pembayaran ?></td>
                    <td><?= number_format($v->nominal,2,',','.') ?></td>
                    <?php if ($v->flag_matching == 0) {
                      echo '<td class="bg-secondary"><span>Belum Matching</span></td>';
                      }else {
                          echo '<td class="bg-success color-palette"><span>Sudah Matching</span></td>';
                      }
                    ?>
                    <td>
                      <a class="btn btn-info btn-sm" href="<?= site_url('Finance/view_uang_masuk/'.$v->id)?>"><i class="fa fa-file-alt"></i> View</a>
                      <a class="btn btn-primary btn-sm" href="<?=base_url().'Finance/print_uang_masuk/'.$v->id;?>" onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-print"></i> Print</a> 
                      <?php if($v->flag_matching == 0) { ?>
                        |
                        <a class="btn btn-danger btn-sm" href="<?=base_url().'Finance/delete_uang_masuk/'.$v->id;?>" onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-trash"></i> Delete</a>
                      <?php } ?>
                    </td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>