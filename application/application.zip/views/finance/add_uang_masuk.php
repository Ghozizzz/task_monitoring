<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Uang Masuk</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>Finance/uang_masuk">Uang Masuk</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Form</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=site_url('Finance/save_uang_masuk');?>">    
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>No. Uang Masuk</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group mb-3">
                        <input type="text" class="form-control" value="Auto Generate" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                          <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." />
                          <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Nama Customer <font color="#f00">*</font></label>
                    </div>
                    <div class="col-md-8">
                      <select class="customer form-control select2bs4" name="customer" id="customer" style="width: 100%;">
                          <option value="0">Silahkan Pilih ...</option>
                          <?php foreach ($customer as $key => $v) {
                              echo '<option value="'.$v->id.'">'.$v->nama_customer.'</option>';
                          }?>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Jenis Pembayaran <font color="#f00">*</font></label>
                    </div>
                    <div class="col-md-8">
                      <select class="form-control select2bs4" name="jenis_id" id="jenis_id" style="width: 100%;"  onchange="get_cek(this.value);">
                        <option value="0">Pilih Jenis Pembayaran ...</option>
                        <option value="Cash">Cash</option>
                        <option value="Transfer">Transfer</option>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3" id="show_bank_tuj">
                    <div class="col-md-4">
                      <label for="">Rekening Pengirim <font color="#f00">*</font></label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" id="rekening_pengirim" name="rekening_pengirim" placeholder="Rekening Pengirim ...">
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Nama Bank <font color="#f00">*</font></label>
                    </div>
                    <div class="col-md-8">
                      <select class="bank form-control select2bs4" name="bank" id="bank" style="width: 100%;">
                          <option value="0">Silahkan Pilih ...</option>
                          <?php foreach ($bank as $b) {
                              echo '<option value="'.$b->id.'">'.$b->nama_bank.'</option>';
                          }?>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                        <label for="currency">Currency</label>
                    </div>
                    <div class="col-md-8">
                        <select id="currency" name="currency" class="form-control select2bs4" style="margin-bottom:5px">
                        <option value="IDR">IDR</option>
                        <option value="USD">USD</option>
                        </select>         
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                       <label for="nominal">Nominal</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" id="nominal" name="nominal" class="form-control myline" style="margin-bottom:5px" onkeyup="getComa(this.value, this.id)">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                <button type="button" class="btn btn-primary float-right" onclick="simpanData();"><i class="fa fa-paper-plane"></i> Submit</button>
                <a href="<?= site_url('Finance/uang_masuk')?>" class="btn btn-info float-right" style="margin-right:5px;"> 
                    <i class="fa fa-angle-left"></i> Kembali 
                </a>
            </div>
          </form>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<script>
function simpanData(){
  if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  } else if($.trim($("#currency").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Currency harus diisi'
    });
  } else if($.trim($("#nominal").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Nominal harus diisi'
    });
  } else if($.trim($("#jenis_id").val()) == 0){
    Toast.fire({
      icon: 'error',
      title: ' Jenis Pembayaran harus diisi'
    });
  } else if($.trim($("#customer").val()) == 0){
    Toast.fire({
      icon: 'error',
      title: ' Supplier harus diisi'
    });
  } else if($.trim($("#bank").val()) == 0){
    Toast.fire({
      icon: 'error',
      title: ' Bank harus diisi'
    });
  }else{
    $(this).prop('disabled', true).text('Please Wait ...');
    $('#formku').submit();
  }
};

function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

function get_cek(id){
    if(id == "Transfer"){
        $('#tanggal_cek').val($('#tanggal').val());

        $('#show_replace').hide();
        $('#show_replace_detail').hide();

        // $("#show_rek_tuj").show();
        $('#show_bank_tuj').show();
        $("#show_bank").show();
        $("#show_rek").show();
    }else if(id === "Cash") {
        $('#show_replace').hide();
        $('#show_replace_detail').hide();
        $('#show_rek').hide();
        $("#show_rek_tuj").hide();
        $("#show_bank").hide();

        $('#show_bank_tuj').hide();
    }
};

$(function(){
  $('#show_rek').hide();
  $("#show_rek_tuj").hide();
  $("#show_bank").hide();
  $("#show_bank_tuj").hide();
});
</script>