<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
    <body class="margin-left:40px;">
        <table border="0" cellpadding="2" cellspacing="0" width="900px" style="font-family: Arial;">
            <tr align="center">
                <td colspan="2">
                    <h1 style="text-align: center; margin-bottom: 0px; font-family: Times New Roman">
                        PT. YAPUTRA ABADI PERKASA<br>
                    </h1>
                </td>
            </tr>
            <tr align="center">
                <td colspan="2">Perkantoran Rukon Tomang Tol Raya Blok A1/50</td>
            </tr>
            <tr align="center">
                <td colspan="2">Taman Kedoya Baru</td>
            </tr>
            <tr align="center">
                <td colspan="2">Kedoya Selatan</td>
            </tr>
            <tr align="center">
                <td colspan="2" style="border-bottom: 1px solid #000;">Jakarta Barat</td>
            </tr>
            <tr align="center" style="height: 25px;">
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td width="60%">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%" style=" font-size: 14px;">
                        <tr>
                            <td>Kepada Yth.</td>
                        </tr>
                        <tr>
                            <td><?=$h['nama_customer'];?></td>
                        </tr>
                        <tr rowspan="3">
                            <td><?=$h['alamat'];?></td>
                        </tr>
                    </table>
                </td>
                <td width="40%">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%" style=" font-size: 14px;">
                        <tr>
                            <td width="40%">No. Invoice :</td>
                            <td>: <?=$h['no_invoice'];?></td>
                        </tr>
                        <tr>
                            <td colspan="2">&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="2">Jakarta, <?=tanggal_indo($h['tanggal']);?></td>
                        </tr>
                        <tr rowspan="2">
                            <td colspan="2">&nbsp;</td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" cellpadding="4" cellspacing="0" width="100%" style="font-family:Arial; font-size: 14px">
                        <tr>
                            <td width="5%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>No.</strong></td>
                            <td width="29%" style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Nama Barang</strong></td>
                            <th width="20%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Quantity</strong></th>
                            <th width="23%" style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;"><strong>Harga</strong></th>
                            <td width="23%" colspan="2" style="text-align:center; border:1px solid #000"><strong>Jumlah</strong></td>
                        </tr>
                        <?php
                            $no = 0;
                            $netto = 0;
                            $bruto = 0;
                            $total_amount = 0;
                            foreach ($details as $row){ $no++;
                        ?>
                        <tr>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=$no;?></td>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000;"><?=$row->nama_barang;?></td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;"><?=number_format($row->netto,2,',','.');?> Kg</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000;">@ Rp. <?=number_format($row->harga,2,',','.');?> /Kg</td>
                            <td style="border-left:1px solid #000; border-bottom: 1px solid #000;">Rp</td>
                            <td style="text-align:right; border-bottom:1px solid #000; border-right:1px solid #000;">
                                <?=number_format($row->sub_total+$row->adjustment,2,',','.');?>
                            </td>
                        </tr>
                        <?php
                                $netto += $row->netto;
                                $total_amount += $row->sub_total+$row->adjustment;
                            }
                        ?>
                        <tr style="height:50px">
                            <td style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-left:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                            <td style="text-align:right; border-right:1px solid #000; border-bottom:1px solid #000">&nbsp;</td>
                        </tr>
                        <tr>
                            <td style="text-align:center; border-left:1px solid #000; border-bottom:1px solid #000" colspan="4"><strong>TOTAL</strong></td>
                            <td style="border-left:1px solid #000; border-bottom: 1px solid #000;"><strong>Rp</strong></td>
                            <td style="text-align:right; border-right:1px solid #000; border-bottom:1px solid #000"><strong>
                                <?=number_format($total_amount,2,',','.');?></strong>
                            </td>
                        </tr>
                        <?php 
                        if ($h['ppn']==1) {
                            $ppn = $total_amount * 10 / 100;
                            $grand_total = $total_amount + $ppn;
                        ?>
                        <tr>
                            <td style="text-align:left; border-bottom: 1px solid #000;" colspan="4"><strong>Ppn 10%</strong></td>
                            <td style="text-align:right; border-bottom:1px solid #000;">
                                <?=number_format($ppn,2,',','.');?>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;" colspan="4"><strong>GRAND TOTAL</strong></td>
                            <td style="text-align:right;">
                                <?=number_format($grand_total,2,',','.');?>
                            </td>
                        </tr>
                        <?php
                        }else{
                            $grand_total = $total_amount;
                            $ppn = 0;
                        } ?>
                    </table>
                </td>
            </tr>
            <tr>
                <td colspan="3" style="height: 25px;">&nbsp;</td>
            </tr>
            <tr>
                <tr colspan="3">
                    <table border="0" width="100%">
                        <tr>
                            <td width="20%" style="text-align:left;">Terbilang</td>
                            <td width="5%">:</td>
                            <td width="50%"><?=ucwords(number_to_words($grand_total)); ?></td>
                            <td width="25%">&nbsp;</td>
                        </tr>
                    </table>
                </tr>
            </tr>
            <tr>
                <td colspan="3">
                    <table border="0" width="100%">
                        <tr style="height: 50px;">
                            <td width="30%">Pembayaran dapat ditransfer ke</td>
                            <td width="5%" style="text-align:right;"></td>
                            <td width="40%"></td>
                            <td width="25%">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="30%">Account a/n</td>
                            <td width="5%" style="text-align:right;">:</td>
                            <td width="40%"><?=$h['atas_nama'];?></td>
                            <td width="25%" style="text-align:right;">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="30%">Nama Bank</td>
                            <td width="5%" style="text-align:right;">:</td>
                            <td width="40%"><?=$h['nama_bank'];?></td>
                            <td width="25%" style="text-align:right;">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="30%">Cabang</td>
                            <td width="5%" style="text-align:right;">:</td>
                            <td width="40%"><?=$h['kcp'];?></td>
                            <td width="25%" style="text-align:right;">&nbsp;</td>
                        </tr>
                        <tr>
                            <td width="30%">No Account</td>
                            <td width="5%" style="text-align:right;">:</td>
                            <td width="40%"><?=$h['no_rekening'];?></td>
                            <td width="25%" style="text-align:right;">&nbsp;</td>
                        </tr>
                        <tr>
                            <td colspan="4" style="height: 50px">&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="center">
                                Hormat Kami
                            </td>
                            <td colspan="3"></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="height: 100px">&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="center">
                                ( Roby Yaputra )
                            </td>
                            <td colspan="3"></td>
                        </tr>
                        <tr>
                            <td align="center">
                                PT. Yaputra Abadi Perkasa
                            </td>
                            <td colspan="3"></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <p>&nbsp;</p>
    <body onLoad="window.print()">
    </body>
</html>