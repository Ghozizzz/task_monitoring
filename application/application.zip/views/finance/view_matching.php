<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Matching Faktur</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url('Finance/MatchingSJ');?>">Matching Faktur</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <form class="eventInsFrom" action="" method="POST" target="_self" name="formku" id="formku" action="<?= site_url('Finance/save_matching')?>">
        <input type="hidden" id="nilai_sisa" name="nilai_sisa">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h5><i class="icon fas fa-check"></i> Sukses</h5>
                    <span id="msg_sukses"><?= $this->session->flashdata('sukses'); ?></span>
                </div>
                <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h5><i class="icon fas fa-ban"></i> Gagal</h5>
                    <span id="msg_sukses"><?= $this->session->flashdata('gagal'); ?></span>
                </div>

                <div class="modal fade" id="SJModal" tabindex="-1" role="basic" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">&nbsp;</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="alert alert-danger display-hide" id="alert-danger">
                                            <button class="close" data-close="alert"></button>
                                            <span id="message">&nbsp;</span>
                                        </div>
                                    </div>
                                </div>
                                <form class="eventInsForm" method="post" target="_self" name="frmInv" 
                                    id="frmInv">
                                    <input type="hidden" id="id_modal_sj" name="id_modal_sj">
                                    <div class="row">
                                        <div class="col-md-5">
                                            No. Faktur<font color="#f00">*</font>
                                        </div>
                                        <div class="col-md-7">
                                            <input type="text" id="no_surat_jalan" name="no_surat_jalan" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                                            <input type="hidden" id="sj_id" name="sj_id">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-5">
                                            Nilai
                                        </div>
                                        <div class="col-md-7">
                                            <input type="text" id="nominal_sj" name="nominal_sj" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-5">
                                            Nominal Sudah Di Bayar
                                        </div>
                                        <div class="col-md-7">
                                            <input type="text" id="nominal_sdh_bayar" name="nominal_sdh_bayar" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-5">
                                            Nominal Di Bayar
                                        </div>
                                        <div class="col-md-7">
                                            <input type="text" id="nominal_bayar" name="nominal_bayar" class="form-control myline" style="margin-bottom:5px" value="0" onkeyup="getComa(this.value, this.id); hitungSubTotalSJ();">
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-5">
                                            Sisa Faktur
                                        </div>
                                        <div class="col-md-7">
                                            <input type="text" id="sisa_sj" name="sisa_sj" class="form-control myline" style="margin-bottom:5px" value="0" readonly="readonly">
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">                        
                                <button type="button" class="btn btn-primary" id="tambah_sj"><i class="fa fa-plus"></i> Tambah</button>
                                <button type="button" class="btn btn-primary" id="simpan_sj"><i class="fa fa-save"></i> Simpan</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Tutup</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>No Matching</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="no_matching" id="no_matching" value="<?=$h['no_matching'];?>" disabled>
                                        <input type="hidden" name="id" id="id" class="id" value="<?=$h['id'];?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Tanggal</label>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="input-group date" id="date_id" data-target-input="nearest">
                                            <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" disabled />
                                            <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Status</label>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($h['status']==0){
                                            echo '<div style="background-color:red; padding:3px;color:white;">Belum Balance</div>';
                                        }else{
                                            echo '<div style="background-color:green; padding:3px; color:white;">Balanced</div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-1"></div>
                            <div class="col-sm-5">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Nama Supplier</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" value="<?=$h['nama_supplier'];?>" disabled>
                                        <input type="hidden" name="id_supplier" value="<?= $h['id_supplier']?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Keterangan</label>
                                    </div>
                                    <div class="col-md-8">
                                        <textarea class="form-control" name="keterangan" id="keterangan" disabled><?= $h['keterangan']?>
                                        </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary">
                        <h3 class="card-title">List Faktur</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">No</th>
                                    <th>No Faktur</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="list_sj">
                            
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
            <div class="card">
                    <div class="card-header bg-info">
                        <h3 class="card-title">List Uang Keluar</h3>
                        <div class="card-tools">
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 10%;">No</th>
                                    <th>No Uang Keluar</th>
                                    <th>Nominal</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="list_uk">
                            
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary">
                        <h3 class="card-title">Data Faktur</h3>
                        <div class="card-tools">
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">No</th>
                                    <th>No Faktur</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="data_sj">
                            
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
            <div class="card">
                    <div class="card-header bg-info">
                        <h3 class="card-title">Data Uang Keluar</h3>
                        <div class="card-tools">
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 10%;">No</th>
                                    <th>No Uang Keluar</th>
                                    <th>Nominal</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="data_uk">
                            
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-2">
            <a href="<?php echo base_url('Finance/MatchingSJ'); ?>" class="btn btn-info"><i class="fa fa-angle-left"></i> Kembali </a>
            <?php if($h['status']==0){ ?>
            <a href="javascript:;" class="btn btn-primary" onclick="simpanData();"><i class="fa fa-save"></i> Simpan </a>
            <a href="javascript:;" class="btn btn-success float-right" id="approveData"><i class="fa fa-check"></i> Approve </a>
            <?php }?>
        </div>
        </form>
    </div>
</section>
<script>
const formatter = new Intl.NumberFormat('en-US', {
   minimumFractionDigits: 2,      
   maximumFractionDigits: 2,
});

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","); 
}

function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

function ReplaceNumberWithCommas(yourNumber) {
    //Seperates the components of the number
    var n= yourNumber.toString().split(".");
    //Comma-fies the first part
    n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    //Combines the two sections
    return n.join(".");
}


function simpanData(){
    var result = confirm("Anda yakin untuk menyimpannya ?");
    if (result) {
        $('#formku').submit(); 
    }
}

function hitungSubTotalSJ(){
    nominal_sj = $('#nominal_sj').val().toString().replace(/\,/g, "");
    n1 = $('#nominal_sdh_bayar').val().toString().replace(/\,/g, "");
    n2 = $('#nominal_bayar').val().toString().replace(/\,/g, "");
    total_harga = formatter.format(Number(nominal_sj) - (Number(n1) + Number(n2)));
    console.log(nominal_sj, n1, n2, total_harga);
    // console.log(nominal_sj+' | '+n3+' | '+total_harga);
    $('#sisa_sj').val(total_harga.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

/** sj */
function list_sj(id_supp,id_match){
    $.ajax({
        url: "<?= site_url('Finance/load_list_sj'); ?>",
        type: "POST",
        data: {
            id:id_supp,
            id_match:<?=$this->uri->segment(3);?>
        },
        dataType: "json",
        success: function(result) {
            $('#list_sj').html(result);
        }
    });
}

function input_sj(id){
    $.ajax({
        url: "<?= site_url('Finance/get_data_sj'); ?>",
        type: "POST",
        data: {
            id:id
        },
        dataType: "json",
        success: function(result){
            console.log(result);
            $("#SJModal").find('.modal-title').text('Input Faktur');
            $("#SJModal").modal('show',{backdrop: 'true'});
            $("#tambah_sj").show();
            $("#simpan_sj").hide();
            $("#alert-danger").hide();
            $("#id_modal_sj").val(<?php echo $h['id'];?>);
            
            $("#no_surat_jalan").val(result['no_surat_jalan']);
            $("#sj_id").val(result['id']);
            $("#nominal_sj").val(numberWithCommas(result['nilai']));
            $("#nominal_sdh_bayar").val(numberWithCommas(result['nilai_bayar']));
            $("#nominal_bayar").val(numberWithCommas(result['nilai_sisa']));
            $("#sisa_sj").val(0);
        }
    });
}

function view_sj(id){
    $.ajax({
        url: "<?php echo base_url('Finance/view_data_sj'); ?>",
        type: "POST",
        data: "id="+id,
        dataType: "json",
        success: function(result){
            $("#SJModal").find('.modal-title').text('sj');
            $("#SJModal").modal('show',{backdrop: 'true'});
            $("#tambah_sj").hide();
            $("#simpan_sj").hide();
            $("#alert-danger").hide();
            
            $("#id_modal_sj").val(result['id']);
            $("#no_surat_jalan").val(result['no_surat_jalan']);
            $("#sj_id").val(result['id_sj']);
            $("#nominal_sj").val(numberWithCommas(result['nilai']));
            $("#nominal_sdh_bayar").val(numberWithCommas(result['nilai_bayar']));
            $("#nominal_bayar").val(numberWithCommas(result['sj_bayar']));
        }
    });
}

function delSJ(id,id_sj){
    if(confirm('Anda yakin menghapus sj ini?')){
        $.ajax({
            type:"POST",
            url:'<?php echo base_url('Finance/del_sj_match'); ?>',
            data:{
               id:id,
               id_sj:id_sj
            },
            success:function(result){
                if(result['message_type']=="sukses"){
                    list_sj(<?= $h['id_supplier'].','.$h['id'];?>);
                    data_sj(<?= $h['id'];?>);
                }else{
                    $('#message').html(result['message']);
                    $('.alert-danger').show(); 
                }            
            }
        });
    }
}

/** Uang Keluar */
function list_uk(id){
    $.ajax({
        url: "<?php echo base_url('Finance/load_list_uk'); ?>",
        type: "POST",
        data: "id="+id,
        dataType: "json",
        success: function(result) {
            $('#list_uk').html(result);
        }
    });
}

function instantADDUK(id,jenis){
    $.ajax({
        type:"POST",
        url:'<?= site_url('Finance/add_instant_uk_match'); ?>',
        data:{
           id_uk:id,
           id_modal:$('#id').val(),
           jenis:jenis
        },
        success:function(result){
            if(result['message_type']=="sukses"){
                $('.addUK').prop('disabled', false);
                list_uk(<?php echo $h['id_supplier'];?>);
                data_uk(<?php echo $h['id'];?>);
            }else{
                $('#message').html(result['message']);
                $('.alert-danger').show(); 
            }            
        }
    });
}

function delUK(id,id_uk,jenis){
    $('#delInv').prop('disabled', true);
    $.ajax({
        type:"POST",
        url:'<?php echo base_url('Finance/del_uk_match'); ?>',
        data:{
           id:id,
           id_uk:id_uk,
           jenis:jenis
        },
        success:function(result){
            if(result['message_type']=="sukses"){
                $('#delInv').prop('disabled', false);
                list_uk(<?= $h['id_supplier'];?>);
                data_uk(<?= $h['id'];?>);
            }else{
                $('#message').html(result['message']);
                $('.alert-danger').show(); 
            }            
        }
    });
}

function data_uk(id){
    $.ajax({
        url: "<?php echo base_url('Finance/load_data_uk'); ?>",
        type: "POST",
        data: "id="+id,
        dataType: "json",
        success: function(result) {
            $('#data_uk').html(result);
            load_sisa();
        }
    });
}

function load_sisa(){
    var sisa_sj = $('#load_total_sj').val()-$('#load_total_uk').val();
    var sisa_uk = $('#load_total_uk').val()-$('#load_total_sj').val();
    sisa_sj = sisa_sj.toFixed(2);
    sisa_uk = sisa_uk.toFixed(2);
    if(sisa_sj>=0){
        $('#view_total_sj').css({'color': 'white', 'background-color':'green'});
    }else{
        $('#view_total_sj').css({'color': 'white', 'background-color':'red'});
    }

    if(sisa_uk>=0){
        $('#view_total_uk').css({'color': 'white', 'background-color':'green'});
    }else{
        $('#view_total_uk').css({'color': 'white', 'background-color':'red'});
    }
    $('#view_total_sj').html(numberWithCommas(sisa_sj));
    $('#view_total_uk').html(numberWithCommas(sisa_uk));
}

$('#tambah_sj').click(function(event) {
    event.preventDefault(); /*  Stops default form submit on click */

    if($.trim($("#nominal_bayar").val()) == ("" || 0)){
        $('#message').html("Nominal di Bayar harus diisi, tidak boleh kosong!");
        $('.alert-danger').show();
    }else{
        $(this).prop('disabled', true);
        $.ajax({// Run getUnlockedCall() and return values to form
            url: "<?= base_url('Finance/add_sj_match'); ?>",
            data:{
               id_modal:$('#id_modal_sj').val(),
               id_sj:$('#sj_id').val(),
               nominal_sdh_bayar:$('#nominal_sdh_bayar').val(),
               nominal_bayar:$('#nominal_bayar').val(),
               sisa_sj:$('#sisa_sj').val(),
               tanggal:$('#tanggal_dt').val()
            },
            type: "POST",
            success: function(result){
                if (result['message_type'] == 'sukses') {
                    $("#SJModal").modal('hide'); 
                    list_sj(<?= $h['id_supplier'].','.$h['id'];?>);
                    data_sj(<?= $h['id'];?>);
                    $('#tambah_sj').prop('disabled', false);
                } else {
                    $("#SJModal").modal('hide'); 
                }
            }
        });
    }
});

$("#approveData").click(function(){
    const nilai_sisa = $('#load_total_uk').val()-$('#load_total_sj').val();
    if(nilai_sisa>=0){
        var r=confirm("Anda yakin meng-approve Matching Faktur ini?");
        if (r==true){
            $("#nilai_sisa").val(nilai_sisa);
            $('#formku').attr("action", "<?=base_url();?>Finance/approve_match_sj");    
            $('#formku').submit(); 
        }
    }else{
        Toast.fire({
          icon: 'error',
          title: ' Nilai Uang Keluar harus lebih besar atau sama dengan Nilai Faktur'
        });
    }
});

function data_sj(id){
    $.ajax({
        url: "<?php echo base_url('Finance/load_data_sj'); ?>",
        type: "POST",
        data: "id="+id,
        dataType: "json",
        success: function(result) {
            $('#data_sj').html(result);
            load_sisa();
        }
    });
}

list_sj(<?= $h['id_supplier'].','.$h['id'];?>);
list_uk(<?= $h['id_supplier']; ?>);
data_sj(<?= $h['id']; ?>);
data_uk(<?= $h['id']; ?>);
load_sisa();    
</script>