<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Detail Invoice</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan">Invoice</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
  <div class="container-fluid">
    <form class="eventInsForm" method="post" target="_self" name="formku" id="formku">
    <input type="hidden" id="id" name="id" value="<?=$h['id'];?>">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <!-- /.card-header -->
          <!-- form start -->   
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>No Invoice</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_invoice" id="no_invoice" value="<?=$h['no_invoice'];?>" readonly>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                          <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" />
                          <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Term Of Payment</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="term_of_payment" id="term_of_payment" value="<?=$h['term_of_payment'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" readonly><?=$h['keterangan'];?></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Customer</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="customer" id="customer" value="<?=$h['nama_customer'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>PPN</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="ppn" id="ppn" value="<?=($h['ppn']==0)? 'No':'Yes';?>" disabled>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <ul class="nav nav-pills">
              <li class="nav-item"><a class="nav-link active" href="#summary" data-toggle="tab">Summary</a></li>
              <li class="nav-item"><a class="nav-link" href="#detail_ppn" data-toggle="tab">PPN</a></li>
              <?php if(!empty($list_denda)) { ?>
                <li class="nav-item"><a class="nav-link" href="#denda" data-toggle="tab">Denda</a></li>
              <?php } ?>
            </ul>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="tab-content">
              <div class="active tab-pane" id="summary">
                <h3 class="card-title bold">Detail Invoice</h3>
                <table class="table table_lowm table-bordered">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Barang</th>
                      <th>Netto/KG</th>
                      <th>POT/KG</th>
                      <th>Bruto/KG</th>
                      <th>Harga Jual</th>
                      <th>Total Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                    $no = 1;
                    $total_all = 0;
                    $bruto = 0;
                    $netto = 0;

                    foreach ($list_data as $row){
                        $bruto += $row->bruto;
                        $netto += $row->netto;
                        echo '<tr>';
                        echo '<td style="text-align:center">'.$no.'</td>';
                        echo '<td>'.$row->nama_barang.'</td>';
                        echo '<td class="text-right">'.number_format($row->netto,2,',','.').'</td>';
                        echo '<td class="text-right">'.number_format($row->bruto-$row->netto,2,',','.').'</td>';
                        echo '<td class="text-right">'.number_format($row->bruto,2,',','.').'</td>';
                        echo '<td class="text-right">'.number_format($row->harga,2,',','.').'</td>';
                        echo '<td class="text-right">'.number_format($row->sub_total+$row->adjustment,2,',','.').'</td>';
                        echo '</tr>';
                        $no++;
                        $total_all += $row->sub_total+$row->adjustment;
                    }
                    ?>
                        <tr>
                            <td colspan="2" class="text-right">Total</td>
                            <td class="text-right"><?=number_format($netto,2,',','.');?></td>
                            <td></td>
                            <td class="text-right"><?=number_format($bruto,2,',','.');?></td>
                            <td class="text-right">Total</td>
                            <td style="background-color: green;text-align:right;color:white;"><?php echo number_format($total_all,2,',','.');?></td>
                        </tr>
                        <tr>
                            <td colspan="7"></td>
                        </tr>
                        <input type="hidden" name="total" id="total" value="<?= $total_all ?>">
                  </tbody>
                </table>
                <hr>
                <?php
                    $total_denda = 0;
                if(!empty($list_denda)) { ?>
                <h3 class="card-title bold">Detail Denda</h3>
                <table class="table table_lowm table-bordered">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>No Faktur</th>
                      <th>No Mobil</th>
                      <th>Jenis Denda</th>
                      <th>Total Denda</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                    $no = 1;
                    $total_denda = 0;

                    foreach ($list_denda as $row){
                        echo '<tr>';
                        echo '<td style="text-align:center">'.$no.'</td>';
                        echo '<td>'.$row->no_surat_jalan.'</td>';
                        echo '<td>('.$row->no_kendaraan.') '.$row->jenis_kendaraan.'</td>';
                        echo '<td>'.$row->nomor.'</td>';
                        echo '<td class="text-right">'.number_format($row->sub_total,2,',','.').'</td>';
                        echo '</tr>';
                        $no++;
                        $total_denda += $row->sub_total;
                    }
                    ?>
                        <tr>
                            <td colspan="4" class="text-right">Total Denda</td>
                            <td style="background-color: green;text-align:right;color:white;"><?=number_format($total_denda,2,',','.');?></td>
                        </tr>
                        <tr>
                            <td colspan="7"></td>
                        </tr>
                  </tbody>
                </table>
                <?php } ?>
                <hr>
                <h3 class="card-title bold">Detail Biaya</h3>
                <table class="table table_lowm table-bordered">
                  <tbody>
                    <tr>
                        <td class="text-left">Jumlah Pokok</td>
                        <td colspan="2" class="text-right"><?= number_format($total_all,2,',','.');?></td>
                    </tr>
                    <?php
                    if($h['ppn']==0){
                      $ppn = 0;
                    }else{
                      $ppn = $total_all*10/100;
                    }
                        $total_pokok = $total_all + $ppn;
                        $grandtotal = $total_all + $ppn + $total_denda;
                    ?>
                    <tr>
                        <td class="text-left">PPN 10%</td>
                        <td colspan="2" class="text-right">(<i class="fa fa-plus"></i>)
                            <?=number_format($ppn,2,',','.');?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-left">Jumlah Pokok + PPN</td>
                        <td colspan="2" class="text-right" style="background-color: green; color: white;">
                            <?= number_format($total_pokok,2,',','.');?>
                        </td>
                    </tr>
                    <?php
                    if(!empty($tiket)){
                      foreach($tiket as $t){ 
                        $grandtotal -= $t->nilai_tiket;
                    ?>
                    <tr>
                        <td class="text-left">TIKET LUAR PULAU</td>
                        <td class="text-right"><?=number_format($t->netto,2,',','.');?> kg * Rp. <?=number_format($t->tiket,2,',','.');?></td>
                        <td class="text-right">(<i class="fa fa-minus"></i>)
                            <?=number_format($t->nilai_tiket,2,',','.');?>
                        </td>
                    </tr>
                    <?php }
                    }
                    if(!empty($list_denda)){
                    ?>
                    <tr>
                        <td class="text-left">Jumlah Denda</td>
                        <td colspan="2" class="text-right">(<i class="fa fa-plus"></i>) <?= number_format($total_denda,2,',','.');?></td>
                    </tr>
                    <?php 
                    }
                      foreach($list_obm as $o){ 
                      $nilai_obm = $o->bruto * $o->harga;
                      $grandtotal -= $nilai_obm;
                    ?>
                    <tr>
                        <td class="text-left">ONGKOS BONGKAR <?=$o->nama_bongkar_muat;?></td>
                        <td class="text-right"><?=number_format($o->bruto,2,',','.');?> kg * Rp. <?=number_format($o->harga,2,',','.');?></td>
                        <td class="text-right">(<i class="fa fa-minus"></i>)
                            <?=number_format($nilai_obm,2,',','.');?>
                        </td>
                    </tr>
                    <?php } ?>
                    <tr>
                        <td class="text-left">TOTAL</td>
                        <td colspan="2" class="text-right" style="background-color: green; color: white;">
                            <?= number_format($grandtotal,2,',','.');?>
                        </td>
                    </tr>
                    <input type="hidden" name="grandtotal" value="<?=$grandtotal;?>">

                  </tbody>
                </table>
                <a class="btn btn-primary btn-sm" href="<?=base_url(); ?>Finance/print_invoice/<?= $h['id']; ?>" target="_blank"><i class="fa fa-print"></i> Print</a>
              </div>
              <!-- /.tab-pane -->

              <?php if($h['ppn']==1) { ?>
              <div class="tab-pane" id="detail_ppn">
                <table class="table table_lowm table-bordered">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Barang</th>
                      <th>Qty</th>
                      <th>Harga @</th>
                      <th>Jumlah</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>PPN FAKTUR ( <?=$h['no_invoice'];?> ) ( <?=$h['no_ppn'];?> )</td>
                      <td></td>
                      <td></td>
                      <td><?=number_format($ppn,2,',','.');?></td>
                    </tr>
                  </tbody>
                </table>
                <a class="btn btn-primary btn-sm" href="<?=base_url(); ?>Finance/print_invoice2/<?= $h['id']; ?>" target="_blank"><i class="fa fa-print"></i> Print</a>
              </div>

              <?php } if(!empty($list_denda)) { ?>
              <div class="tab-pane" id="denda">
                <table class="table table_lowm table-bordered">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>No Faktur</th>
                      <th>No Mobil</th>
                      <th>Jenis Denda</th>
                      <th>Total Denda</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                    $no = 1;
                    $total_denda = 0;

                    foreach ($list_denda as $row){
                        echo '<tr>';
                        echo '<td style="text-align:center">'.$no.'</td>';
                        echo '<td>'.$row->no_surat_jalan.'</td>';
                        echo '<td>('.$row->no_kendaraan.') '.$row->jenis_kendaraan.'</td>';
                        echo '<td>'.$row->nomor.'</td>';
                        echo '<td class="text-right">'.number_format($row->sub_total,2,',','.').'</td>';
                        echo '</tr>';
                        $no++;
                        $total_denda += $row->sub_total;
                    }
                    ?>
                        <tr>
                            <td colspan="4" class="text-right">Total Denda</td>
                            <td style="background-color: green;text-align:right;color:white;"><?=number_format($total_denda,2,',','.');?></td>
                        </tr>
                        <tr>
                            <td colspan="7"></td>
                        </tr>
                  </tbody>
                </table>
              </div>
              <?php } ?>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-md-12">
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>No SKBDN</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="no_skbdn" id="no_skbdn" value="<?=$h['no_skbdn'];?>" placeholder="Nomor SKBDN ..." <?=($h['status']==1)?'readonly':'';?>>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>No PPN</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="no_ppn" id="no_ppn" value="<?=$h['no_ppn'];?>" placeholder="Nomor PPN ..." <?=($h['status']==1)?'readonly':'';?>>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <a href="<?= site_url('Finance/Invoice')?>" class="btn btn-default m-1 mb-3"> 
            <i class="fa fa-angle-left"></i> Kembali 
        </a>
        <?php
          if($h['status']==0){ ?>
            <a class="btn btn-info m-1 mb-3" href="<?=base_url().'Finance/edit_invoice/'.$h['id'];?>" >
              <i class="fa fa-edit"></i> Edit
            </a>
        <?php
          }
          if($h['status']==2){ ?>
            <a href="<?= site_url('Finance/qc_invoice/').$h['id'];?>" class="btn btn-info m-1 mb-3"> 
                <i class="fa fa-edit"></i> Edit Invoice 
            </a>
            <a href="<?=base_url();?>Finance/add_denda_invoice/<?=$h['id'];?>" class="btn btn-warning m-1 mb-3">
              <i class="fa fa-plus"></i> Tambah Denda
            </a>
            <button type="button" class="btn btn-success float-right" id="approveData">Approve</button>
        <?php }else if($h['status']==1 && $h['nilai_bayar']==0){ ?>
          <button type="button" class="btn btn-success float-right" id="openInv">Open Invoice</button>
        <?php } ?>
      </div>
    </div>
    </form>
  </div>
</section>
<div class="modal fade" id="approveModal" tabindex="-1" role="basic" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title">&nbsp;</h4>
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          </div>
          <div class="modal-body">
              <div class="row">
                  <div class="col-md-12">
                      <div class="alert alert-danger display-hide" id="alert-danger" style="display: none;">
                          <button class="close" data-close="alert"></button>
                          <span id="message">&nbsp;</span>
                      </div>
                  </div>
              </div>
              <form class="eventInsForm" method="post" target="_self" name="frmInv" 
                  id="frmInv">
                  <input type="hidden" id="modal_id_inv" name="modal_id_inv">
                  <div class="row">
                      <div class="col-md-4">
                          No. Invoice<font color="#f00">*</font>
                      </div>
                      <div class="col-md-8">
                          <input type="text" id="modal_no_invoice" name="modal_no_invoice" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-3">
                          Kendaraan<font color="#f00">*</font>
                      </div>
                      <div class="col-md-9">
                          <input type="text" id="kendaraan" name="kendaraan" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-3">
                          Bruto
                      </div>
                      <div class="col-md-9">
                          <input type="text" id="bruto" name="bruto" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-3">
                          Netto
                      </div>
                      <div class="col-md-9">
                          <input type="text" id="netto" name="netto" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-3">
                          Harga Beli
                      </div>
                      <div class="col-md-9">
                          <input type="text" id="harga_beli" name="harga_beli" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-3">
                          Harga Jual
                      </div>
                      <div class="col-md-9">
                          <input type="text" id="harga_jual" name="harga_jual" class="form-control myline" style="margin-bottom:5px" placeholder="Harga Jual ...">
                      </div>
                  </div>
              </form>
          </div>
          <div class="modal-footer">                        
              <button type="button" class="btn btn-primary" id="tambah_sj"><i class="fa fa-plus"></i> Tambah</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Tutup</button>
          </div>
      </div>
  </div>
</div>
<script>
$("#approveData").click(function(){

  if($.trim($("#no_skbdn").val()) == ''){
    Toast.fire({
      icon: 'error',
      title: ' Nomor SKBDN Harap diisi'
    });
  }else{
    var r=confirm("Anda yakin meng-approve Invoice ini?");
    if (r==true){
      $('#formku').attr("action", "<?=base_url();?>Finance/approve_inv");    
      $('#formku').submit(); 
    }
  }
});

$("#openInv").click(function(){
  var r=confirm("Anda yakin meng-open Invoice ini?");
  if (r==true){
    $('#formku').attr("action", "<?=base_url();?>Finance/open_inv");    
    $('#formku').submit(); 
  }
});
</script>