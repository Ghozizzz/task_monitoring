<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Master</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Master</a></li>
          <li class="breadcrumb-item active">Bongkar Muat</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- form start -->
        <form class="eventInsForm" method="post" target="_self" name="formku" id="formku">
          <input type="hidden" id="id" name="id">
          <div class="form-group">
            <label>Nama Bongkar muat</label>
            <input type="text" class="form-control" name="nama_bongkar_muat" id="nama_bongkar_muat" placeholder="Nama bongkar muat ...">
          </div>
          <div class="form-group">
            <label>Harga</label>
            <input type="text" class="form-control" name="harga" id="harga" placeholder="Harga bongkar muat ...">
          </div>
        </form>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="saveData">Save changes</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<section class="content">
  <div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-check"></i> Sukses</h5>
                <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
            </div>
            <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-ban"></i> Gagal</h5>
                <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
            </div>
        </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Data Bongkar muat</h3>
              <div class="card-tools">
                <button class="btn btn-block btn-primary" id="tambah">Tambah</button>
              </div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example2" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Nama Bongkar muat</th>
                <th>Harga</th>
                <th>Action</th>
              </tr>
              </thead>
              <tbody>
                <?php foreach ($data as $key => $v) { ?>
                <tr>
                  <td><?=$v->nama_bongkar_muat;?></td>
                  <td><?=$v->harga;?></td>
                  <td>
                    <button class="btn btn-info btn-sm" onclick="editData(<?=$v->id;?>)"><i class="fa fa-edit"></i> Edit</button>
                    <a class="btn btn-danger btn-sm" href="<?=base_url().'Admin/bongkar_muat_delete/'.$v->id;?>" onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-trash"></i> Delete</a>
                  </td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<script>
var dsState;
$("#tambah").click(function(){

  $('#nama_bongkar_muat').val('');  $('#id').val('');

  dsState = "Input";
  $("#myModal").find('.modal-title').text('Tambah Data Bongkar muat');
  $("#myModal").modal('show',{backdrop: 'true'}); 
});

$("#saveData").click(function(){
  if($.trim($("#nama_bongkar_muat").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Nama Bongkar muat harus diisi'
    });
  }else if($.trim($("#harga").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Harga harus diisi'
    });
  }else{
    if(dsState=="Input"){
        $('#formku').attr("action", "<?=base_url();?>Admin/bongkar_muat_save");
        $('#formku').submit();
    }else{
        $('#formku').attr("action", "<?=base_url();?>Admin/bongkar_muat_update");
        $('#formku').submit(); 
    }
  }
});

function editData(id){
  dsState = "Edit";
  $.ajax({
      url: "<?=base_url('Admin/bongkar_muat_edit');?>",
      type: "POST",
      data : {id: id},
      success: function (result){
          $('#nama_bongkar_muat').val(result['nama_bongkar_muat']);
          $('#harga').val(result['harga']);
          $('#id').val(result['id']);
          
          $("#myModal").find('.modal-title').text('Edit Data Bongkar muat');
          $("#myModal").modal('show',{backdrop: 'true'});           
      }
  });
}
</script>