<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Master</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Master</a></li>
          <li class="breadcrumb-item active">Harga Barang</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>

<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!-- form start -->
        <form class="eventInsForm" method="post" target="_self" name="formku" id="formku">
          <input type="hidden" id="id" name="id">
          <div class="form-group">
            <label>Nama Barang</label>
            <input type="text" class="form-control" name="barang" id="barang" disabled>
            <input type="hidden" id="id_barang" name="id_barang">
          </div>
          <div class="form-group">
            <label>Nama Customer</label>
            <input type="text" class="form-control" name="customer" id="customer" disabled>
            <input type="hidden" id="id_customer" name="id_customer">
          </div>
          <div class="form-group">
            <div class="input-group date" id="datetime_id" data-target-input="nearest">
                <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#datetime_id" placeholder="Tanggal ..." />
                <div class="input-group-append" data-target="#datetime_id" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
            </div>
          </div>
          <div class="separator_hr"><b>Harga</b></div>
          <div class="form-group">
            <label>Harga Beli</label>
            <input type="text" class="form-control" name="harga" id="harga" placeholder="Harga Beli ...">
          </div>
        </form>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="saveData">Save changes</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<section class="content">
  <div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-check"></i> Sukses</h5>
                <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
            </div>
            <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h5><i class="icon fas fa-ban"></i> Gagal</h5>
                <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
            </div>
        </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Data Harga Barang</h3>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example2" class="table table-bordered table-striped">
              <thead>
              <tr>
                <th>Nama Barang</th>
                <th>Nama Customer</th>
                <th>Harga Barang</th>
                <th>Tanggal</th>
                <th>Action</th>
              </tr>
              </thead>
              <tbody>
                <?php foreach ($data as $key => $v) { ?>
                <tr>
                  <td><?=$v->nama_barang;?></td>
                  <td><?=$v->nama_customer;?></td>
                  <td><?=number_format($v->harga,2,',','.');?></td>
                  <td><?=$v->tanggal;?></td>
                  <td>
                    <button class="btn btn-info btn-sm" onclick="editData(<?=$v->id;?>)"><i class="fa fa-edit"></i> Edit</button>
                    <a class="btn btn-danger btn-sm" href="<?=base_url().'Admin/delete_harga/'.$v->id;?>" 
                      onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-trash"></i> Delete</a>
                  </td>
                </tr>
                <?php } ?>
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="4">
                    <a class="btn btn-default" href="<?=base_url().'Admin/harga_barang';?>" >
                      <i class="fas fa-arrow-left"></i> Kembali</a>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<script>
$("#saveData").click(function(){
  if($.trim($("#id_barang").val()) == ("" || 0)){
    Toast.fire({
      icon: 'error',
      title: ' Nama barang harus diisi'
    });
  }else if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  }else if($.trim($("#harga").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Harga Beli harus diisi'
    });
  }else{
    $('#formku').attr("action", "<?=base_url();?>Admin/harga_barang_update");
    $('#formku').submit();
  }
});

function editData(id){
  $.ajax({
      url: "<?=base_url('Admin/harga_barang_edit');?>",
      type: "POST",
      data : {id: id},
      success: function (result){
          $('#id_barang').val(result['id_barang']);
          $('#id_customer').val(result['id_customer']);
          $('#barang').val(result['nama_barang']);
          $('#customer').val(result['nama_customer']);
          $('#harga').val(result['harga']);
          $('#tanggal_dt').val(result['tanggal']);
          $('#id').val(result['id']);
          
          $("#myModal").find('.modal-title').text('Edit Data harga_barang');
          $("#myModal").modal('show',{backdrop: 'true'});           
      }
  });
}
</script>