<?php 
    $this->load->view('layout/header');
    $this->load->view($content);
    $this->load->view('layout/footer');
?>