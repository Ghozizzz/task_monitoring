<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Detail Faktur</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SJ">Faktur</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
  <div class="container-fluid">
    <form class="eventInsForm" method="post" target="_self" name="formku" id="formku">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <!-- /.card-header -->
          <!-- form start -->
            <input type="hidden" id="id" name="id" value="<?=$h['id'];?>">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>No Faktur</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_surat_jalan" id="no_surat_jalan" placeholder="No Faktur ..." value="<?=$h['no_surat_jalan'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                      <!-- <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                        </div>
                        <input type="text" name="tanggal" id="tanggal_dm" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                      </div> -->
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="tanggal" id="tanggal" value="<?=$h['tanggal'];?>" readonly>
                    </div>
                  </div>
                  <?php if($h['denda_1']>0){ ?>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Denda</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" value="<?=number_format($h['denda_1'],2,',','.');?>" disabled>
                    </div>
                  </div>
                  <?php } if($h['denda_2']>0){ ?>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Denda K3</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" value="<?=number_format($h['denda_2'],2,',','.');?>" disabled>
                    </div>
                  </div>
                  <?php } ?>
                  <input type="hidden" name="denda" value="<?=$h['denda'];?>">
                  <input type="hidden" name="denda_1" value="<?=$h['denda'];?>">
                  <input type="hidden" name="denda_2" value="<?=$h['denda_2'];?>">
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Tiket Luar Pulau</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="tiket" id="tiket" placeholder="Tiket Luar Pulau ..." value="<?=number_format($h['tiket'],2,',','.');?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>BB Cash</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="bb_cash" id="bb_cash" placeholder="BB Cash ..." value="<?=number_format($h['bb_cash'],2,',','.');?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Ongkos Bongkar Muat</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="id_obm" id="id_obm" value="(<?=$h['nama_bongkar_muat'].') '.number_format($h['harga_bongkar_muat'],2,',','.');?>" disabled>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Nama Supplier</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="supplier" id="supplier" value="<?=$h['nama_supplier'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Nama Customer</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="customer" id="customer" value="<?=$h['nama_customer'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Jenis Kendaraan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="jenis_kendaraan" id="jenis_kendaraan" placeholder="Jenis Kendaraan ..." value="<?=$h['jenis_kendaraan'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Nomor Kendaraan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_kendaraan" id="no_kendaraan" placeholder="Nomor Kendaraan ..." value="<?=$h['no_kendaraan'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>PPN</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" id="ppn" name="ppn" value="<?=($h['ppn']==0)? 'No':'Yes';?>" readonly>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" disabled><?=$h['keterangan'];?></textarea>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Nilai Deposit</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="nilai_deposit" id="nilai_deposit" value="<?=number_format($h['nilai_deposit'],2,',','.');?>" disabled>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Details</h3>

            <div class="card-tools">
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Banyaknya</th>
                  <th>N A M A B A R A N G</th>
                  <th>Harga @ Rp</th>
                  <th>Jumlah</th>
                </tr>
              </thead>
              <tbody>
              <?php
                $no = 1;
                $bruto = 0;
                $potongan = 0;
                $netto = 0;
                $bonus = 0;
                $total = 0;
                foreach ($list_data as $row){
                    $no++;
                    $bruto += $row->bruto;
                    $potongan += $row->potongan;
                    $netto += $row->netto;
                    $bonus += $row->bonus;
                    $total += $row->total;
                }
                    echo '<tr>';
                    echo '<td>Netto</td>';
                    echo '<td class="text-right">'.number_format($netto,2,',','.').'</td>';
                    echo '<td>'.$row->nama_barang.'</td>';
                    echo '<td class="text-right">'.number_format($row->harga,2,',','.').'</td>';
                    echo '<td class="text-right">'.number_format($total,2,',','.').'</td>';
                    echo '</tr>';

                    echo '<tr>';
                    echo '<td>Potongan</td>';
                    echo '<td class="text-right">'.number_format($potongan,2,',','.').'</td>';
                    echo '<td colspan="3"></td>';
                    echo '</tr>';
                    $nilai_obm = $h['harga_bongkar_muat']*$bruto;
                    echo '<tr>';
                    echo '<td>Bruto</td>';
                    echo '<td class="text-right">'.number_format($bruto,2,',','.').'</td>';
                    echo '<td>OBM ('.$h['nama_bongkar_muat'].')</td>';
                    echo '<td class="text-right">'.number_format($h['harga_bongkar_muat'],2,',','.').'</td>';
                    echo '<td class="text-right">'.number_format($nilai_obm,2,',','.').'</td>';
                    echo '</tr>';
                ?>
                <tr>
                  <td colspan="3"></td>
                  <td class="text-center">Total Rp.</td>
                  <td>Rp.<span class="float-right bold"><?=number_format($total-$nilai_obm,2,',','.');?></span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="card">
          <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap table-bordered">
              <tbody>
                <?php 
                if($h['ppn']==1){
                  $nilai_ppn = $total * 10/100;
                }else{
                  $nilai_ppn = 0;
                }

                $tiket = $h['tiket']*$netto;

                $grand_total = $total + $nilai_ppn - $nilai_obm + $tiket - $h['denda'] - $h['bb_cash'];?>
                  <input type="hidden" id="nilai_tiket" name="nilai_tiket" value="<?=$tiket;?>">
                  <input type="hidden" id="total_detail" name="total_detail" value="<?=$total;?>">
                <tr>
                  <td colspan="5" class="bold bg-info">Summary</td>
                </tr>
                <tr>
                  <td colspan="3">Nilai Total</td>
                  <td colspan="2">(<i class="fa fa-plus"></i>) Rp. <span class="float-right bold"><?=number_format($total-$nilai_obm,2,',','.');?></span></td>
                </tr>
                <tr>
                  <td colspan="3">Nilai PPN</td>
                  <td colspan="2">(<i class="fa fa-plus"></i>) Rp. <span class="float-right bold"><?=number_format($nilai_ppn,2,',','.');?></span></td>
                </tr>
              <?php if($h['tiket'] > 0){ ?>
                <tr>
                  <td colspan="2">Tiket Luar Pulau</td>
                  <td colspan="1"><?=number_format($h['tiket'],0,',','.').' x '.number_format($netto,2,',','.');?></td>
                  <td colspan="2">(<i class="fa fa-plus"></i>) Rp. <span class="float-right bold"><?=number_format($tiket,2,',','.');?></span></td>
                </tr>
              <?php }if($h['bb_cash'] > 0){?>
                <tr>
                  <td colspan="3">BB Cash</td>
                  <td colspan="2">(<i class="fa fa-minus"></i>) Rp. <span class="float-right bold"><?=number_format($h['bb_cash'],2,',','.');?></span></td>
                </tr>
              <?php } if($h['denda'] > 0){ ?>
                <tr>
                  <td colspan="3">Denda</td>
                  <td colspan="2">(<i class="fa fa-minus"></i>) Rp. <span class="float-right bold"><?=number_format($h['denda'],2,',','.');?></span></td>
                </tr>
              <?php } ?>
                <tr class="bg-success">
                  <td colspan="3" class="bold">Grand Total</td>
                  <td colspan="2" class="bold">Rp. <span class="float-right"><?=number_format($grand_total,2,',','.');?></span></td>
                </tr>
                <input type="hidden" id="grand_total" name="grand_total" value="<?=$grand_total;?>">
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 pb-2">
        <a href="<?=base_url();?>SJ/index" class="btn btn-secondary float-left"><i class="fa fa-angle-left"></i> Kembali</a>
        &nbsp; 
        <?php if($h['status']==0){ ?>
          <a class="btn btn-info btn-md" href="<?= site_url().'SJ/edit/'.$h['id'];?>" ><i class="fa fa-edit"></i> Edit</a>
          <button type="button" class="btn btn-success float-right" id="approveData">Approve</button>
        <?php }elseif($h['status']==1){ ?>
          <button type="button" class="btn btn-success float-right" id="openData">Open Faktur</button>
        <?php } ?>
      </div>
    </div>
    </form>
  </div>
</section>
<script>
const formatter = new Intl.NumberFormat('en-US', {
   minimumFractionDigits: 2,      
   maximumFractionDigits: 2,
});

$("#approveData").click(function(){
  proceed_bayar();
});

function proceed_bayar(){
  var r=confirm("Anda yakin meng-approve Faktur ini?");
  if (r==true){
      $('#formku').attr("action", "<?=base_url();?>SJ/approve_sj");    
      $('#formku').submit(); 
  }
}

$("#openData").click(function(){
    var r=confirm("Anda yakin meng-open Permintaan barang ini?");
    if (r==true){
        $('#formku').attr("action", "<?=base_url();?>SJ/open_sj");    
        $('#formku').submit(); 
    }
});
</script>