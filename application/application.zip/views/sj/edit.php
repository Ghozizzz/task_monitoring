<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Edit Faktur</h1>
      </div>
      <div class="alert alert-success" style="display: none;" role="alert">
        &nbsp;
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SJ">Faktur</a></li>
          <li class="breadcrumb-item active">Edit</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-check"></i> Sukses</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Gagal</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
  <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=base_url('SJ/update'); ?>">
    <div class="row">
      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Header</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->   
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>No Faktur</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_surat_jalan" id="no_surat_jalan" placeholder="No Faktur ..." value="<?=$h['no_surat_jalan'];?>">

                      <input type="hidden" id="id" name="id" value="<?= $h['id']?>">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                        <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" />
                        <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>PPN</label>
                    </div>
                    <div class="col-md-8">
                      <select class="form-control select2bs4" name="ppn" id="ppn" style="width: 100%;">
                          <option value="0" <?=(($h['ppn']==0)? 'selected="selected"' : '' );?>>No</option>
                          <option value="1" <?=(($h['ppn']==1)? 'selected="selected"' : '' );?>>Yes</option>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"><?=$h['keterangan'];?></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row">
                    <div class="col-md-4">
                      <label>Nama Supplier</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control mb-3" id="nama_supplier" name="nama_supplier" value="<?=$h['nama_supplier'];?>" placeholder="Nama Supplier ...">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Nama Customer Tujuan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control mb-3" name="nama_customer" value="<?=$h['nama_customer'];?>" disabled>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Jenis Kendaraan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="jenis_kendaraan" id="jenis_kendaraan" placeholder="Jenis Kendaraan ..." value="<?=$h['jenis_kendaraan'];?>">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Nomor Kendaraan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_kendaraan" id="no_kendaraan" placeholder="Nomor Kendaraan ..." value="<?=$h['no_kendaraan'];?>">
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Detail Barang</h3>
            <div class="card-tools">
              <div class="input-group date" id="date_detail" data-target-input="nearest">
                <span class="d-inline">Tanggal Harga : </span>
                <input type="text" name="tanggal_detail" class="form-control datetimepicker-input" id="tanggal_detail" data-target="#date_detail" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" />
                <div class="input-group-append" data-target="#date_detail" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                </div>
              </div>
            </div>
          </div>
          <?php $already_insert = (empty($details))?'0':'1';?>
          <input type="hidden" id="already_insert" name="already_insert" value="<?=$already_insert;?>">
          <!-- /.card-header -->
          <div class="card-body">
            <?php if($already_insert==0){ ?>
            <div class="row">
              <div class="col-md-6">
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Jenis Barang</label>
                  </div>
                  <div class="col-md-8">
                    <select class="form-control select2bs4" name="id_jb" id="barang_1" onchange="get_harga(this.value,1);">
                        <option value="">Silahkan Pilih ...</option>
                      <?php foreach ($barang as $k) {
                        echo '<option value="'.$k->id.'">'.$k->nama_barang.'</option>';
                      } ?>
                    </select>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Bruto</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="bruto" id="bruto_1" placeholder="Bruto ..." onkeyup="hitung(1)">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Potongan</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="potongan" id="potongan_1" placeholder="Potongan ..." readonly>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Netto</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="netto" id="netto_1" placeholder="Netto ..." onkeyup="hitung(1)">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Harga</label>
                  </div>
                  <div class="col-md-8">
                    <select class="form-control select2bs4" id="harga_option_1" onchange="get_total(this.value,1)">
                      <option>Pilih barang terlebih dahulu</option>
                    </select>
                    <input type="hidden" name="id_harga" id="harga_id_1">
                    <input type="hidden" name="harga" id="harga_barang_1" value="0">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Bonus</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="bonus" id="bonus_1" placeholder="Bonus ..." onkeyup="hitung(1)">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Total</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="total" id="sub_total_1" placeholder="Sub Total ..." readonly>
                  </div>
                </div>
              </div>
            </div>
            <?php }else{ ?>
            <div class="row">
              <div class="col-md-6">
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Jenis Barang</label>
                  </div>
                  <div class="col-md-8">
                    <select class="form-control select2bs4" name="id_jb" id="barang_1" onchange="get_harga(this.value,1);">
                        <option value="">Silahkan Pilih ...</option>
                      <?php foreach ($barang as $k) {
                        echo '<option value="'.$k->id.'" '.(($k->id==$details['id_jb'])?'selected':'').'>'.$k->nama_barang.'</option>';
                      } ?>
                    </select>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Bruto</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="bruto" id="bruto_1" value="<?=$details['bruto'];?>" placeholder="Bruto ..." onkeyup="hitung(1)">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Potongan</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="potongan" id="potongan_1" value="<?=$details['potongan'];?>" placeholder="Potongan ..." readonly>
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Netto</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="netto" id="netto_1" value="<?=$details['netto'];?>" placeholder="Netto ..." onkeyup="hitung(1)">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Harga</label>
                  </div>
                  <div class="col-md-8">
                    <select class="form-control select2bs4" id="harga_option_1" onchange="get_total(this.value,1)">
                      <option>Pilih barang terlebih dahulu</option>
                    </select>
                    <input type="hidden" name="id_harga" id="harga_id_1" value="0">
                    <input type="hidden" name="harga" id="harga_barang_1" value="0">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Bonus</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="bonus" id="bonus_1" value="<?=$details['bonus'];?>" placeholder="Bonus ..." onkeyup="hitung(1)">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Total</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="total" id="sub_total_1" value="<?=$details['total'];?>" placeholder="Sub Total ..." readonly>
                  </div>
                </div>
              </div>
            </div>
            <?php } ?>
            <hr>
            <div class="row">
              <div class="col-md-6">
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Denda</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="denda_1" id="denda_1" placeholder="Denda ..." value="<?=$h['denda_1'];?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Denda K3</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="denda_2" id="denda_2" placeholder="Denda K3 ..." value="<?=$h['denda_2'];?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Nilai Deposit</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="nilai_deposit" id="nilai_deposit" placeholder="Nilai Deposit ..." value="<?=$h['nilai_deposit'];?>">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Tiket Luar Pulau</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="tiket" id="tiket" placeholder="Tiket Luar Pulau ..." value="<?=$h['tiket'];?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>BB Cash</label>
                  </div>
                  <div class="col-md-8">
                    <input type="text" class="form-control" name="bb_cash" id="bb_cash" placeholder="Tiket Luar Pulau ..." value="<?=$h['bb_cash'];?>">
                  </div>
                </div>
                <div class="row mb-3">
                  <div class="col-md-4">
                    <label>Ongkos Bongkar Muat</label>
                  </div>
                  <div class="col-md-8">
                    <select class="form-control select2bs4" name="bongkar_muat" id="bongkar_muat" style="width: 100%;">
                        <option value="0" <?=(($h['id_obm']==0)? 'selected="selected"' : '' );?>>Tidak Ada OBM</option>
                      <?php foreach ($bongkar_muat as $k) {
                        echo '<option value="'.$k->id.'" '.(($k->id==$h['id_obm'])? 'selected="selected"' : '' ).'>'.$k->nama_bongkar_muat.' ('.$k->harga.')</option>';
                      } ?>
                    </select>
                  </div>
                </div>
              </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
        <div class="mt-3">
          <a href="<?= site_url('SJ/index')?>" class="btn btn-info float-left mr-2"> 
            <i class="fa fa-angle-left"></i> Kembali 
          </a>
          <button type="button" class="btn btn-primary mb-4 float-right" id="update_surat_jalan">
            <i class="fa fa-save"></i> Save
          </button>
        </div>
      </div>
    </div>
  </form>
  </div>
</section>
<script>
function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

$("#update_surat_jalan").click(function(){
  if($.trim($("#no_surat_jalan").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Nomer Faktur harus diisi'
    });
  }else if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  } else if($.trim($("#nama_supplier").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Supplier harus diisi'
    });
  }else if($.trim($("#harga_barang_1").val()) == 0){
    Toast.fire({
      icon: 'error',
      title: ' Harga harus diisi'
    });
  } else{
    $(this).prop('disabled', true).text('Please Wait ...');
    $('#formku').submit();
  }
})

function hitung(id){
  const netto = $('#bruto_'+id).val()-$('#netto_'+id).val();
  $('#potongan_'+id).val(Number(netto.toFixed(2)));
  var sub_total = ( Number($('#harga_barang_'+id).val())+Number($('#bonus_'+id).val()) ) * Number($('#netto_'+id).val());
  sub_total = sub_total.toFixed(2);
  sub_total = numberWithCommas(Number(sub_total));
  $('#sub_total_'+id).val(sub_total);
}

function hitung_total(id){
  var total = 0;
  total += Number($('#sub_total_'+id).val());
  total = total.toFixed(2);
  total = numberWithCommas(Number(total));
  $('#total').val(total);
  hitung(id)
  console.log(total)
}

function timbang(id){
  const bruto = $("#bruto_"+id).val();
  const potongan = $("#potongan_"+id).val();
  const total_netto = bruto - potongan;
  const netto = total_netto.toFixed(2);
  $("#netto_"+id).val(netto);
  hitung(id);
}

function loadDetail(id){
  $.ajax({
    type:"POST",
    url:"<?= site_url('SJ/load_detail_html')?>",
    data:"id="+id,
    success:function(result){
      //console.log(result);
      $('#boxDetail').html(result.tabel);
      if(result.no==3){
        $('#tambah_detail').hide('slow');
      }else{
        $('#tambah_detail').show('slow');
      }
    }
  })
}

function updateDetail(id_detail,id){
  if($.trim($("#barang_"+id).val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Barang harus diisi'
    });
  }else if($.trim($("#netto_"+id).val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Netto harus diisi'
    });
  }else{
    $.ajax({
        type:"POST",
        url:'<?= site_url('SJ/update_detail'); ?>',
        data:{
          id:id_detail,
          id_jb:$('#barang_'+id).val(),
          bruto:$('#bruto_'+id).val(),
          potongan:$('#potongan_'+id).val(),
          netto:$('#netto_'+id).val(),
          id_harga:$('#harga_id_'+id).val(),
          harga:$('#harga_barang_'+id).val(),
          bonus:$('#bonus_'+id).val(),
          total:$('#sub_total_'+id).val()
        },
        success:function(result){
            if(result['status']=="sukses"){
                loadDetail($('#id').val());
                $('#message').html("");
                $('.alert-danger').hide(); 
            }else{
                $('#message').html(result['message']);
                $('.alert-danger').show(); 
            }            
        }
    });
  }
}

function hapusDetail(id){
    var r=confirm("Anda yakin menghapus item details ini?");
    if (r==true){
        $.ajax({
            type:"POST",
            url:'<?= site_url('SJ/delete_detail'); ?>',
            data:"id="+ id,
            success:function(result){
                if(result['status']=="sukses"){
                    loadDetail($('#id').val());
                }else{
                    alert(result['message']);
                }     
            }
        });
    }
}

function editDetail(val,harga,id){
  $.ajax({
    url: "<?=base_url('Admin/get_harga_barang_sj'); ?>",
    type: "POST",
    data: {
      id:val,
      id_harga:harga,
      idc:<?=$h['id_customer'];?>,
      cur_date:$('#tanggal_detail').val()
    },
    dataType: "json",
    success: function(result) {
      $('#btnEdit_'+id).hide();
      $('#lbl_bruto_'+id).hide();
      $('#lbl_potongan_'+id).hide();
      $('#lbl_netto_'+id).hide();
      $('#lbl_bonus_'+id).hide();
      $('#lbl_sub_total_'+id).hide();
      $('#lbl_harga_option_'+id).hide();

      $("#harga_option_"+id).show();
      $('#btnUpdate_'+id).show();
      $('#btnTimbang_'+id).show();
      $('#bruto_'+id).show();
      $('#potongan_'+id).show();
      $('#netto_'+id).show();
      $('#bonus_'+id).show();
      $('#sub_total_'+id).show();
      $("#harga_option_"+id).html(result);
      $("#harga_option_"+id).select2({
        theme: 'bootstrap4'
      });
    }
  });
}


function get_total(val,id){
  const result = val.split(","); 
  $('#harga_id_'+id).val(result[0]);
  $('#harga_barang_'+id).val(result[1]);
  // console.log(val);
  hitung(id);
}

function get_harga(val,id){
  if(val!= ''){
    $.ajax({
        url: "<?=base_url('Admin/get_harga_barang_list'); ?>",
        type: "POST",
        data: {
          id:val,
          idc:<?=$h['id_customer'];?>,
          cur_date:$('#tanggal_detail').val()
        },
        dataType: "html",
        success: function(result) {
          $("#harga_option_"+id).html(result);
          $('#harga_id_'+id).val(0);
          $('#harga_barang_'+id).val(0);
        }
    });
  }
}

function get_harga_current(val,harga,id){
  if(val!= ''){
    $.ajax({
        url: "<?=base_url('Admin/get_harga_current'); ?>",
        type: "POST",
        data: {
          id:val,
          id_harga:harga,
          idc:<?=$h['id_customer'];?>,
          cur_date:$('#tanggal_detail').val()
        },
        dataType: "html",
        success: function(data) {
          console.log(data);
          $("#harga_option_"+id).html(data);
          const result = $('#harga_option_'+id).val().split(","); 
          $('#harga_id_'+id).val(result[0]);
          $('#harga_barang_'+id).val(result[1]);
          hitung(id);
        }
    });
  }
}

function saveDetail(id){
  if($.trim($("#barang_"+id).val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Barang harus diisi'
    });
  }else if($.trim($("#bruto_"+id).val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Bruto harus diisi'
    });
  }else if($.trim($("#netto_"+id).val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Netto harus diisi'
    });
  }else if($.trim($("#potongan_"+id).val()) < 0){
    Toast.fire({
      icon: 'error',
      title: ' Potongang harus lebih atau sama dengan 0'
    });
  }else{
    $.ajax({
      type:"POST",
      url:'<?=base_url('SJ/save_detail'); ?>',
      data:{
        id:<?=$h['id'];?>,
        id_jb:$('#barang_'+id).val(),
        bruto:$('#bruto_'+id).val(),
        potongan:$('#potongan_'+id).val(),
        netto:$('#netto_'+id).val(),
        id_harga:$('#harga_id_'+id).val(),
        harga:$('#harga_barang_'+id).val(),
        bonus:$('#bonus_'+id).val(),
        total:$('#sub_total_'+id).val()
      },
      success:function(result){
        if(result['status']=="sukses"){
          $('#barang_'+id).val('').trigger('change');
          $("#harga_option_"+id).find('option').remove();
          $('#bruto_'+id).val('');
          $('#potongan_'+id).val('');
          $('#netto_'+id).val('');
          $('#harga_id_'+id).val('');
          $('#harga_barang_'+id).val('');
          $('#bonus_'+id).val('');
          $('#sub_total_'+id).val('');
          loadDetail($('#id').val());
        }else{
          alert(result['message']);
        }            
      }
    });
  }
}


$(function() {

  $('#date_detail').datetimepicker({
      format: 'YYYY-MM-DD',
  });

  <?php if($already_insert==1){
    echo 'get_harga_current('.$details['id_jb'].','.$details['id_harga'].',1);';
  }?>
  loadDetail(<?=$this->uri->segment(3);?>);
});
</script>