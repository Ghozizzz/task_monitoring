<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Pembayaran</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Pembayaran</a></li>
          <li class="breadcrumb-item active">Matching Faktur</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-check"></i> Sukses</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-ban"></i> Gagal</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Data Faktur</h3>
              <div class="card-tools">
                <a class="btn btn-block btn-primary" id="tambah" href="<?=base_url();?>SJ/add">Tambah</a>
              </div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row mb-1">
              <div class="col-md-1">
                <label for="Doctor-name">From</label>
              </div>
              <div class="col-md-3">
                <input type="date" id="StartDate"
                  class="form-control" value="<?=date('Y-m-d', strtotime('-2 months'));?>">
              </div>
              <div class="col-md-1">
                <label for="dob">To</label>
              </div>
              <div class="col-md-3">
                <input type="date" id="EndDate"
                  class="form-control" value="<?=date('Y-m-d');?>">
              </div>
              <div class="col-md-4">
                <a href="javascript:;" class="btn btn-info btn" id="filter"><i class="fa fa-search"></i> Filter </a>
                <a href="javascript:;" class="btn btn-info btn" id="reset">Reset</a>
              </div>
            </div>
            <table id="load_sj" class="table table-bordered">
              <thead>
                <tr>
                  <td>#</td>
                  <td>Nomor</td>
                  <td>Tanggal</td>
                  <td>Supplier</td>
                  <td>Status</td>
                  <td>Action</td>
                </tr>
              </thead>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<script>
$(document).ready(function() {
  $('#load_sj').DataTable( {
      "processing": true,
      "serverSide": true,
      "ajax":{
        "url":"<?=site_url('SJ/list_sj');?>",
        "type":"post",
        "data":function (data) {
            var startDate = $('#StartDate').val();
            var endDate = $('#EndDate').val();
            data.startDate = startDate;
            data.endDate = endDate;
        }
      },
      "columnDefs":[
        {
          "targets":'_all',
          "className":'p-1'
        },
      ]
  });
});

$("#reset").click(function () {
  $('input[type=date]').val('');
});

$("#filter").click(function () {
  $('#load_sj').DataTable().ajax.reload(); 
});
</script>