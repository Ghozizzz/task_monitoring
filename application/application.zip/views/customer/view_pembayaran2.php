<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Detail Pembayaran</h1>
      </div>
      <div class="alert alert-success" style="display: none;" role="alert">
        &nbsp;
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan">Pembayaran</a></li>
          <li class="breadcrumb-item active">View Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Header</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->   
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku">
            <input type="hidden" id="id" name="id" value="<?= $h['id']?>">
            <input type="hidden" id="nilai_pmb" name="nilai_pmb" value="<?= $h['nilai']?>">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>No Pembayaran</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_pmb" id="no_pmb" placeholder="No Pembayaran ..." value="<?=$h['no_pmb'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                        <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" disabled/>
                        <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker" >
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Customer</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="nama_customer" id="nama_customer" placeholder="Nama Customer ..." value="<?=$h['nama_customer'];?>" disabled>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                    <!-- <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="nominal">Nilai</label>
                        </div>
                        <div class="col-md-8">
                            <input type="text" id="nilai" name="nilai" class="form-control myline" style="margin-bottom:5px" value="<?=$h['nilai']?>" disabled>
                        </div>
                    </div> -->
                    <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" disabled><?=$h['keterangan'];?></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-12">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-info">
                    <h3 class="card-title">Data Invoice</h3>
                </div>
                <div class="card-body table-responsive p-0">
                  <table class="table table-hover text-nowrap table-bordered">
                      <thead>
                          <tr>
                              <th style="width: 5%;">No</th>
                              <th>No Invoice</th>
                              <th>Total</th>
                          </tr>
                      </thead>
                      <tbody id="data_inv">
                        <?php $no = 0; $total = 0; foreach ($details as $v) { $no++;
                          echo '<tr>';
                          echo '<td>'.$no.'</td>';
                          echo '<td>'.$v->no_invoice.'</td>';
                          echo '<td>'.number_format($v->inv_bayar,2,',','.').'</td>';
                          $total += $v->inv_bayar;
                        } ?>
                      </tbody>
                      <tfoot>
                        <tr>
                          <td colspan="2"><b>Total</b></td>
                          <td><b><?=number_format($total,2,',','.');?></b></td>
                        </tr>
                      </tfoot>
                  </table>
                </div>
            </div>
          </div>
          </div>
        </div>
        </form>
        <div class="col-md-12 mt-3 mb-3">
          <a href="<?=base_url();?>Customer/Pembayaran" class="btn btn-secondary float-left"><i class="fa fa-angle-left"></i> Kembali</a>
          <button type="button" class="btn btn-success float-right" id="openInv">Open Invoice</button>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<script>
$("#openInv").click(function(){
  var r=confirm("Anda yakin meng-open Pembayaran ini?");
  if (r==true){
    $('#formku').attr("action", "<?=base_url();?>Customer/open_inv");    
    $('#formku').submit(); 
  }
});
</script>