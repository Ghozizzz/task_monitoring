<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Detail Pembayaran</h1>
      </div>
      <div class="alert alert-success" style="display: none;" role="alert">
        &nbsp;
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan">Pembayaran</a></li>
          <li class="breadcrumb-item active">View Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-check"></i> Sukses</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Gagal</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>

        <div class="modal fade" id="INVModal" tabindex="-1" role="basic" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">&nbsp;</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              </div>
              <div class="modal-body">
                <div class="row">
                  <div class="col-md-12">
                    <div class="alert alert-danger display-hide" id="alert-danger">
                      <button class="close" data-close="alert"></button>
                      <span id="message">&nbsp;</span>
                    </div>
                  </div>
                </div>
                <form class="eventInsForm" method="post" target="_self" name="frmInv" id="frmInv">
                  <input type="hidden" id="id_modal_inv" name="id_modal_inv">
                  <div class="row">
                    <div class="col-md-5">
                      No. Invoice<font color="#f00">*</font>
                    </div>
                    <div class="col-md-7">
                        <input type="text" id="no_invoice" name="no_invoice" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        <input type="hidden" id="id_inv" name="id_inv">
                    </div>
                  </div>
                  <div class="row">
                      <div class="col-md-5">
                          Nilai
                      </div>
                      <div class="col-md-7">
                          <input type="text" id="nominal_inv" name="nominal_inv" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-5">
                          Nominal Sudah Di Bayar
                      </div>
                      <div class="col-md-7">
                          <input type="text" id="nominal_sdh_bayar" name="nominal_sdh_bayar" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-5">
                          Nominal Di Bayar
                      </div>
                      <div class="col-md-7">
                          <input type="text" id="nominal_bayar" name="nominal_bayar" class="form-control myline" style="margin-bottom:5px" value="0" onkeyup="getComa(this.value, this.id); hitungSubTotalINV();">
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-5">
                          Sisa Invoice
                      </div>
                      <div class="col-md-7">
                          <input type="text" id="sisa_inv" name="sisa_inv" class="form-control myline" style="margin-bottom:5px" value="0" readonly="readonly">
                      </div>
                  </div>
                </form>
              </div>
              <div class="modal-footer">                        
                  <button type="button" class="btn btn-primary" id="tambah_inv"><i class="fa fa-plus"></i> Tambah</button>
                  <button type="button" class="btn btn-primary" id="simpan_inv"><i class="fa fa-save"></i> Simpan</button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Tutup</button>
              </div>
          </div>
        </div>
      </div>

    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Header</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->   
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku">
            <input type="hidden" id="id" name="id" value="<?= $h['id']?>">
            <input type="hidden" id="nilai_pmb" name="nilai_pmb" value="<?= $h['nilai']?>">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>No Pembayaran</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_pmb" id="no_pmb" placeholder="No Pembayaran ..." value="<?=$h['no_pmb'];?>" disabled>
                      <input type="hidden" id="id" name="id" value="<?=$h['id'];?>">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                        <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" disabled/>
                        <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker" >
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Customer</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="nama_customer" id="nama_customer" placeholder="Nama Customer ..." value="<?=$h['nama_customer'];?>" disabled>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" disabled><?=$h['keterangan'];?></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                  <div class="card">
                      <div class="card-header bg-info">
                          <h3 class="card-title">List Invoice</h3>
                      </div>
                      <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">No</th>
                                    <th>No Invoice</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="list_inv">
                            
                            </tbody>
                        </table>
                      </div>
                  </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                  <div class="card">
                      <div class="card-header bg-info">
                          <h3 class="card-title">Data Invoice</h3>
                          <div class="float-right">
                            <a href="javascript:;" class="btn btn-warning btn-xs" id="add_biaya">
                              <i class="fa fa-plus"></i> Tambah Biaya </a>
                          </div>
                      </div>
                      <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered">
                            <thead>
                                <tr>
                                    <th style="width: 5%;">No</th>
                                    <th>No Invoice</th>
                                    <th>Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody id="data_inv">
                            
                            </tbody>
                        </table>
                      </div>
                  </div>
                </div>
            </div>
        </div>
        </form>
        <div class="col-md-12 mt-3 mb-3">
            <a href="<?=base_url();?>Customer/Pembayaran" class="btn btn-secondary float-left"><i class="fa fa-angle-left"></i> Kembali</a>
            <?php if($h['status']==0){ ?>
            <a href="javascript:;" class="btn btn-success float-right" id="approveData"><i class="fa fa-check"></i> Approve </a>
            <?php }?>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<div class="modal fade" id="BiayaModal" tabindex="-1" role="basic" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">&nbsp;</h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
      </div>
      <div class="modal-body">
        <form class="eventInsForm" method="post" target="_self" name="frmBiaya" id="frmBiaya">
          <div class="row">
            <div class="col-md-5">
              Keterangan<font color="#f00">*</font>
            </div>
            <div class="col-md-7">
                <input type="text" id="keterangan_biaya" name="keterangan_biaya" class="form-control myline" style="margin-bottom:5px" placeholder="Keterangan ...">
                <input type="hidden" id="id_biaya" name="id_biaya">
            </div>
          </div>
          <div class="row">
              <div class="col-md-5">
                  Nominal
              </div>
              <div class="col-md-7">
                  <input type="text" id="nominal_biaya" name="nominal_biaya" class="form-control myline" style="margin-bottom:5px" placeholder="Nominal ...">
              </div>
          </div>
        </form>
      </div>
      <div class="modal-footer">                        
          <button type="button" class="btn btn-primary" id="simpan_biaya"><i class="fa fa-plus"></i> Simpan</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Tutup</button>
      </div>
  </div>
</div>
<script>
const formatter = new Intl.NumberFormat('en-US', {
   minimumFractionDigits: 2,      
   maximumFractionDigits: 2,
});

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","); 
}

function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

function ReplaceNumberWithCommas(yourNumber) {
    //Seperates the components of the number
    var n= yourNumber.toString().split(".");
    //Comma-fies the first part
    n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    //Combines the two sections
    return n.join(".");
}

$('#add_biaya').click(function(event) {
  event.preventDefault();

  $('#keterangan_biaya').val('');
  $('#nominal_biaya').val('');
  $('#id_biaya').val('');

  $("#BiayaModal").find('.modal-title').text('Input Pembayaran Biaya');
  $("#BiayaModal").modal('show',{backdrop: 'true'});
});

$("#simpan_biaya").click(function(){
  if($.trim($("#keterangan_biaya").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Keterangan harus diisi'
    });
  }else if($.trim($("#nominal_biaya").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Nominal harus diisi'
    });
  }else{
    $('#simpan_biaya').prop('disabled', true);
    $.ajax({
        url: "<?=site_url('Customer/add_biaya_pmb'); ?>",
        type: "POST",
        data: {
            id_pmb:<?=$h['id']?>,
            keterangan:$('#keterangan_biaya').val(),
            nominal:$('#nominal_biaya').val()
        },
        dataType: "json",
        success: function(result) {
          if (result['message_type'] == 'sukses') {
            $("#BiayaModal").modal('hide'); 
            data_inv(<?= $h['id'];?>);
          }else{
            alert(result['message']);
          }
          $('#simpan_biaya').prop('disabled', false);
        }
    });
  }
});

function hitungSubTotalINV(){
    nominal_inv = $('#nominal_inv').val().toString().replace(/\,/g, "");
    n1 = $('#nominal_sdh_bayar').val().toString().replace(/\,/g, "");
    n2 = $('#nominal_bayar').val().toString().replace(/\,/g, "");
    total_harga = formatter.format(Number(nominal_inv) - (Number(n1) + Number(n2)));
    console.log(nominal_inv, n1, n2, total_harga);
    $('#sisa_inv').val(total_harga.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

$("#approveData").click(function(){
  var r=confirm("Anda yakin meng-approve Pembayaran ini?");
  if (r==true){
    $('#nilai_pmb').val($('#total_inv').val());
    $('#formku').attr("action", "<?=base_url();?>Customer/approve_pmb");    
    $('#formku').submit(); 
  }
});

function list_inv(id_cust){
    $.ajax({
        url: "<?= site_url('Customer/load_list_inv'); ?>",
        type: "POST",
        data: {
            id:id_cust,
            id_pmb:<?=$h['id'];?>
        },
        dataType: "json",
        success: function(result) {
            $('#list_inv').html(result);
        }
    });
}

function input_inv(id){
    $.ajax({
        url: "<?= site_url('Customer/get_data_inv'); ?>",
        type: "POST",
        data: {
            id:id
        },
        dataType: "json",
        success: function(result){
            $("#INVModal").find('.modal-title').text('Input Pembayaran Invoice');
            $("#INVModal").modal('show',{backdrop: 'true'});
            $("#tambah_inv").show();
            $("#simpan_inv").hide();
            $("#alert-danger").hide();
            $("#id_modal_inv").val(<?php echo $h['id'];?>);
            
            $("#no_invoice").val(result['no_invoice']);
            $("#id_inv").val(result['id']);
            $("#nominal_inv").val(numberWithCommas(result['nilai_invoice']));
            $("#nominal_sdh_bayar").val(numberWithCommas(result['nilai_bayar']));
            $("#nominal_bayar").val(numberWithCommas(result['nilai_sisa']));
            $("#sisa_inv").val(0);
        }
    });
}

function data_inv(id){
    $.ajax({
        url: "<?php echo base_url('Customer/load_data_inv'); ?>",
        type: "POST",
        data: "id="+id,
        dataType: "json",
        success: function(result) {
            $('#data_inv').html(result);
        }
    });
}

$('#tambah_inv').click(function(event) {
    event.preventDefault(); /*  Stops default form submit on click */

    if($.trim($("#nominal_bayar").val()) == ("" || 0)){
        $('#message').html("Nominal di Bayar harus diisi, tidak boleh kosong!");
        $('.alert-danger').show();
    }else{
        $(this).prop('disabled', true);
        $.ajax({// Run getUnlockedCall() and return values to form
            url: "<?= site_url('Customer/add_inv_pmb'); ?>",
            data:{
               id_modal:$('#id_modal_inv').val(),
               id_inv:$('#id_inv').val(),
               nominal_sdh_bayar:$('#nominal_sdh_bayar').val(),
               nominal_bayar:$('#nominal_bayar').val(),
               sisa_inv:$('#sisa_inv').val(),
               tanggal:$('#tanggal_dt').val()
            },
            type: "POST",
            success: function(result){
                if (result['message_type'] == 'sukses') {
                    $("#INVModal").modal('hide'); 
                    list_inv(<?= $h['id_customer']?>);
                    data_inv(<?= $h['id'];?>);
                    $('#tambah_inv').prop('disabled', false);
                } else {
                    $("#INVModal").modal('hide'); 
                }
            }
        });
    }
});

function delINV(id,id_inv){
    if(confirm('Anda yakin menghapus Pembayaran Invoice ini?')){
        $.ajax({
            type:"POST",
            url:'<?= site_url('Customer/del_inv'); ?>',
            data:{
               id:id,
               id_inv:id_inv
            },
            success:function(result){
                if(result['message_type']=="sukses"){
                    list_inv(<?= $h['id_customer'];?>);
                    data_inv(<?= $h['id']?>)
                }else{
                    $('#message').html(result['message']);
                    $('.alert-danger').show(); 
                }            
            }
        });
    }
}

list_inv(<?= $h['id_customer'];?>);
data_inv(<?= $h['id']?>);
</script>