<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Edit Pembayaran</h1>
      </div>
      <div class="alert alert-success" style="display: none;" role="alert">
        &nbsp;
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan">Pembayaran</a></li>
          <li class="breadcrumb-item active">Edit</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-check"></i> Sukses</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Gagal</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Header</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->   
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=base_url('Customer/update'); ?>">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>No Pembayaran</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_pmb" id="no_pmb" placeholder="No Pembayaran ..." value="<?=$h['no_pmb'];?>">
                      <input type="hidden" id="id" name="id" value="<?= $h['id']?>">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                        <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" />
                        <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Customer</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="nama_customer" id="nama_customer" value="<?=$h['nama_customer'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"><?=$h['keterangan'];?></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.card -->
      </div>
        </form>
        <div class="mt-3">
          <a href="<?= site_url('Customer/Pembayaran')?>" class="btn btn-info float-left mr-2"> 
            <i class="fa fa-angle-left"></i> Kembali 
          </a>
          <button type="button" class="btn btn-primary mb-4 float-left" id="save_pembayaran">
            <i class="fa fa-save"></i> Save
          </button>
        </div>
        <!-- /.card -->
    </div>
  </div>
</section>

<script>
function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

$("#save_pembayaran").click(function(){
  if($.trim($("#no_pmb").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Nomer Pembayaran harus diisi'
    });
  }else if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  } else if($.trim($("#customer").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Customer harus diisi'
    });
  } else if($.trim($("#id_inv").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Invoice harus diisi'
    });
  } else if($.trim($("#inv_bayar").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Invoice Bayar harus diisi'
    });
  } else{
    $(this).prop('disabled', true).text('Please Wait ...');
    $('#formku').submit();
  }
})

</script>