<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Tambah Data Pembayaran</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>Customer/Pembayaran">Pembayaran</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Form Header</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=base_url('Customer/save_pembayaran');?>">    
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>No Pembayaran</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group mb-3">
                          <div class="input-group-prepend">
                          <span class="input-group-text">PMB-</span>
                          </div>
                          <input type="text" class="form-control" name="no+pmb" id="no+pmb" value="Auto Generate" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                          <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." />
                          <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                <div class="row mb-3">
                  <div class="col-md-4 mb-3">
                    <label>Nama Customer</label>
                  </div>
                  <div class="col-md-8">
                    <select class="supplier form-control select2bs4" name="customer" id="customer" style="width: 100%;">
                        <option value="0">Silahkan Pilih ...</option>
                        <?php foreach ($customer as $key => $v) {?>
                            <option value="<?= $v->id?>"><?= $v->nama_customer?></option>
                        <?php } ?>
                    </select>
                  </div>
                  <div class="col-md-4">
                    <label>Keterangan</label>
                  </div>
                  <div class="col-md-8">
                    <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"></textarea>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
                <button type="button" class="btn btn-primary float-right" onclick="simpanData();"><i class="fa fa-save"></i> Submit</button>
                <a href="<?= site_url('Finance/MatchingSJ')?>" class="btn btn-info float-right" style="margin-right:5px;"> 
                    <i class="fa fa-angle-left"></i> Kembali 
                </a>
            </div>
          </form>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<script>
function simpanData(){
  if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  } else if($.trim($("#customer").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Customer harus diisi'
    });
  }else{
    $(this).prop('disabled', true).text('Please Wait ...');
    $('#formku').submit();
  }
};

function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}
</script>