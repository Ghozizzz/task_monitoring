<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Laporan</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?= site_url('laporan') ?>">Laporan</a></li>
          <li class="breadcrumb-item active">Harga Barang Customer</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Laporan Harga Barang Customer</h3>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="row mb-3">
                      <div class="col-md-4">
                        Nama Customer
                      </div>
                      <div class="col-md-8">
                        <select class="customer form-control select2bs4" name="customer" id="customer" style="width: 100%;">
                            <option value="0">Silahkan Pilih ...</option>
                            <?php foreach($customer as $row) {
                              echo '<option value="'.$row->id.'">'.$row->nama_customer.'</option>';
                            }?>
                        </select>
                      </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            &nbsp;
                        </div>
                        <div class="col-md-8">
                            <a href="javascript:;" class="btn btn-success" onclick="simpanData();"> 
                                <i class="fa fa-search"></i> Proses 
                            </a>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<script>
function simpanData(){
    if($("#customer").val() == 0){
    Toast.fire({
      icon: 'error',
      title: ' Customer harus diisi'
    });
    }else{   
        var c=$('#customer').val();
        window.open('<?= site_url();?>Laporan/print_laporan_harga_cust?c='+c,'_blank');
    };
};
</script>