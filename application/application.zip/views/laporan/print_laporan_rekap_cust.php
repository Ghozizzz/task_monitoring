<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
<body class="margin-left:40px;">
 <table width="100%" >
    <tr>
        <td width="34%" align="center">
        <h4>Laporan Rekap <?=$customer['nama_customer'];?> <br>
        Per <?= tanggal_indo(date("Y-m-d")) ;?></h4></td>
    </tr>
 </table>
<table width="100%" class="table" style="font-size: 16px;" border="2">
    <tr>
        <th style="border-top: 1px solid; border-bottom: 1px solid; text-align: left;">Tgl</th>
        <?php foreach ($tgl_jam as $key => $v) { ?>
            <th style="border-top: 1px solid; border-bottom: 1px solid; text-align: right;"><?=date('d-m-Y', strtotime($v->tanggal));?></th>
        <?php } ?>
    </tr>
    <tr>
        <th style="border-top: 1px solid; border-bottom: 1px solid; text-align: left;">Jam</th>
        <?php foreach ($tgl_jam as $key => $v) { ?>
            <th style="border-top: 1px solid; border-bottom: 1px solid; text-align: right;"><?=date('h:i:s', strtotime($v->tanggal));?></th>
        <?php } ?>
    </tr>
    <tbody>
    <?php
    $no=1;
    foreach ($details as $row) { ?>
        <tr>
            <td><?=$row->nama_barang;?></td>
            <td align="right"><?=$row->l1;?></td>
            <td align="right"><?=$row->l2;?></td>
            <td align="right"><?=$row->l3;?></td>
            <td align="right"><?=$row->l4;?></td>
            <td align="right"><?=$row->l5;?></td>
            <td align="right"><?=$row->l6;?></td>
            <td align="right"><?=$row->l7;?></td>
            <td align="right"><?=$row->l8;?></td>
            <td align="right"><?=$row->l9;?></td>
            <td align="right"><?=$row->l10;?></td>
        </tr>
    <?php } ?>
    </tbody>
</table>
    </body>
</html>