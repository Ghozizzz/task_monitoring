<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
    <body class="margin-left:40px;">
        <table border="0" cellpadding="0" width="100%" cellspacing="0" style="font-family:Microsoft Sans Serif">
            <tr>
                <td align="left" colspan="3">
                    <strong><span style="font-size:20px;">PT. YAPUTRA ABADI PERKASA</span></strong>
                </td>
            </tr>
            <tr>
                <td height="5px"></td>
            </tr>
            <tr>
                <td style="padding-left:20px;"><span style="font-size:15px;">Perkantoran Tomang Tol Blok A1 / 50</td>
                <td style="padding-right: 20px;">Kepada</td>
            </tr>
            <tr>
                <td style="padding-left: 11px;">Taman Kedoya Baru - Kedoya Selatan</td>
                <td>YTH. <?= $h['nama_supplier']?></td>
            </tr>
            <tr>
                <td style="padding-left: 90px;">Jakarta Barat</td>
                <td>Di <?= $h['alamat']?></td>
            </tr>
            <tr>
                <td style="padding-left: 60px;">Hp. 0818 0824 1509 </span></td>
            </tr>
            <tr>
                <td colspan="3">&nbsp;</td>
            </tr>
            <tr>
                <td colspan="3">
                    <p align="center" style="font-size:20px;">
                        <strong><b><u>SURAT JALAN</u></b></strong>
                    </p>
                </td>              
            </tr>
        </table>
        <table border="0" cellpadding="2" cellspacing="0" width="900px" style="font-family:Times New Roman;">
            <tr>
                <td width="40%">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%" style="font-size: 18px;">
                        <tr>
                            <td>Jenis Mobil </td>
                            <td>: <?= $h['jenis_kendaraan']?></td>
                        </tr>
                        <tr>
                            <td>No. Kendaraan</td>
                            <td>: <?= $h['no_kendaraan']?></td>
                        </tr>
                    </table>
                </td>
                <td>&nbsp;</td>
                <td width="40%">
                    <table border="0" cellpadding="2" cellspacing="0" width="100%" style="font-size: 18px;">
                        <tr>
                            <td>&nbsp;</td>
                        </tr>
                        <tr>
                            <td>Tanggal</td>
                            <td>: <?= tanggal_indo($h['tanggal']); ?></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <table border="1" cellpadding="5" cellspacing="0" width="100%" style="font-size: 18px;">
            <tr>
                <th style="width: 5%;">NO</th>
                <th style="width: 40%;">Jenis Barang</th>
                <th rowspan="5">&nbsp;</th>
            </tr>
            <?php
            $no = 1;
            foreach($details as $d)
            {?>
            <tr>
                <td><?= $no++;?></td>
                <td><?= $d->nama_barang?></td>
            </tr>
            <?php }?>
        </table>
        <table border="0" width="100%" class="mt-2">
            <tr>
                <td style="text-align:center">Penerima</td>
                <td style="text-align:center">Pengemudi</td>
                <td style="text-align:center">Pengirim</td>
            </tr>
            <tr>
                <td style="text-align:center">( Gudang )</td>
                <td style="text-align:center">( Supir )</td>
                <td style="text-align:center">( Supplier )</td>
            </tr>
        </table>
        <p>&nbsp;</p>
	<body onLoad="window.print()">
    </body>
</html>
        