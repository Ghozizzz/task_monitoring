<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Pembayaran</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Pembayaran</a></li>
          <li class="breadcrumb-item active">Matching Faktur</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-check"></i> Sukses</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-ban"></i> Gagal</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Data Matching Faktur</h3>
              <div class="card-tools">
                <a class="btn btn-block btn-primary" id="tambah" href="<?=base_url();?>SuratJalan/addMatchingSJ"><i class="fa fa-plus"></i> Tambah</a>
              </div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row mb-1">
              <div class="col-md-1">
                <label for="Doctor-name">Supplier</label>
              </div>
              <div class="col-md-3">
                <select class="supplier form-control select2bs4" name="supplier" id="supplier" style="width: 100%;" placeholder="Silahkan pilih...">
                    <option value="0">Silahkan Pilih ...</option>
                    <?php foreach($supplier as $row) {
                      echo '<option value="'.$row->id.'">'.$row->nama_supplier.'</option>';
                    }?>
                </select>
              </div>
              <div class="col-md-1">
                <label for="dob">Group Supplier</label>
              </div>
              <div class="col-md-3">
                <select class="group_supplier form-control select2bs4" name="group_supplier" id="group_supplier" style="width: 100%;" placeholder="Silahkan pilih...">
                    <option value="0">Silahkan Pilih ...</option>
                    <?php foreach($group_supplier as $row) {
                      echo '<option value="'.$row->id.'">'.$row->nama_group_supplier.'</option>';
                    }?>
                </select>
              </div>
              <div class="col-md-1">
                <label for="dob">Customer</label>
              </div>
              <div class="col-md-3">
                <select class="customer form-control select2bs4" name="customer" id="customer" style="width: 100%;" placeholder="Silahkan pilih...">
                    <option value="0">Silahkan Pilih ...</option>
                    <?php foreach($customer as $row) {
                      echo '<option value="'.$row->id.'">'.$row->nama_customer.'</option>';
                    }?>
                </select>
              </div>
            </div>
            <div class="row mb-1">
              <div class="col-md-1">
                <label for="Doctor-name">From</label>
              </div>
              <div class="col-md-3">
                <input type="date" id="StartDate"
                  class="form-control" >
              </div>
              <div class="col-md-1">
                <label for="dob">To</label>
              </div>
              <div class="col-md-3">
                <input type="date" id="EndDate"
                  class="form-control" >
              </div>
              <div class="col-md-4">
                <a href="javascript:;" class="btn btn-info btn" id="filter"><i class="fa fa-search"></i> Filter </a>
                <a href="javascript:;" class="btn btn-info btn" id="reset">Reset</a>
              </div>
            </div>
            <table id="load_sj" class="table table-bordered">
              <thead>
                <tr>
                  <td>#</td>
                  <td>Nomor</td>
                  <td>Tanggal</td>
                  <td>Supplier</td>
                  <td>Group</td>
                  <td>Customer</td>
                  <td>Kendaraan</td>
                  <td>Nilai</td>
                  <td>Action</td>
                </tr>
              </thead>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>
<div class="modal fade" id="SJModal" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">&nbsp;</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger display-hide" id="alert-danger">
                            <button class="close" data-close="alert"></button>
                            <span id="message">&nbsp;</span>
                        </div>
                    </div>
                </div>
                <form class="eventInsForm" method="post" target="_self" name="frmInv" 
                    id="frmInv">
                    <input type="hidden" id="id_modal_sj" name="id_modal_sj">
                    <input type="hidden" id="id_supplier" name="id_supplier">
                    <div class="row">
                        <div class="col-md-5">
                            No. Faktur<font color="#f00">*</font>
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="no_surat_jalan" name="no_surat_jalan" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                            <input type="hidden" id="sj_id" name="sj_id">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            Nilai
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="nominal_sj" name="nominal_sj" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            Nominal Sudah Di Bayar
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="nominal_sdh_bayar" name="nominal_sdh_bayar" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            Nominal Di Bayar
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="nominal_bayar" name="nominal_bayar" class="form-control myline" style="margin-bottom:5px" value="0" onkeyup="getComa(this.value, this.id); hitungSubTotalSJ();">
                        </div>
                    </div>
                    <small>*Nilai kelebihan akan masuk saldo "bayar lebih"</small>
                    <div class="row">
                        <div class="col-md-5">
                            Sisa Faktur
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="sisa_sj" name="sisa_sj" class="form-control myline" style="margin-bottom:5px" value="0" readonly="readonly">
                        </div>
                    </div>
                    <div class="row" style="margin-bottom:5px">
                        <div class="col-md-5">
                            Tanggal Bayar
                        </div>
                        <div class="col-md-7">
                          <div class="input-group date" id="date_id" data-target-input="nearest">
                              <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..."/>
                              <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                                  <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                              </div>
                          </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            Jenis Pembayaran
                        </div>
                        <div class="col-md-7">
                          <select class="form-control select2bs4" name="jenis_id" id="jenis_id" style="width: 100%; margin-bottom:5px" onchange="get_cek(this.value);">
                            <option value="0">Pilih Jenis Pembayaran ...</option>
                            <option value="Cash">Cash</option>
                            <option value="Transfer">Transfer</option>
                          </select>
                        </div>
                    </div>
                    <div class="row show_bank_tuj" style="display: none; margin-bottom:5px">
                        <div class="col-md-5">
                            Rekening Tujuan
                        </div>
                        <div class="col-md-7">
                          <input type="text" class="form-control" id="rekening_tujuan" name="rekening_tujuan" placeholder="Rekening Tujuan ...">
                        </div>
                    </div>
                    <div class="row show_bank_tuj" style="display: none; margin-bottom:5px">
                        <div class="col-md-5">
                            Nama Bank
                        </div>
                        <div class="col-md-7">
                            <select class="bank form-control select2bs4" name="bank" id="bank" style="width: 100%;">
                                <option value="0">Silahkan Pilih ...</option>
                                <?php foreach ($bank as $b) {
                                    echo '<option value="'.$b->id.'">'.$b->nama_bank.'</option>';
                                }?>
                            </select>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">                        
                <button type="button" class="btn btn-primary" id="tambah_sj"><i class="fa fa-plus"></i> <span id="tambah_sj_txt">Tambah</span></button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Tutup</button>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
  $('#load_sj').DataTable( {
      "processing": true,
      "serverSide": true,
      "ajax":{
        "url":"<?=site_url('SuratJalan/get_sj_belum_lunas');?>",
        "type":"post",
        "data":function (data) {
            var startDate = $('#StartDate').val();
            var endDate = $('#EndDate').val();
            data.startDate = startDate;
            data.endDate = endDate;
            data.id_supplier = $('#supplier').val();
            data.id_gs = $('#group_supplier').val();
            data.id_customer = $('#customer').val();
        }
      },
      "columnDefs":[
        {
          "targets":'_all',
          "className":'p-1'
        },
        {
          "targets":[3,4],
          "className":'text-right'
        }
      ]
  });
});

$("#reset").click(function () {
  $('input[type=date]').val('');
  $('#supplier').val(0).trigger('change');
  $('#group_supplier').val(0).trigger('change');
  $('#customer').val(0).trigger('change');
  $('#load_sj').DataTable().ajax.reload();
});

$("#filter").click(function () {
  $('#load_sj').DataTable().ajax.reload(); 
});

const formatter = new Intl.NumberFormat('en-US', {
   minimumFractionDigits: 2,      
   maximumFractionDigits: 2,
});

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","); 
}

function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

function get_cek(id){
  if(id == "Transfer"){
      // $("#show_rek_tuj").show();
      $('.show_bank_tuj').show();
  }else if(id === "Cash") {
      $('.show_bank_tuj').hide();
  }
};

function hitungSubTotalSJ(){
    nominal_sj = $('#nominal_sj').val().toString().replace(/\,/g, "");
    n1 = $('#nominal_sdh_bayar').val().toString().replace(/\,/g, "");
    n2 = $('#nominal_bayar').val().toString().replace(/\,/g, "");
    total_harga = formatter.format(Number(nominal_sj) - (Number(n1) + Number(n2)));
    // console.log(nominal_sj, n1, n2, total_harga);
    // console.log(nominal_sj+' | '+n3+' | '+total_harga);
    $('#sisa_sj').val(total_harga.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

function input_sj(id){
  $.ajax({
    url: "<?= site_url('SuratJalan/get_data_sj'); ?>",
    type: "POST",
    data: {
        id:id
    },
    dataType: "json",
    success: function(result){
      // console.log(result);
      $("#SJModal").find('.modal-title').text('Input Faktur');
      $("#SJModal").modal('show',{backdrop: 'true'});
      $("#tambah_sj").show();
      $("#alert-danger").hide();
      
      $("#id_supplier").val(result['id_supplier']);
      $("#no_surat_jalan").val(result['no_surat_jalan']);
      $("#sj_id").val(result['id']);
      $("#nominal_sj").val(numberWithCommas(result['nilai']));
      $("#nominal_sdh_bayar").val(numberWithCommas(result['nilai_total_bayar']));
      $("#nominal_bayar").val(numberWithCommas(result['nilai_sisa']));
      $("jenis_id").val('');
      $("#rekening_tujuan").val('');
      $("#bank").val('');
      $("#sisa_sj").val(0);
    }
  });
}

$('#tambah_sj').click(function(event) {
    event.preventDefault(); /*  Stops default form submit on click */

    if($.trim($("#nominal_bayar").val()) == ("" || 0)){
        Toast.fire({
          icon: 'error',
          title: ' Rekening Tujuan harus diisi'
        });
    }else if($.trim($("#tanggal_dt").val()) == ''){
        Toast.fire({
          icon: 'error',
          title: ' Tanggal Bayar harus diisi'
        });
    }else{
      if($.trim($("#jenis_id").val()) == 0){
        Toast.fire({
          icon: 'error',
          title: ' Jenis Pembayaran harus diisi'
        });
      }else if($.trim($("#jenis_id").val()) == "Cash"){
          var r=confirm("Anda yakin meng-approve Matching Faktur ini?");
          if (r==true){
            $(this).prop('disabled', true);
            proceed_bayar();/// LANJUT BAYAR
          }
      }else{
        if($.trim($("#rekening_tujuan").val()) == ""){
          Toast.fire({
            icon: 'error',
            title: ' Rekening Tujuan harus diisi'
          });
        }else if($.trim($("#bank").val()) == ""){
          Toast.fire({
            icon: 'error',
            title: ' Bank harus diisi'
          });
        }else{
          var r=confirm("Anda yakin meng-approve Matching Faktur ini?");
            if (r==true){
            $(this).prop('disabled', true);
            proceed_bayar();/// LANJUT BAYAR
          }
        }
      }
    }
});

function proceed_bayar(){
  $('#tambah_sj_txt').text('Please Wait ...');
  $.ajax({// Run getUnlockedCall() and return values to form
      url: "<?= base_url('SuratJalan/add_sj_match_single'); ?>",
      data:{
         id_supplier:$('#id_supplier').val(),
         id_sj:$('#sj_id').val(),
         nominal_sdh_bayar:$('#nominal_sdh_bayar').val(),
         nominal_bayar:$('#nominal_bayar').val(),
         sisa_sj:$('#sisa_sj').val(),
         tanggal:$('#tanggal_dt').val(),
         jenis_id:$('#jenis_id').val(),
         rekening_tujuan:$('#rekening_tujuan').val(),
         id_bank:$('#bank').val()
      },
      type: "POST",
      success: function(result){
        if (result['message_type'] == 'sukses') {
          alert('Faktur Berhasil di Bayar');
          $("#SJModal").modal('hide');
        } else {
          alert(result['message']);
          $("#SJModal").modal('hide'); 
        }
        $('#load_sj').DataTable().ajax.reload();
        $('#tambah_sj').prop('disabled', false);
        $('#tambah_sj_txt').text('Tambah');
        $('#id_supplier').val('');
        $("#no_surat_jalan").val('');
        $("#sj_id").val('');
        $("#nominal_sj").val('');
        $("#nominal_sdh_bayar").val('');
        $("#nominal_bayar").val('');
        $("#sisa_sj").val(0);
      }
  });
}
</script>