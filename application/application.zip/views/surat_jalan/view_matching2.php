<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Matching Faktur</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url('SuratJalan/MatchingSJ');?>">Matching Faktur</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
    <div class="container-fluid">
        <form class="eventInsFrom" action="" method="POST" target="_self" name="formku" id="formku" action="<?= site_url('SuratJalan/save_matching')?>">
        <input type="hidden" id="total_sj" name="total_sj">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>No Matching</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="no_matching" id="no_matching" value="<?=$h['no_matching'];?>" disabled>
                                        <input type="hidden" name="id" id="id" class="id" value="<?=$h['id'];?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Tanggal</label>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="input-group date" id="date_id" data-target-input="nearest">
                                            <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" readonly />
                                            <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Status</label>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($h['status']==0){
                                            echo '<div style="background-color:red; padding:3px;color:white;">Belum Balance</div>';
                                        }else{
                                            echo '<div style="background-color:green; padding:3px; color:white;">Balanced</div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-5">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Nama Supplier</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" value="<?=$h['nama_supplier'];?>" disabled>
                                        <input type="hidden" name="id_supplier" value="<?= $h['id_supplier']?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Keterangan</label>
                                    </div>
                                    <div class="col-md-8">
                                        <textarea class="form-control" name="keterangan" id="keterangan" disabled><?= $h['keterangan']?>
                                        </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary">
                        <h3 class="card-title">Data Faktur</h3>
                        <div class="card-tools">
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered" id="data_sj">
                            <thead>
                                <tr>
                                  <th style="width: 5%;">No</th>
                                  <th>No SJ</th>
                                  <th>Barang</th>
                                  <th>Kendaraan</th>
                                  <th>Netto</th>
                                  <th>Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no=0; $total=0; foreach ($details as $v){ $no++; $total += $v->sj_bayar;?>
                                <tr>
                                    <td style="width: 5%"><?=$no;?></td>
                                    <td><?=$v->no_matching;?></td>
                                    <td><?=$v->nama_barang;?></td>
                                    <td><?=$v->jenis_kendaraan.' ('.$v->no_kendaraan.')';?></td>
                                    <td align="right"><?=number_format($v->netto,2,',','.');?></td>
                                    <td align="right"><?=number_format($v->sj_bayar,2,',','.');?></td>
                                </tr>
                                <?php } ?>
                                <tr>
                                    <td colspan="5"><b>Total</b></td>
                                    <td align="right"><?=number_format($total,2,',','.');?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-2">
            <a href="<?php echo base_url('SuratJalan/MatchingSJ'); ?>" class="btn btn-info"><i class="fa fa-angle-left"></i> Kembali </a>
            <?php if($h['status']==0){ ?>
            <a href="javascript:;" class="btn btn-primary" onclick="simpanData();"><i class="fa fa-save"></i> Simpan </a>
            <a href="javascript:;" class="btn btn-success float-right" id="approveData"><i class="fa fa-check"></i> Approve </a>
            <?php 
                }
                if($h['status']==1 && $cek_inv['c']==0){ ?>
                  <a class="btn btn-danger btn-md float-right" href="<?=base_url().'SuratJalan/delete_matching/'.$h['id'];?>" onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-trash"></i> Delete</a>
            <?php } ?>
        </div>
        </form>
    </div>
</section>