<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Pembayaran</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Pembayaran</a></li>
          <li class="breadcrumb-item active">Matching Faktur</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-check"></i> Sukses</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h5><i class="icon fas fa-ban"></i> Gagal</h5>
            <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Histori Data Faktur yang Dihapus</h3>
              <div class="card-tools">
                <a class="btn btn-block btn-danger" href="<?=base_url();?>SuratJalan/delete_all_55693953b81a93e51dfed1c79bfabda" onclick="return confirm('Anda yakin menghapus semua data ini?');" >Hapus Semua</a>
              </div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example2" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <td>#</td>
                  <td>Nomor</td>
                  <td>Tanggal</td>
                  <td>Supplier</td>
                  <td>Nama Customer</td>
                  <td>Nama Pembuat Faktur</td>
                </tr>
              </thead>
              <tbody>
                <?php $no=0; foreach ($data as $key => $v) { $no++; ?>
                  <tr>
                    <td><?=$no;?></td>
                    <td><?=$v->no_surat_jalan;?></td>
                    <td><?=date('d-m-Y',strtotime($v->tanggal));?></td>
                    <td><?=$v->nama_supplier;?></td>
                    <td><?=$v->nama_customer;?></td>
                    <td><?=$v->nama_user;?></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>