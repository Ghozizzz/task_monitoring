<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Detail Faktur</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan">Faktur</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<section class="content">
  <div class="container-fluid">
    <form class="eventInsForm" method="post" target="_self" name="formku" id="formku">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <!-- /.card-header -->
          <!-- form start -->
            <input type="hidden" id="id" name="id" value="<?=$h['id'];?>">
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>No Faktur</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_surat_jalan" id="no_surat_jalan" placeholder="No Faktur ..." value="<?=$h['no_surat_jalan'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                      <!-- <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                        </div>
                        <input type="text" name="tanggal" id="tanggal_dm" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                      </div> -->
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="tanggal" id="tanggal" value="<?=date('d-m-Y', strtotime($h['tanggal']));?>" readonly>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>No TBT</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" id="no_tbt" name="no_tbt" value="<?=$h['no_tbt'];?>" readonly>
                    </div>
                  </div>
                  <?php if($h['denda_1']>0){ ?>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Denda</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" value="<?=number_format($h['denda_1'],2,',','.');?>" disabled>
                    </div>
                  </div>
                  <?php } if($h['denda_2']>0){ ?>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Denda K3</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" value="<?=number_format($h['denda_2'],2,',','.');?>" disabled>
                    </div>
                  </div>
                  <?php } ?>
                  <input type="hidden" name="denda" value="<?=$h['denda'];?>">
                  <input type="hidden" name="denda_1" value="<?=$h['denda'];?>">
                  <input type="hidden" name="denda_2" value="<?=$h['denda_2'];?>">
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Tiket Luar Pulau</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="tiket" id="tiket" placeholder="Tiket Luar Pulau ..." value="<?=number_format($h['tiket'],2,',','.');?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>BB Cash</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="bb_cash" id="bb_cash" placeholder="BB Cash ..." value="<?=number_format($h['bb_cash'],2,',','.');?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Ongkos Bongkar Muat</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="id_obm" id="id_obm" value="(<?=$h['nama_bongkar_muat'].') '.number_format($h['harga_bongkar_muat'],2,',','.');?>" disabled>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Group Supplier</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="group_supplier" id="group_supplier" value="<?=$h['nama_group_supplier'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Nama Supplier</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="supplier" id="supplier" value="<?=$h['nama_supplier'];?>" disabled>
                        <input type="hidden" name="id_supplier" value="<?=$h['id_supplier'];?>">
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Nama Customer</label>
                    </div>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="customer" id="customer" value="<?=$h['nama_customer'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Jenis Kendaraan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="jenis_kendaraan" id="jenis_kendaraan" placeholder="Jenis Kendaraan ..." value="<?=$h['jenis_kendaraan'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Nomor Kendaraan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_kendaraan" id="no_kendaraan" placeholder="Nomor Kendaraan ..." value="<?=$h['no_kendaraan'];?>" disabled>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>PPN</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" id="ppn" name="ppn" value="<?=($h['ppn']==0)? 'No':'Yes';?>" readonly>
                    </div>
                  </div>
                  <div class="row mb-2">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan" disabled><?=$h['keterangan'];?></textarea>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
        <!-- /.card -->
      </div>
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Details</h3>

            <div class="card-tools">
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Banyaknya</th>
                  <th>N A M A B A R A N G</th>
                  <th>Harga @ Rp</th>
                  <th>Jumlah</th>
                </tr>
              </thead>
              <tbody>
              <?php
                $no = 1;
                $bruto = 0;
                $potongan = 0;
                $netto = 0;
                $bonus = 0;
                $total = 0;
                foreach ($list_data as $row){
                    $no++;
                    $bruto += $row->bruto;
                    $potongan += $row->potongan;
                    $netto += $row->netto;
                    $bonus += $row->bonus;
                    $total += $row->total;
                }
                    echo '<tr>';
                    echo '<td>Netto</td>';
                    echo '<td class="text-right">'.number_format($netto,2,',','.').'</td>';
                    echo '<td>'.$row->nama_barang.'</td>';
                    echo '<td class="text-right">'.number_format($row->harga,2,',','.').'</td>';
                    echo '<td class="text-right">'.number_format($total,2,',','.').'</td>';
                    echo '</tr>';

                    echo '<tr>';
                    echo '<td>Potongan</td>';
                    echo '<td class="text-right">'.number_format($potongan,2,',','.').'</td>';
                    echo '<td colspan="3"></td>';
                    echo '</tr>';
                    $nilai_obm = $h['harga_bongkar_muat']*$bruto;
                    echo '<tr>';
                    echo '<td>Bruto</td>';
                    echo '<td class="text-right">'.number_format($bruto,2,',','.').'</td>';
                    echo '<td>OBM ('.$h['nama_bongkar_muat'].')</td>';
                    echo '<td class="text-right">'.number_format($h['harga_bongkar_muat'],2,',','.').'</td>';
                    echo '<td class="text-right">'.number_format($nilai_obm,2,',','.').'</td>';
                    echo '</tr>';
                ?>
                <tr>
                  <td colspan="3"></td>
                  <td class="text-center">Total Rp.</td>
                  <td>Rp.<span class="float-right bold"><?=number_format($total-$nilai_obm,2,',','.');?></span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="card">
          <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap table-bordered">
              <tbody>
                <?php 
                if($h['ppn']==1){
                  $nilai_ppn = $total * 10/100;
                }else{
                  $nilai_ppn = 0;
                }

                $tiket = $h['tiket']*$netto;

                $grand_total = $total + $nilai_ppn - $nilai_obm + $tiket - $h['denda'] - $h['bb_cash'];?>
                  <input type="hidden" id="nilai_tiket" name="nilai_tiket" value="<?=$tiket;?>">
                  <input type="hidden" id="total_detail" name="total_detail" value="<?=$total;?>">
                <tr>
                  <td colspan="5" class="bold bg-info">Summary</td>
                </tr>
                <tr>
                  <td colspan="3">Nilai Total</td>
                  <td colspan="2">(<i class="fa fa-plus"></i>) Rp. <span class="float-right bold"><?=number_format($total-$nilai_obm,2,',','.');?></span></td>
                </tr>
                <tr>
                  <td colspan="3">Nilai PPN</td>
                  <td colspan="2">(<i class="fa fa-plus"></i>) Rp. <span class="float-right bold"><?=number_format($nilai_ppn,2,',','.');?></span></td>
                </tr>
              <?php if($h['tiket'] > 0){ ?>
                <tr>
                  <td colspan="2">Tiket Luar Pulau</td>
                  <td colspan="1"><?=number_format($h['tiket'],0,',','.').' x '.number_format($netto,2,',','.');?></td>
                  <td colspan="2">(<i class="fa fa-plus"></i>) Rp. <span class="float-right bold"><?=number_format($tiket,2,',','.');?></span></td>
                </tr>
              <?php }if($h['bb_cash'] > 0){?>
                <tr>
                  <td colspan="3">BB Cash</td>
                  <td colspan="2">(<i class="fa fa-minus"></i>) Rp. <span class="float-right bold"><?=number_format($h['bb_cash'],2,',','.');?></span></td>
                </tr>
              <?php } if($h['denda'] > 0){ ?>
                <tr>
                  <td colspan="3">Denda</td>
                  <td colspan="2">(<i class="fa fa-minus"></i>) Rp. <span class="float-right bold"><?=number_format($h['denda'],2,',','.');?></span></td>
                </tr>
              <?php } ?>
                <tr class="bg-success">
                  <td colspan="3" class="bold">Grand Total</td>
                  <td colspan="2" class="bold">Rp. <span class="float-right"><?=number_format($grand_total,2,',','.');?></span></td>
                </tr>
                <input type="hidden" id="grand_total" name="grand_total" value="<?=$grand_total;?>">
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
    <?php if($h['status']==0){ ?>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header bg-primary">
            <h3 class="card-title">Data Pembayaran</h3>
            <div class="card-tools">
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body p-0">
            <table class="table table-hover table-bordered">
              <thead>
                <?php if($lb['lebihbayar']>0){ ?>
                <tr>
                  <td width="50%">Nilai Lebih Bayar</td>
                  <td width="50%">
                    <input type="text" class="form-control" id="nilai_lb" name="nilai_lb" value="<?=number_format($lb['lebihbayar'],2,'.',',');?>" readonly>
                  </td>
                </tr>
                <tr>
                  <td width="50%">Potong Lebih Bayar</td>
                  <td width="50%">
                    <select class="form-control" name="jenis_lb" id="jenis_lb" style="width: 100%;">
                      <option value="0">No</option>
                      <option value="1">Yes</option>
                    </select>
                  </td>
                </tr>
                <?php } ?>
                <tr>
                  <td width="50%">Potong Deposit</td>
                  <td width="50%">
                    <select class="form-control" name="jenis_id" id="jenis_id" style="width: 100%;"  onchange="get_cek(this.value);">
                      <option value="0">No</option>
                      <option value="1">Yes</option>
                    </select>
                  </td>
                </tr>
                <tr class="show_deposit" style="display: none;">
                  <td width="50%">Nilai Deposit saat Ini</td>
                  <td width="50%">
                    <input type="text" class="form-control" id="deposit" name="deposit" value="<?=number_format($h['nilai_deposit'],2,'.',',');?>" disabled>
                  </td>
                </tr>
                <tr class="show_deposit" style="display: none;">
                  <td width="50%">Nilai Deposit yang Dipotong</td>
                  <td width="50%">
                    <input type="text" class="form-control" id="nilai_deposit" name="nilai_deposit" placeholder="Nominal ..." onkeyup="getComa(this.value, this.id); hitungDeposit();">
                  </td>
                </tr>
              <?php if($this->session->userdata('id_roles') != 3){ ?>
                <tr>
                  <td width="50%">Langsung Bayar</td>
                  <td width="50%">
                    <select class="form-control" name="langsung_bayar" id="langsung_bayar" style="width: 100%;"  onchange="show_bayar(this.value);">
                      <option value="0">No</option>
                      <option value="1">Yes</option>
                    </select>
                  </td>
                </tr>
                <tr class="show_bayar" style="display: none; margin-bottom:5px">
                  <td width="50%">Tanggal Bayar</td>
                  <td width="50%">
                    <div class="input-group date" id="date_id" data-target-input="nearest">
                        <input type="text" name="tanggal_bayar" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" />
                        <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                        </div>
                    </div>
                  </td>
                </tr>
                <tr class="show_bayar" style="display: none; margin-bottom:5px">
                  <td width="50%">Jenis Pembayaran</td>
                  <td width="50%">
                    <select class="form-control select2bs4" name="jenis_pmb_id" id="jenis_pmb_id" style="width: 100%; margin-bottom:5px" onchange="show_bank_tuj(this.value);">
                      <option value="0">Pilih Jenis Pembayaran ...</option>
                      <option value="Cash">Cash</option>
                      <option value="Transfer">Transfer</option>
                    </select>
                  </td>
                </tr>
                <tr class="show_bank_tuj" style="display: none; margin-bottom:5px">
                  <td width="50%">Rekening Tujuan</td>
                  <td width="50%">
                    <input type="text" class="form-control" id="rekening_tujuan" name="rekening_tujuan" placeholder="Rekening Tujuan ...">
                  </td>
                </tr>
                <tr class="show_bank_tuj" style="display: none; margin-bottom:5px">
                  <td width="50%">Nama Bank</td>
                  <td width="50%">
                    <select class="bank form-control select2bs4" name="bank" id="bank" style="width: 100%;">
                      <option value="0">Silahkan Pilih ...</option>
                      <?php foreach ($bank as $b) {
                          echo '<option value="'.$b->id.'">'.$b->nama_bank.'</option>';
                      }?>
                    </select>
                  </td>
                </tr>
              <?php } ?>
              </thead>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php }else{ 
      if(!empty($pembayaran)){
    ?>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header bg-primary">
            <h3 class="card-title">Data Pembayaran</h3>
            <div class="card-tools">
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap table-bordered">
              <thead>
                <tr>
                  <th>Nomor</th>
                  <th>Tanggal</th>
                  <th>Nilai</th>
                </tr>
              </thead>
              <tbody>
                <?php $t_pmb = 0; foreach ($pembayaran as $r){ ?>
                <tr>
                  <td width="35%">
                    <?=$r->no_matching;?>
                    <?php if($r->jenis_pmb==0){?>
                      <a href="<?=base_url().'SuratJalan/view_matching/'.$r->id_match;?>" class="btn btn-success btn-xs"><i class="fa fa-book"></i> View </a>
                    <?php } ?>
                  </td>
                  <td width="15%"><?=$r->tanggal;?></td>
                  <td width="50%" class="bold">
                    Rp. <span class="float-right"><?=number_format($r->nilai,2,',','.');?></span>
                  </td>
                </tr>
                <?php $t_pmb+=$r->nilai; 
                  } ?>
                <tr class="bg-success">
                  <td colspan="2" class="bold">Grand Total</td>
                  <td class="bold">Rp. <span class="float-right"><?=number_format($t_pmb,2,',','.');?></span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php } 
      if(!empty($invoice)){
    ?>
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header bg-primary">
            <h3 class="card-title">Data Invoice</h3>
            <div class="card-tools">
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap table-bordered">
              <thead>
                <tr>
                  <th>Nomor</th>
                  <th>Tanggal</th>
                </tr>
              </thead>
              <tbody>
                <?php $t_pmb = 0; foreach ($invoice as $i){ ?>
                <tr>
                  <td width="85%">
                    <?=$i->no_invoice;?>
                      <a href="<?=base_url().'Finance/view_invoice/'.$i->id;?>" class="btn btn-success btn-xs"><i class="fa fa-book"></i> View </a>
                  </td>
                  <td width="15%"><?=$i->tanggal;?></td>
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php
      }
    } ?>
    <div class="row">
      <div class="col-md-12 pb-2">
        <a href="<?=base_url();?>SuratJalan/index" class="btn btn-secondary float-left"><i class="fa fa-angle-left"></i> Kembali</a>
        &nbsp; 
        <?php if($h['status']==0){ ?>
          <a class="btn btn-info btn-md" href="<?= site_url().'SuratJalan/edit/'.$h['id'];?>" ><i class="fa fa-edit"></i> Edit</a>
          <button type="button" class="btn btn-success float-right" id="approveData">Approve</button>
        <?php }elseif($h['status']==1 && $h['count']==0 && $h['id_invoice']==0 && $this->session->userdata('id_roles') == 1){ ?>
          <button type="button" class="btn btn-success float-right" id="openData">Open Faktur</button>
        <?php } ?>
          <a class="btn btn-dark" href="<?= site_url().'SuratJalan/print_sj/'.$h['id'];?>" target="_blank"><i class="fa fa-print"></i> Print</a>
      </div>
    </div>
    </form>
  </div>
</section>
<script>
const formatter = new Intl.NumberFormat('en-US', {
   minimumFractionDigits: 2,      
   maximumFractionDigits: 2,
});

function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","); 
}

function hitungDeposit(){
    deposit = $('#deposit').val().toString().replace(/\,/g, "");
    nilai_deposit = $('#nilai_deposit').val().toString().replace(/\,/g, "");
    total_harga = Number(deposit) - Number(nilai_deposit);

    if(total_harga<0){
      Toast.fire({
        icon: 'error',
        title: ' Nilai Potong tidak boleh lebih besar dari nilai deposit'
      });
      $('#nilai_deposit').val(numberWithCommas(deposit-0));
    }
    if(Number(nilai_deposit)>$('#grand_total').val()){
      Toast.fire({
        icon: 'error',
        title: ' Nilai Deposit tidak boleh lebih besar dari nilai faktur'
      });
      $('#nilai_deposit').val(0);
    }
}

function get_cek(id){
  if(id == 0){
      $('.show_deposit').hide();
  }else if(id == 1) {
      $('.show_deposit').show();
  }
};

function show_bayar(id){
  if(id == 0){
      $('.show_bayar').hide();
      $('.show_bank_tuj').hide();
  }else if(id == 1) {
      $('.show_bayar').show();
  }
};

function show_bank_tuj(id){
  if(id == "Transfer"){
      // $("#show_rek_tuj").show();
      $('.show_bank_tuj').show();
  }else if(id === "Cash") {
      $('.show_bank_tuj').hide();
  }
};

$("#approveData").click(function(){
  if($.trim($("#total_detail").val()) == 0){
    Toast.fire({
      icon: 'error',
      title: ' Total tidak boleh 0'
    });
  }else if($.trim($("#langsung_bayar").val()) == 1){
    if($.trim($("#tanggal_dt").val()) == 0){
      Toast.fire({
        icon: 'error',
        title: ' Tanggal bayar harus diisi'
      });
    }else if($.trim($("#jenis_pmb_id").val())  == "Cash"){
      proceed_bayar();
    }else{
      if($.trim($("#rekening_tujuan").val()) == ""){
        Toast.fire({
          icon: 'error',
          title: ' Rekening Tujuan harus diisi'
        });
      }else if($.trim($("#bank").val()) == ""){
        Toast.fire({
          icon: 'error',
          title: ' Bank harus diisi'
        });
      }else{
        proceed_bayar();/// LANJUT BAYAR
      }
    }
  }else{
    proceed_bayar();
  }
});

function proceed_bayar(){
  var r=confirm("Anda yakin meng-approve Faktur ini?");
  if (r==true){
      $('#formku').attr("action", "<?=base_url();?>SuratJalan/approve_sj");    
      $('#formku').submit(); 
  }
}

$("#openData").click(function(){
    var r=confirm("Anda yakin meng-open Permintaan barang ini?");
    if (r==true){
        $('#formku').attr("action", "<?=base_url();?>SuratJalan/open_sj");    
        $('#formku').submit(); 
    }
});
</script>