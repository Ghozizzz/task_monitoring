<html lang="en">
    <head>
        <title></title>
        <meta charset="utf-8" />
    </head>
    <body class="margin-left:40px;">
        <table border="0" cellpadding="0" width="100%" cellspacing="0" style="font-family:Microsoft Sans Serif">
            <tr>
                <td width="40%">
                    <table width="100%" cellspacing="0">
                        <tr>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;">
                                <strong>TGL.</strong>
                            </td>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000; border-right:1px solid #000;">
                                <?=date('d-m-Y', strtotime($h['tanggal']));?>
                            </td>
                        </tr>
                        <tr class="text-center bold">
                            <td colspan="2" align="center" style="border-left:1px solid #000; border-bottom:1px solid #000; border-right:1px solid #000;">
                                <strong>DARI</strong>
                            </td>
                        </tr>
                        <tr rowspan="3">
                            <td colspan="2" align="center" style="border-left:1px solid #000; border-bottom:1px solid #000; border-right:1px solid #000;"><?=$h['nama_supplier'];?></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="border-left:1px solid #000; border-bottom:1px solid #000; border-right:1px solid #000;">&nbsp;</td>
                        </tr>
                    </table>
                </td>
                <td width="10%"></td>
                <td width="50%">
                    <table width="100%" cellspacing="0">
                        <tr>
                            <td colspan="2"><strong>KEPADA :</strong></td>
                        </tr>
                        <tr>
                            <td colspan="2"><strong><span style="font-size:20px;">PT. YAPUTRA ABADI PERKASA</span></strong></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left:20px;"><span style="font-size:15px;">Perkantoran Tomang Tol Blok A1 / 50</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 11px;">Taman Kedoya Baru - Kedoya Selatan</td>
                        </tr>
                        <tr>
                            <td colspan="2" style="padding-left: 90px;">Jakarta Barat</td>
                        </tr>
                        <tr>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000;">
                                <strong>No. Mobil</strong>
                            </td>
                            <td style="border-left:1px solid #000; border-bottom:1px solid #000; border-top:1px solid #000; border-right:1px solid #000;"><?=$h['no_kendaraan'];?></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        <table width="100%" cellpadding="1" cellspacing="0" border="1">
          <thead>
            <tr>
              <th width="10%">#</th>
              <th width="10%">Banyaknya</th>
              <th width="50%">N A M A B A R A N G</th>
              <th width="15%">Harga @ Rp</th>
              <th width="15%">Jumlah</th>
            </tr>
          </thead>
          <tbody>
          <?php
            $no = 1;
            $bruto = 0;
            $potongan = 0;
            $netto = 0;
            $bonus = 0;
            $total = 0;
            foreach ($details as $row){
                $no++;
                $bruto += $row->bruto;
                $potongan += $row->potongan;
                $netto += $row->netto;
                $bonus += $row->bonus;
                $total += $row->total;
            }
                echo '<tr>';
                echo '<td>Netto</td>';
                echo '<td align="right">'.number_format($netto,2,',','.').'</td>';
                echo '<td>'.$row->nama_barang.'</td>';
                echo '<td align="right">'.number_format($row->harga,2,',','.').'</td>';
                echo '<td align="right">'.number_format($total,2,',','.').'</td>';
                echo '</tr>';

                echo '<tr>';
                echo '<td>Potongan</td>';
                echo '<td align="right">'.number_format($potongan,2,',','.').'</td>';
                echo '<td colspan="3"></td>';
                echo '</tr>';
                $nilai_obm = $h['harga_bongkar_muat']*$bruto;
                echo '<tr>';
                echo '<td>Bruto</td>';
                echo '<td align="right">'.number_format($bruto,2,',','.').'</td>';
                echo '<td>OBM ('.$h['nama_bongkar_muat'].')</td>';
                echo '<td align="right">'.number_format($h['harga_bongkar_muat'],2,',','.').'</td>';
                echo '<td align="right">'.number_format($nilai_obm,2,',','.').'</td>';
                echo '</tr>';
                $tiket = $h['tiket']*$netto;
                if($h['tiket'] > 0){ ?>
                <tr>
                  <td colspan="2"></td>
                  <td>Tiket Luar Pulau</td>
                  <td align="right"><?=number_format($h['tiket'],0,',','.');?></td>
                  <td align="right"><?=number_format($tiket,2,',','.');?></td>
                </tr>
              <?php } if($h['bb_cash'] > 0){?>
                <tr>
                  <td colspan="2"></td>
                  <td>BB Cash</td>
                  <td></td>
                  <td align="right"><?=number_format($h['bb_cash'],2,',','.');?></td>
                </tr>
              <?php } if($h['denda'] > 0){ ?>
                <tr>
                  <td colspan="2"></td>
                  <td>Denda</td>
                  <td></td>
                  <td align="right"><?=number_format($h['denda'],2,',','.');?></td>
                </tr>
              <?php } 
                $total_pmb = 0;
                foreach ($pembayaran as $r){ ?>
                <tr>
                    <td colspan="2"></td>
                    <td><?=$r->no_matching;?></td>
                    <td></td>
                    <td align="right"><?=number_format($r->nilai,2,',','.');?></td>
                </tr>
              <?php $total_pmb+= $r->nilai; } ?>
            <tr>
              <td colspan="3" align="center"><?=($h['tanggal_lunas']!='0000-00-00')? 'Dibayar Tgl '.$h['tanggal_lunas']:'';?></td>
              <td align="center">Total Rp.</td>
              <td align="right"><?=number_format($total-$nilai_obm-$total_pmb,2,',','.');?></td>
            </tr>
          </tbody>
        </table>
        <table border="0" width="100%" class="mt-2">
            <tr>
                <td style="text-align:center">Tanda Terima</td>
                <td style="text-align:center">Hormat Kami</td>
            </tr>
        </table>
        <p>&nbsp;</p>
	<body onLoad="window.print()">
    </body>
</html>
        