<!-- Content Header (Page header) -->
<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Tambah Faktur</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url();?>SuratJalan">Faktur</a></li>
          <li class="breadcrumb-item active">Tambah</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Gagal</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <!-- left column -->
      <div class="col-md-12">
        <!-- general form elements -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Form</h3>
          </div>
          <!-- /.card-header -->
          <!-- form start -->
          <form class="eventInsForm" method="post" target="_self" name="formku" id="formku" action="<?=base_url('SuratJalan/save');?>">    
            <div class="card-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="row">
                    <div class="col-md-4">
                      <label>No Faktur</label>
                    </div>
                    <div class="col-md-8">
                      <div class="input-group mb-3">
                        <div class="input-group-prepend">
                          <span class="input-group-text">FT-YAP.</span>
                        </div>
                        <input type="text" class="form-control" value="Auto Generate" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Tanggal</label>
                    </div>
                      <!-- <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                        </div>
                        <input type="text" name="tanggal" id="tanggal_dm" class="form-control" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                      </div> -->
                    <div class="col-md-8">
                      <div class="input-group date" id="date_id" data-target-input="nearest">
                          <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." />
                          <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <label>No TBT</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control mb-3" name="no_tbt" value="" placeholder="Nomor TBT ...">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>PPN</label>
                    </div>
                    <div class="col-md-8">
                      <select class="form-control select2bs4" name="ppn" id="ppn" style="width: 100%;">
                          <option value="0">No</option>
                          <option value="1">Yes</option>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Keterangan</label>
                    </div>
                    <div class="col-md-8">
                      <textarea class="form-control" name="keterangan" id="keterangan" placeholder="Keterangan"></textarea>
                    </div>
                  </div>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-5">
                  <div class="row">
                    <div class="col-md-4">
                      <label>Group Supplier</label>
                    </div>
                    <div class="col-md-8">
                      <?php if($this->session->userdata('id_roles') == 3){ ?>
                      <input type="text" class="form-control mb-3" value="<?=$group_supplier['nama_group_supplier'];?>" readonly>
                      <input type="hidden" id="group_supplier" name="group_supplier" value="<?=$group_supplier['id'];?>">
                      <?php }else{ ?>
                      <select class="form-control select2bs4" name="group_supplier" id="group_supplier" style="width: 100%;">
                          <option>Silahkan Pilih ...</option>
                        <?php foreach ($group_supplier as $row) {
                          echo '<option value="'.$row->id.'">'.$row->nama_group_supplier.'</option>';
                        } ?>
                      </select>
                      <?php } ?>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Nama Supplier</label>
                    </div>
                    <div class="col-md-8">
                      <select class="supplier form-control select2bs4" name="supplier" id="supplier" style="width: 100%;">
                          <option value="">Silahkan Pilih ...</option>
                          <option value="0">**Supplier Baru**</option>
                          <?php foreach($supplier as $row) {
                            echo '<option value="'.$row->id.'">'.$row->nama_supplier.'</option>';
                          }?>
                      </select>
                    </div>
                  </div>
                  <div class="row mb-3" id="supplier_baru_div" style="display: none;">
                    <div class="col-md-4">
                      <label>Nama Supplier Baru</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="supplier_baru" id="supplier_baru" placeholder="Nama Supplier Baru ...">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Nama Customer Tujuan</label>
                    </div>
                    <div class="col-md-8">
                      <?php if($this->session->userdata('id_roles') == 3){ ?>
                      <input type="text" class="form-control mb-3" value="<?=$customer['nama_customer'];?>" placeholder="Nama Customer" readonly>
                      <input type="hidden" id="customer" name="customer" value="<?=$customer['id'];?>">
                      <?php }else{ ?>
                      <select class="customer form-control select2bs4" name="customer" id="customer" style="width: 100%;">
                          <option value="0">Silahkan Pilih ...</option>
                          <?php foreach($customer as $row) {
                            echo '<option value="'.$row->id.'">'.$row->nama_customer.'</option>';
                          }?>
                      </select>
                      <?php } ?>
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Jenis Kendaraan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="jenis_kendaraan" id="jenis_kendaraan" placeholder="Jenis Kendaraan ...">
                    </div>
                  </div>
                  <div class="row mb-3">
                    <div class="col-md-4">
                      <label>Nomor Kendaraan</label>
                    </div>
                    <div class="col-md-8">
                      <input type="text" class="form-control" name="no_kendaraan" id="no_kendaraan" placeholder="Nomor Kendaraan ...">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card-body -->

            <div class="card-footer">
              <button type="button" class="btn btn-primary float-right" id="saveData"><i class="fa fa-paper-plane"></i> Submit</button>
            </div>
          </form>
        </div>
        <!-- /.card -->
      </div>
    </div>
  </div>
</section>
<script>
$("#saveData").click(function(){

  if($.trim($("#tanggal_dt").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Tanggal harus diisi'
    });
  }else if($.trim($("#supplier").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Supplier harus diisi'
    });
  }else if($.trim($("#customer").val()) == 0){
    Toast.fire({
      icon: 'error',
      title: ' Customer harus diisi'
    });
  }else if($.trim($("#group_supplier").val()) == ""){
    Toast.fire({
      icon: 'error',
      title: ' Group Supplier harus diisi'
    });
  }else{
    $(this).prop('disabled', true).text('Please Wait ...');
    $('#formku').submit();
  }
});

$(function() {
  $('#supplier').change(function () {
    if($(this).val()==0){
      $('#supplier_baru_div').show('slow');
    }else{
      $('#supplier_baru_div').hide('slow');
    }
  });
});
</script>