<section class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1>Matching Faktur</h1>
      </div>
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="<?=base_url('SuratJalan/MatchingSJ');?>">Matching Faktur</a></li>
          <li class="breadcrumb-item active">Detail</li>
        </ol>
      </div>
    </div>
  </div><!-- /.container-fluid -->
</section>
<div class="modal fade" id="SJModal" tabindex="-1" role="basic" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">&nbsp;</h4>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-danger display-hide" id="alert-danger">
                            <button class="close" data-close="alert"></button>
                            <span id="message">&nbsp;</span>
                        </div>
                    </div>
                </div>
                <form class="eventInsForm" method="post" target="_self" name="frmInv" 
                    id="frmInv">
                    <input type="hidden" id="id_modal_sj" name="id_modal_sj">
                    <div class="row">
                        <div class="col-md-5">
                            No. Faktur<font color="#f00">*</font>
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="no_surat_jalan" name="no_surat_jalan" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                            <input type="hidden" id="sj_id" name="sj_id">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            Nilai
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="nominal_sj" name="nominal_sj" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            Nominal Sudah Di Bayar
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="nominal_sdh_bayar" name="nominal_sdh_bayar" class="form-control myline" style="margin-bottom:5px" readonly="readonly">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            Nominal Di Bayar
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="nominal_bayar" name="nominal_bayar" class="form-control myline" style="margin-bottom:5px" value="0" onkeyup="getComa(this.value, this.id); hitungSubTotalSJ();">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-5">
                            Sisa Faktur
                        </div>
                        <div class="col-md-7">
                            <input type="text" id="sisa_sj" name="sisa_sj" class="form-control myline" style="margin-bottom:5px" value="0" readonly="readonly">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">                        
                <button type="button" class="btn btn-primary" id="tambah_sj"><i class="fa fa-plus"></i> Tambah</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fa fa-times"></i> Tutup</button>
            </div>
        </div>
    </div>
</div>
<section class="content">
    <div class="container-fluid">
        <form class="eventInsFrom" action="" method="POST" target="_self" name="formku" id="formku" action="<?= site_url('SuratJalan/save_matching')?>">
        <input type="hidden" id="total_sj" name="total_sj">
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h5><i class="icon fas fa-check"></i> Sukses</h5>
                    <span id="msg_sukses"><?= $this->session->flashdata('sukses'); ?></span>
                </div>
                <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h5><i class="icon fas fa-ban"></i> Gagal</h5>
                    <span id="msg_sukses"><?= $this->session->flashdata('gagal'); ?></span>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>No Matching</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="no_matching" id="no_matching" value="<?=$h['no_matching'];?>" disabled>
                                        <input type="hidden" name="id" id="id" class="id" value="<?=$h['id'];?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Tanggal</label>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="input-group date" id="date_id" data-target-input="nearest">
                                            <input type="text" name="tanggal" class="form-control datetimepicker-input" id="tanggal_dt" data-target="#date_id" placeholder="Tanggal ..." value="<?=$h['tanggal'];?>" readonly />
                                            <div class="input-group-append" data-target="#date_id" data-toggle="datetimepicker">
                                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Status</label>
                                    </div>
                                    <div class="col-md-8">
                                        <?php if($h['status']==0){
                                            echo '<div style="background-color:red; padding:3px;color:white;">Belum Balance</div>';
                                        }else{
                                            echo '<div style="background-color:green; padding:3px; color:white;">Balanced</div>';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1"></div>
                            <div class="col-md-5">
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Nama Supplier</label>
                                    </div>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" name="nama_supplier" id="nama_supplier" value="<?=$h['nama_supplier'];?>" disabled>
                                        <input type="hidden" name="id_supplier" value="<?= $h['id_supplier']?>">
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-md-4">
                                        <label>Keterangan</label>
                                    </div>
                                    <div class="col-md-8">
                                        <textarea class="form-control" name="keterangan" id="keterangan" disabled><?= $h['keterangan']?>
                                        </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary">
                        <h3 class="card-title">List Faktur</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered" id="load_sj">
                            <thead>
                                <tr>
                                  <th style="width: 5%;">No</th>
                                  <th>No SJ</th>
                                  <th>Barang</th>
                                  <th>Kendaraan</th>
                                  <th>Netto</th>
                                  <th>Harga</th>
                                  <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary">
                        <h3 class="card-title">Data Faktur</h3>
                        <div class="card-tools">
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered" id="data_sj">
                            <thead>
                                <tr>
                                  <th style="width: 5%;">No</th>
                                  <th>No SJ</th>
                                  <th>Barang</th>
                                  <th>Kendaraan</th>
                                  <th>Netto</th>
                                  <th>Harga</th>
                                  <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary">
                        <h3 class="card-title">Data Pembayaran</h3>
                        <div class="card-tools">
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover text-nowrap table-bordered">
                            <thead>
                                <tr>
                                    <td width="50%">Ada Lebih Bayar</td>
                                    <td width="50%">
                                      <select class="form-control select2bs4" name="jenis_lb" id="jenis_lb" style="width: 100%;"  onchange="get_lb(this.value);">
                                        <option value="0">No</option>
                                        <option value="1">Yes</option>
                                      </select>
                                    </td>
                                </tr>
                                <tr class="show_lb" style="display: none;">
                                    <td width="50%">Nilai Lebih Bayar</td>
                                    <td width="50%"><input type="text" class="form-control" id="nilai_lb" name="nilai_lb" placeholder="Rekening Tujuan ..."></td>
                                </tr>
                                <tr>
                                    <td>Total SJ</td>
                                    <td>
                                        <input type="text" class="form-control" id="total_match_format" value="0" readonly>
                                        <input type="hidden" id="total_match" name="total" value="0">
                                    </td>
                                </tr>
                                <tr>
                                    <td width="50%">Jenis Pembayaran</td>
                                    <td width="50%">
                                      <select class="form-control select2bs4" name="jenis_id" id="jenis_id" style="width: 100%;"  onchange="get_cek(this.value);">
                                        <option value="0">Pilih Jenis Pembayaran ...</option>
                                        <option value="Cash">Cash</option>
                                        <option value="Transfer">Transfer</option>
                                      </select>
                                    </td>
                                </tr>
                                <tr class="show_bank_tuj" style="display: none;">
                                    <td width="50%">Rekening Tujuan</td>
                                    <td width="50%"><input type="text" class="form-control" id="rekening_tujuan" name="rekening_tujuan" placeholder="Rekening Tujuan ..."></td>
                                </tr>
                                <tr class="show_bank_tuj" style="display: none;">
                                    <td width="50%">Nama Bank</td>
                                    <td width="50%">
                                          <select class="bank form-control select2bs4" name="bank" id="bank" style="width: 100%;">
                                              <option value="0">Silahkan Pilih ...</option>
                                              <?php foreach ($bank as $b) {
                                                  echo '<option value="'.$b->id.'">'.$b->nama_bank.'</option>';
                                              }?>
                                          </select>
                                    </td>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-2">
            <a href="<?php echo base_url('SuratJalan/MatchingSJ'); ?>" class="btn btn-info"><i class="fa fa-angle-left"></i> Kembali </a>
            <?php if($h['status']==0){ ?>
            <a href="javascript:;" class="btn btn-primary" onclick="simpanData();"><i class="fa fa-save"></i> Simpan </a>
            <a href="javascript:;" class="btn btn-success float-right" id="approveData"><i class="fa fa-check"></i> Approve </a>
            <?php }?>
        </div>
        </form>
    </div>
</section>
<script>
$(document).ready(function() {
    $('#load_sj').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax":{
          "url":"<?=site_url('SuratJalan/get_list_sj');?>",
          "type":"post",
          "data":{
            "id":<?=$h['id_supplier'];?>,
            "idm":<?=$h['id'];?>
          }
        },
        "columnDefs":[
          {
            "targets":'_all',
            "className":'p-1'
          },
          {
            "targets":[3,4],
            "className":'text-right'
          }
        ]
    } );
    $('#data_sj').DataTable( {
        "processing": true,
        "serverSide": true,
        "ajax":{
          "url":"<?=site_url('SuratJalan/get_data_match_detail');?>",
          "type":"post",
          "data":{
            "id":<?=$h['id'];?>
          }
        },
        "columnDefs":[
          {
            "targets":'_all',
            "className":'p-1'
          },
          {
            "targets":[3,4],
            "className":'text-right'
          }
        ]
    } );
});

const formatter = new Intl.NumberFormat('en-US', {
   minimumFractionDigits: 2,      
   maximumFractionDigits: 2,
});

function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","); 
}

function getComa(value, id){
    angka = value.toString().replace(/\,/g, "");
    $('#'+id).val(angka.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

function ReplaceNumberWithCommas(yourNumber) {
    //Seperates the components of the number
    var n= yourNumber.toString().split(".");
    //Comma-fies the first part
    n[0] = n[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    //Combines the two sections
    return n.join(".");
}

function simpanData(){
    var result = confirm("Anda yakin untuk menyimpannya ?");
    if (result) {
        $('#formku').submit(); 
    }
}

function hitungSubTotalSJ(){
    nominal_sj = $('#nominal_sj').val().toString().replace(/\,/g, "");
    n1 = $('#nominal_sdh_bayar').val().toString().replace(/\,/g, "");
    n2 = $('#nominal_bayar').val().toString().replace(/\,/g, "");
    total_harga = formatter.format(Number(nominal_sj) - (Number(n1) + Number(n2)));
    // console.log(nominal_sj, n1, n2, total_harga);
    // console.log(nominal_sj+' | '+n3+' | '+total_harga);
    $('#sisa_sj').val(total_harga.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","));
}

/** sj */
// function list_sj(id_supp,id_match){
//     $.ajax({
//         url: "<?= site_url('SuratJalan/load_list_sj'); ?>",
//         type: "POST",
//         data: {
//             id:id_supp,
//             id_match:<?=$this->uri->segment(3);?>
//         },
//         dataType: "json",
//         success: function(result) {
//             $('#list_sj').html(result);
//         }
//     });
// }

function input_sj(id){
    $.ajax({
        url: "<?= site_url('SuratJalan/get_data_sj'); ?>",
        type: "POST",
        data: {
            id:id
        },
        dataType: "json",
        success: function(result){
            console.log(result);
            $("#SJModal").find('.modal-title').text('Input Faktur');
            $("#SJModal").modal('show',{backdrop: 'true'});
            $("#tambah_sj").show();
            $("#alert-danger").hide();
            $("#id_modal_sj").val(<?php echo $h['id'];?>);
            
            $("#no_surat_jalan").val(result['no_surat_jalan']);
            $("#sj_id").val(result['id']);
            $("#nominal_sj").val(numberWithCommas(result['nilai']));
            $("#nominal_sdh_bayar").val(numberWithCommas(result['nilai_total_bayar']));
            $("#nominal_bayar").val(numberWithCommas(result['nilai_sisa']));
            $("#sisa_sj").val(0);
        }
    });
}

function view_sj(id){
    $.ajax({
        url: "<?php echo base_url('SuratJalan/view_data_sj'); ?>",
        type: "POST",
        data: "id="+id,
        dataType: "json",
        success: function(result){
            $("#SJModal").find('.modal-title').text('sj');
            $("#SJModal").modal('show',{backdrop: 'true'});
            $("#tambah_sj").hide();
            $("#alert-danger").hide();
            
            $("#id_modal_sj").val(result['id']);
            $("#no_surat_jalan").val(result['no_surat_jalan']);
            $("#sj_id").val(result['id_sj']);
            $("#nominal_sj").val(numberWithCommas(result['nilai']));
            $("#nominal_sdh_bayar").val(numberWithCommas(result['nilai_bayar']));
            $("#nominal_bayar").val(numberWithCommas(result['sj_bayar']));
        }
    });
}

function delSJ(id,id_sj){
    if(confirm('Anda yakin menghapus sj ini?')){
        $.ajax({
            type:"POST",
            url:'<?php echo base_url('SuratJalan/del_sj_match'); ?>',
            data:{
               id:id,
               id_sj:id_sj
            },
            success:function(result){
                if(result['message_type']=="sukses"){
                    // list_sj(<?= $h['id_supplier'].','.$h['id'];?>);
                    // data_sj(<?= $h['id'];?>);
                    $('#load_sj').DataTable().ajax.reload();
                    $('#data_sj').DataTable().ajax.reload();
                    cekTotal();
                }else{
                    $('#message').html(result['message']);
                    $('.alert-danger').show(); 
                }            
            }
        });
    }
}

$('#tambah_sj').click(function(event) {
    event.preventDefault(); /*  Stops default form submit on click */

    if($.trim($("#nominal_bayar").val()) == ("" || 0)){
        $('#message').html("Nominal di Bayar harus diisi, tidak boleh kosong!");
        $('.alert-danger').show();
    }else{
        $(this).prop('disabled', true);
        $.ajax({// Run getUnlockedCall() and return values to form
            url: "<?= base_url('SuratJalan/add_sj_match'); ?>",
            data:{
               id_modal:$('#id_modal_sj').val(),
               id_sj:$('#sj_id').val(),
               nominal_sdh_bayar:$('#nominal_sdh_bayar').val(),
               nominal_bayar:$('#nominal_bayar').val(),
               sisa_sj:$('#sisa_sj').val(),
               tanggal:$('#tanggal_dt').val()
            },
            type: "POST",
            success: function(result){
                if (result['message_type'] == 'sukses') {
                    $("#SJModal").modal('hide'); 
                    // list_sj(<?= $h['id_supplier'].','.$h['id'];?>);
                    $('#load_sj').DataTable().ajax.reload();
                    // data_sj(<?= $h['id'];?>);
                    $('#data_sj').DataTable().ajax.reload();
                    cekTotal();
                    $('#tambah_sj').prop('disabled', false);
                } else {
                    alert('GAGAL');
                    $("#SJModal").modal('hide'); 
                }
            }
        });
    }
});

$("#approveData").click(function(){
    console.log($('#total_match').val());
    if($('#total_match').val() == 0){
        Toast.fire({
          icon: 'error',
          title: ' Total Faktur harus lebih besar dari 0'
        });
    }else if($.trim($("#jenis_id").val()) == 0){
        Toast.fire({
          icon: 'error',
          title: ' Jenis Pembayaran harus diisi'
        });
    }else if($.trim($("#jenis_id").val()) == "Cash"){
        var r=confirm("Anda yakin meng-approve Matching Faktur ini?");
        if (r==true){
            $('#formku').attr("action", "<?=base_url();?>SuratJalan/approve_match_sj");    
            $('#formku').submit(); 
        }
    }else{
      if($.trim($("#rekening_tujuan").val()) == ""){
        Toast.fire({
          icon: 'error',
          title: ' Rekening Tujuan harus diisi'
        });
      }else if($.trim($("#bank").val()) == ""){
        Toast.fire({
          icon: 'error',
          title: ' Bank harus diisi'
        });
      }else{
        var r=confirm("Anda yakin meng-approve Matching Faktur ini?");
        if (r==true){
            $('#formku').attr("action", "<?=base_url();?>SuratJalan/approve_match_sj");    
            $('#formku').submit(); 
        }
      }
    }
});

function get_cek(id){
  if(id == "Transfer"){
    $('.show_bank_tuj').show();
  }else if(id === "Cash") {
    $('.show_bank_tuj').hide();
  }
};

function get_lb(id){
  if(id == 1){
    $('.show_lb').show();
  }else if(id == 0) {
    $('.show_lb').hide();
  }
};

function cekTotal(){
    $.ajax({
        url: "<?php echo base_url('SuratJalan/cek_total_match'); ?>",
        type: "POST",
        data: "id="+<?=$h['id'];?>,
        dataType: "json",
        success: function(result) {
            $('#total_match_format').val(result['total_format']);
            $('#total_match').val(result['total']);
        }
    });
}
cekTotal();
</script>