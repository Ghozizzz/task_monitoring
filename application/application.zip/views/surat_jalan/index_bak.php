<!-- Content Header (Page header) -->
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0 text-dark">Faktur</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Faktur</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>

<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="alert alert-success <?=(empty($this->session->flashdata('sukses'))? "d-none": ""); ?>" id="box_msg_sukses">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-check"></i> Sukses</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('sukses'); ?></span>
        </div>
        <div class="alert alert-danger <?=(empty($this->session->flashdata('gagal'))? "d-none": ""); ?>" id="box_msg_gagal">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h5><i class="icon fas fa-ban"></i> Gagal</h5>
          <span id="msg_sukses"><?php echo $this->session->flashdata('gagal'); ?></span>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <div class="d-flex justify-content-between">
              <h3 class="card-title">Data Faktur</h3>
              <div class="card-tools">
                <a class="btn btn-block btn-primary" id="tambah" href="<?=base_url();?>SuratJalan/add">Tambah</a>
              </div>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example2" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <td>Nomor</td>
                  <td>Tanggal</td>
                  <td>Supplier</td>
                  <td>Group Spl</td>
                  <td>Status</td>
                  <td>Status Invoice</td>
                  <td>Action</td>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($data as $key => $v) { ?>
                  
                  <tr>
                    <td><?=$v->no_surat_jalan;?></td>
                    <td><?=$v->tanggal;?></td>
                    <td><?=$v->nama_supplier;?></td>
                    <td><?=$v->nama_group_supplier;?></td>
                    <?php if($v->status==0){
                      echo '<td class="bg-secondary"><span>Draft</span></td>'; 
                    }elseif($v->status==1){
                      if($v->flag>0){
                        echo '<td class="bg-navy"><span>Sudah Dibayar</span></td>';
                      }else{
                        echo '<td class="bg-success"><span>Approved</span></td>';
                      }
                    }elseif($v->status==2){
                      echo '<td class="bg-navy"><b>Finished</b></td>';
                    }elseif($v->status==9){
                      echo '<td class="bg-danger color-palette"><span>Rejected</span></td>';
                    }

                    /** Status Invoice **/
                    if($v->id_invoice==0){
                      echo '<td class="bg-secondary">Belum ada Invoice</td>';
                    }else{
                      echo '<td class="bg-navy">Sudah ada Invoice</td>';
                    }
                    ?></td>
                    </td>
                    <td>
                    <?php if($v->status==0){ ?>
                      <a class="btn btn-info btn-sm" href="<?= site_url().'SuratJalan/edit/'.$v->id;?>" ><i class="fa fa-edit"></i> Edit</a>
                      <a class="btn btn-danger btn-sm" href="<?= site_url().'SuratJalan/delete/'.$v->id;?>" onclick="return confirm('Anda yakin menghapus data ini?');"><i class="fa fa-trash"></i> Delete</a> |
                    <?php } ?>
                      <a class="btn btn-primary btn-sm" href="<?= site_url().'SuratJalan/view/'.$v->id;?>" ><i class="fa fa-file-alt"></i> View</a>
                    <?php if($v->status!=0){?>
                      <a class="btn btn-dark btn-sm" href="<?= site_url().'SuratJalan/print_sj/'.$v->id;?>" target="_blank"><i class="fa fa-print"></i> Print</a>
                    <?php } ?>   
                    </td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </div>
  <!-- /.container-fluid -->
</section>