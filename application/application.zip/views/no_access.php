<section class="content">
  <div class="error-page">
    <h2 class="headline text-warning"> No Access</h2>

      <h3><i class="fas fa-exclamation-triangle text-warning"></i> Oops! You Got No Access ...</h3>
    <!-- /.error-content -->
  </div>
  <!-- /.error-page -->
</section>